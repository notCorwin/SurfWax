# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: userscripts.spec.ts >> restores saved user scripts after the MV3 worker restarts
- Location: e2e/userscripts.spec.ts:41:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 1
Received: 0

Call Log:
- Timeout 15000ms exceeded while waiting on the predicate
```

# Test source

```ts
  1   | import { chromium, expect, type BrowserContext, type CDPSession, type Locator, type Page } from "@playwright/test";
  2   | import { once } from "node:events";
  3   | import { mkdtemp, readFile, rm } from "node:fs/promises";
  4   | import { existsSync } from "node:fs";
  5   | import { createServer, type Server } from "node:http";
  6   | import { tmpdir } from "node:os";
  7   | import { resolve } from "node:path";
  8   | 
  9   | 
  10  | import { test, textResponse, commandResponse, startProvider, closeServer, openExtension, dispose, configure, enableUserScripts, readEvents, nameCurrentConversation, warnsOnLeave, expectThemeButton, type MockResponse } from './fixtures';
  11  | 
  12  | test("ships the MV3 Harness and user-script manager", async () => {
  13  |   const opened = await openExtension();
  14  |   try {
  15  |     const manifest = await opened.page.evaluate(() => chrome.runtime.getManifest());
  16  |     expect(manifest).toMatchObject({ name: "Surf Wax", manifest_version: 3, minimum_chrome_version: "138", version: JSON.parse(await readFile(resolve(process.cwd(), "package.json"), "utf8")).version });
  17  |     expect(manifest.permissions).toEqual(["debugger", "downloads", "scripting", "sidePanel", "storage", "tabs", "unlimitedStorage", "userScripts"]);
  18  |     expect(manifest.optional_permissions ?? []).toEqual([]);
  19  |     expect(await opened.page.evaluate(() => chrome.permissions.contains({ permissions: ["downloads"] }))).toBe(true);
  20  |     expect(manifest.permissions).toContain("userScripts");
  21  |     expect(existsSync(resolve(process.env.SURFWAX_EXTENSION_PATH ?? "dist", "userscripts.html"))).toBe(true);
  22  |     await expect(opened.page.getByTestId("open-user-scripts")).toBeVisible();
  23  |     await expect(opened.page.getByTestId("config-required-state")).toBeVisible();
  24  | 
  25  |     const options = await configure(opened.context, opened.page, "https://provider.test/v1");
  26  |     await expect(options.getByTestId("options-card").locator("input")).toHaveCount(6);
  27  |     await expect(options.getByRole("link", { name: "打开脚本管理" })).toHaveCount(0);
  28  |     await options.getByRole("tab", { name: "数据管理" }).click();
  29  |     await expect(options.getByTestId("event-log-clear")).toBeVisible();
  30  |     await expect(options.getByTestId("event-log")).toHaveCount(0);
  31  |     await expect(options.getByTestId("user-scripts-panel")).toHaveCount(0);
  32  |     await expect(opened.page.getByTestId("welcome-options")).toHaveCount(0);
  33  |     await expect(opened.page.getByTestId("edit-message-button")).toHaveCount(0);
  34  |     await expect(opened.page.getByTestId("model-label")).toHaveCount(0);
  35  |   } finally {
  36  |     await dispose(opened.context, opened.userDataDirectory);
  37  |   }
  38  | });
  39  | 
  40  | 
  41  | test("restores saved user scripts after the MV3 worker restarts", { tag: "@user-journey" }, async () => {
  42  |   const provider = await startProvider([]);
  43  |   const opened = await openExtension();
  44  |   try {
  45  |     await enableUserScripts(opened.context, opened.extensionId, opened.page);
  46  |     // Establish saved state through the user's workbench. Writing declarations
  47  |     // directly races first-start reconciliation and bypasses the save path.
  48  |     const manager = await opened.context.newPage();
  49  |     await manager.goto(`chrome-extension://${opened.extensionId}/userscripts.html`);
  50  |     await expect(manager.getByLabel("已保存脚本")).toBeVisible();
  51  |     await manager.getByRole("button", { name: "新建脚本" }).click();
  52  |     await manager.locator("#script-id").fill("restored");
  53  |     await manager.locator("#script-matches").fill(`${provider.origin}/*`);
  54  |     await manager.locator("#script-code .cm-content").fill("document.documentElement.dataset.restoredScript = 'ran'");
  55  |     await manager.getByRole("button", { name: "保存", exact: true }).click();
  56  |     await expect(manager.getByRole("status")).toContainText("脚本已保存");
  57  |     await manager.getByRole("button", { name: "返回列表" }).click();
  58  |     await expect(manager.getByLabel("已保存脚本").getByText("已注册")).toBeVisible();
  59  |     const saved = (await manager.evaluate(() => chrome.storage.local.get("side-agent:user-scripts")))["side-agent:user-scripts"];
  60  |     expect(saved).toMatchObject([{ id: "restored", matches: [`${provider.origin}/*`] }]);
  61  |     await manager.evaluate(async () => {
  62  |       await chrome.storage.local.set({ "side-agent:unrelated": "keep" });
  63  |       // Fault injection: lose the executable projection, retaining the saved
  64  |       // declaration. Native Chrome persistence must not mask broken restore.
  65  |       await chrome.userScripts.unregister({ ids: ["restored"] });
  66  |     });
  67  |     expect(await manager.evaluate(async () => (await chrome.userScripts.getScripts({ ids: ["restored"] })).length)).toBe(0);
  68  |     // CDP loadUnpacked is not a persistent installation. Restart the actual
  69  |     // MV3 worker instead of reinstalling and calling that a browser restart.
  70  |     const protocol = await opened.context.newCDPSession(opened.page);
  71  |     let versionId: string | undefined;
  72  |     protocol.on("ServiceWorker.workerVersionUpdated", ({ versions }) => {
  73  |       versionId = versions.find(version => version.scriptURL.startsWith(`chrome-extension://${opened.extensionId}/`) && version.runningStatus === "running")?.versionId ?? versionId;
  74  |     });
  75  |     await protocol.send("ServiceWorker.enable");
  76  |     await expect.poll(() => versionId).toBeTruthy();
  77  |     await protocol.send("ServiceWorker.stopWorker", { versionId: versionId! });
  78  |     await opened.page.reload();
  79  |     await expect(opened.page.getByTestId("open-user-scripts")).toBeVisible();
  80  |     await protocol.detach();
> 81  |     await expect.poll(() => opened.page.evaluate(async () => (await chrome.userScripts.getScripts({ ids: ["restored"] })).length)).toBe(1);
      |                                                                                                                                    ^ Error: expect(received).toBe(expected) // Object.is equality
  82  |     expect((await opened.page.evaluate(async () => chrome.storage.local.get("side-agent:user-scripts")))["side-agent:user-scripts"]).toEqual(saved);
  83  |     expect(await opened.page.evaluate(async () => (await chrome.storage.local.get("side-agent:unrelated"))["side-agent:unrelated"])).toBe("keep");
  84  |     const target = await opened.context.newPage();
  85  |     await target.goto(`${provider.origin}/target`);
  86  |     await expect.poll(() => target.evaluate(() => document.documentElement.dataset.restoredScript)).toBe("ran");
  87  |   } finally {
  88  |     const state = await opened.page.evaluate(async () => ({
  89  |       declarations: await chrome.storage.local.get(["side-agent:user-scripts", "side-agent:user-scripts-disabled", "side-agent:user-scripts-error"]),
  90  |       native: typeof chrome.userScripts === "object" ? await chrome.userScripts.getScripts() : null,
  91  |     })).catch(error => ({ error: String(error) }));
  92  |     const workers = await Promise.all(opened.context.serviceWorkers().filter(worker => worker.url().startsWith(`chrome-extension://${opened.extensionId}/`)).map(worker =>
  93  |       worker.evaluate(async () => ({ available: typeof chrome.userScripts, native: typeof chrome.userScripts === "object" ? await chrome.userScripts.getScripts() : null }))
  94  |         .catch(error => ({ error: String(error) }))));
  95  |     const events = await readEvents(opened.page).then(events => events.filter(event => event.type.startsWith("userscript."))).catch(error => ({ error: String(error) }));
  96  |     await test.info().attach("user-script-restoration-state", { body: JSON.stringify({ state, workers, events }), contentType: "application/json" });
  97  |     await dispose(opened.context, opened.userDataDirectory, provider.server);
  98  |   }
  99  | });
  100 | 
  101 | 
  102 | test("lets the agent create, inspect, edit and toggle a user script", async () => {
  103 |   const responses: MockResponse[] = [];
  104 |   const provider = await startProvider(responses);
  105 |   const opened = await openExtension();
  106 |   try {
  107 |     await enableUserScripts(opened.context, opened.extensionId, opened.page);
  108 |     const script = { id: "agent-script", matches: [`${provider.origin}/*`], js: [{ code: "document.documentElement.dataset.agentScript = 'first'" }] };
  109 |     responses.push(
  110 |       commandResponse("create_script", { definition: script }, "call-script-create"),
  111 |       commandResponse("list_scripts", {}, "call-script-list"),
  112 |       commandResponse("read_script", { scriptId: script.id }, "call-script-read"),
  113 |       commandResponse("update_script", { scriptId: script.id, changes: { js: [{ code: "document.documentElement.dataset.agentScript = 'edited'" }] } }, "call-script-edit"),
  114 |       commandResponse("disable_script", { scriptId: script.id }, "call-script-disable"),
  115 |       commandResponse("enable_script", { scriptId: script.id }, "call-script-enable"),
  116 |       textResponse("SCRIPT_TOOLS_DONE"), textResponse("脚本工具"),
  117 |     );
  118 |     const options = await configure(opened.context, opened.page, provider.baseURL);
  119 |     await options.close();
  120 |     // Old tool names belong to a persisted historical conversation. Creating
  121 |     // its snapshot during a fresh thread's initialization races prompt reads.
  122 |     await nameCurrentConversation(opened.page, "历史脚本会话");
  123 |     await opened.page.getByTestId("composer-input").fill("创建、查看、编辑并切换脚本");
  124 |     await opened.page.getByTestId("composer-input").press("Enter");
  125 |     await expect(opened.page.locator(".markdown-body").last()).toContainText("SCRIPT_TOOLS_DONE");
  126 |     const result = await opened.page.evaluate(async () => ({
  127 |       scripts: await chrome.userScripts.getScripts({ ids: ["agent-script"] }),
  128 |       disabled: (await chrome.storage.local.get("side-agent:user-scripts-disabled"))["side-agent:user-scripts-disabled"],
  129 |     }));
  130 |     expect(result.scripts).toMatchObject([{ id: script.id, js: [{ code: "document.documentElement.dataset.agentScript = 'edited'" }] }]);
  131 |     expect(result.disabled).toEqual([]);
  132 |     const events = await readEvents(opened.page);
  133 |     expect(events.find((event) => event.type === "model.started")?.content.toolCount).toBe(provider.requests.find((request) => request.tools)?.tools.length);
  134 |     for (const id of ["call-script-create", "call-script-list", "call-script-read", "call-script-edit", "call-script-disable", "call-script-enable"]) {
  135 |       expect(events.some((event) => event.toolCallId === id && event.type === "tool.finished")).toBe(true);
  136 |     }
  137 |   } finally {
  138 |     await dispose(opened.context, opened.userDataDirectory, provider.server);
  139 |   }
  140 | });
  141 | 
  142 | 
  143 | test("contains a long user script restore error without hiding the manager", async () => {
  144 |   const opened = await openExtension();
  145 |   try {
  146 |     const [scripts] = await Promise.all([
  147 |       opened.context.waitForEvent("page"), opened.page.getByTestId("open-user-scripts").click(),
  148 |     ]);
  149 |     await scripts.setViewportSize({ width: 360, height: 700 });
  150 |     await scripts.evaluate(() => chrome.storage.local.set({ "side-agent:user-scripts-error": "SCRIPT_ERROR_".repeat(2000) }));
  151 |     const notice = scripts.locator(".app-error-notice").filter({ hasText: "用户脚本恢复失败" });
  152 |     await expect(notice).toBeVisible();
  153 |     await notice.getByText("错误详情").click();
  154 |     await expect(notice.locator(".app-error-detail")).toContainText("SCRIPT_ERROR_");
  155 |     expect(await notice.locator(".app-error-detail").evaluate((element) => element.scrollHeight > element.clientHeight)).toBe(true);
  156 |     await expect(scripts.getByLabel("已保存脚本")).toBeVisible();
  157 |   } finally {
  158 |     await dispose(opened.context, opened.userDataDirectory);
  159 |   }
  160 | });
  161 | 
  162 | 
  163 | test("manages, edits and deletes scripts in the native Chrome scripts workbench", async () => {
  164 |   const provider = await startProvider([]);
  165 |   const opened = await openExtension();
  166 |   try {
  167 |     const [disabledManager] = await Promise.all([
  168 |       opened.context.waitForEvent("page"), opened.page.getByTestId("open-user-scripts").click(),
  169 |     ]);
  170 |     await expect(disabledManager.getByRole("status")).toContainText("Allow User Scripts");
  171 |     await disabledManager.close();
  172 |     await enableUserScripts(opened.context, opened.extensionId, opened.page);
  173 |     const target = await opened.context.newPage();
  174 |     await target.goto(`${provider.origin}/target`);
  175 |     const [manager] = await Promise.all([
  176 |       opened.context.waitForEvent("page"), opened.page.getByTestId("open-user-scripts").click(),
  177 |     ]);
  178 |     await manager.waitForLoadState("domcontentloaded");
  179 |     await expect(manager.getByTestId("user-scripts-panel")).toBeVisible();
  180 |     await expect(manager.getByLabel("已保存脚本")).toBeVisible();
  181 |     await expect(manager.getByText("在网页中试运行")).toHaveCount(0);
```
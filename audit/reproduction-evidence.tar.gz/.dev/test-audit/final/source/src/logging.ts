import { artifactPagingError, artifactPagePath } from "./artifact-selection";
import { logIO } from "./log-io";
import type { JsonValue } from "./types";
import { arrayBufferLength, arrayViewName, createArrayView, dateISOString, dateValue, decodeLogGraph, encodeLogGraph, graphProperties, isArrayBuffer, isDataView, isDate, isMap, isRegExp, isSet, mapEntries, mapSizeOf, regexpFlagString, regexpSource, requiresLogGraph, setSizeOf, setValues, viewLayout } from "./log-graph";
import { partitionArtifact, readPartitionedArtifact, type ArtifactGraph, type ArtifactPart } from "./artifact-graph";

export type LogEvent = {
  id: number;
  type: string;
  timestamp: string;
  /** Version of the value encoding, separate from user-controlled payloads. */
  valueEncoding?: 2 | 3 | 4 | 5;
  /** Internal manifest and part coordinates; user payloads cannot set these fields. */
  artifactGraph?: ArtifactGraph;
  artifactPart?: { key: string; owner?: string; node: number; section: string; part: number };
  content: JsonValue;
  /** Sparse replacement parts relative to an earlier durable message event. */
  messagePatch?: { baseId: number; partsLength: number; indices: number[] };
  conversationId?: string;
  runId?: string;
  parentId?: string | null;
  stopReason?: JsonValue;
  usage?: JsonValue;
  providerMetadata?: JsonValue;
  toolCallId?: string;
  input?: JsonValue;
  output?: JsonValue;
  error?: JsonValue;
  retry?: JsonValue;
  abort?: JsonValue;
  latencyMs?: number;
};

export type LogRecord = {
  type: string;
  content?: unknown;
  conversationId?: string;
  runId?: string;
  parentId?: string | null;
  toolCallId?: string;
  /** Recovery already has the durable, phase-qualified ID. Do not qualify it again. */
  toolCallIdCanonical?: boolean;
  stopReason?: unknown;
  usage?: unknown;
  providerMetadata?: unknown;
  input?: unknown;
  output?: unknown;
  error?: unknown;
  retry?: unknown;
  abort?: unknown;
  latencyMs?: number;
};

export type ConversationMessage = {
  id: string;
  role: "system" | "user" | "assistant";
  parts: unknown[];
  [key: string]: unknown;
};

type EventStore = {
  append(event: Omit<LogEvent, "id">): Promise<LogEvent>;
  supportsArtifactParts?: boolean;
  appendArtifactAnd?(artifact: Omit<LogEvent, "id">, terminal: Omit<LogEvent, "id">, link: "resultArtifactId", parts?: readonly Omit<LogEvent, "id">[]): Promise<{ artifact: LogEvent; terminal: LogEvent }>;
  appendPartitioned?(artifact: Omit<LogEvent, "id">, parts: readonly Omit<LogEvent, "id">[]): Promise<LogEvent>;
  artifactParts?(key: string, node: number, section?: string, first?: number, last?: number): Promise<LogEvent[]>;
  artifactBucketParts?(key: string, node: number, prefix: "i:" | "e:", first: number, last: number): Promise<LogEvent[]>;
  get?(id: number): Promise<LogEvent | undefined>;
  getMany?(ids: readonly number[]): Promise<Array<LogEvent | undefined>>;
  latestByType?(type: string): Promise<LogEvent | undefined>;
  appendMany?(events: readonly Omit<LogEvent, "id">[]): Promise<LogEvent[]>;
  all(): Promise<LogEvent[]>;
  byTypes?(types: readonly string[], conversationId?: string, afterId?: number, limit?: number): Promise<LogEvent[]>;
  diagnosticsByCapture?(conversationId: string, tabId: number, epoch: string, afterId: number): Promise<LogEvent[]>;
  terminalEvents?(events: readonly Omit<LogEvent, "id">[], afterId: number): Promise<LogEvent[]>;
  byRunTypes?(runIds: readonly string[], types: readonly string[], afterId?: number): Promise<LogEvent[]>;
  conversation?(conversationId: string, afterId?: number): Promise<LogEvent[]>;
  /** Legacy test capability; canonical runtime never invokes destructive clearing. */
  clear?(): Promise<void>;
};

const DB_NAME = "side-agent-runtime";
const DB_VERSION = 11;
const EVENT_STORE = "events";
const DIAGNOSTIC_INDEX_STORE = "diagnosticCaptureIndex";
const ARTIFACT_INDEX_STORE = "artifactPartIndex";
const CONVERSATION_INDEX = "conversationId";
const TYPE_INDEX = "type";
const CONVERSATION_TYPE_INDEX = "conversationType";
const RUN_TYPE_INDEX = "runType";
const RUN_TOOL_TYPE_INDEX = "runToolType";
const OBSOLETE_ID_INDEXES = ["typeId", "conversationTypeId", "runTypeId", "conversationIdId"] as const;
const SUMMARY_EVENT_TYPES = [
  "conversation.created",
  "conversation.selected",
  "conversation.title.updated",
  // Keep historical archive events readable without maintaining archive state.
  "conversation.archived",
  "conversation.unarchived",
  "conversation.submitted",
  "conversation.finished",
  "conversation.failed",
  "conversation.aborted",
  "conversation.deleted",
  "conversation.restored",
  "conversation.followup.queued",
  "conversation.followup.dispatched",
  "conversation.followup.removed",
  "model.title.started",
  "model.title.finished",
  "model.title.failed",
  "model.title.aborted",
] as const;
const RUN_EVENT_TYPES = ["conversation.submitted", "conversation.finished", "conversation.failed", "conversation.aborted"] as const;
const FOLLOWUP_EVENT_TYPES = [
  "conversation.followup.queued",
  "conversation.followup.dispatched",
  "conversation.followup.removed",
] as const;
const CONTEXT_EVENT_TYPES = ["context.compacted", "context.estimate.calibrated", "context.prompt.updated", "model.context.appended"] as const;

export function upgradeEventStore(db: IDBDatabase, transaction: IDBTransaction): void {
  const store = db.objectStoreNames.contains(EVENT_STORE)
    ? transaction.objectStore(EVENT_STORE)
    : db.createObjectStore(EVENT_STORE, { keyPath: "id", autoIncrement: true });
  if (!store.indexNames.contains(CONVERSATION_INDEX)) store.createIndex(CONVERSATION_INDEX, CONVERSATION_INDEX);
  if (!store.indexNames.contains(TYPE_INDEX)) store.createIndex(TYPE_INDEX, TYPE_INDEX);
  if (!store.indexNames.contains(CONVERSATION_TYPE_INDEX)) {
    store.createIndex(CONVERSATION_TYPE_INDEX, [CONVERSATION_INDEX, TYPE_INDEX]);
  }
  if (!store.indexNames.contains(RUN_TYPE_INDEX)) store.createIndex(RUN_TYPE_INDEX, ["runId", TYPE_INDEX]);
  // Rebuildable from immutable events, including records written before this index existed.
  if (!store.indexNames.contains(RUN_TOOL_TYPE_INDEX)) store.createIndex(RUN_TOOL_TYPE_INDEX, ["runId", "toolCallId", TYPE_INDEX]);
  // Version 7 added four compound indexes over the append-only event payloads.
  // Rebuilding them could exhaust a Side Panel renderer when a development
  // profile had accumulated a large log. The existing indexes already order
  // duplicate keys by primary key, so cursor seeking provides the same range
  // reads without copying every historical event during an upgrade.
  for (const name of OBSOLETE_ID_INDEXES) if (store.indexNames.contains(name)) store.deleteIndex(name);
  // New captures are ephemeral and cannot survive an extension reload, so an
  // empty index is sufficient for old databases: no expensive backfill or
  // scan of historical event payloads is needed during the upgrade.
  if (!db.objectStoreNames.contains(DIAGNOSTIC_INDEX_STORE)) db.createObjectStore(DIAGNOSTIC_INDEX_STORE);
  if (!db.objectStoreNames.contains(ARTIFACT_INDEX_STORE)) db.createObjectStore(ARTIFACT_INDEX_STORE);
}

function requestResult<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("IndexedDB request failed"));
  });
}

function transactionDone(transaction: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error ?? new Error("IndexedDB transaction failed"));
    transaction.onabort = () => reject(transaction.error ?? new Error("IndexedDB transaction aborted"));
  });
}

function indexEventsAfter(index: IDBIndex, key: IDBValidKey, afterId: number, limit = Infinity): Promise<LogEvent[]> {
  return new Promise((resolve, reject) => {
    const events: LogEvent[] = [];
    const request = index.openCursor(IDBKeyRange.only(key));
    let sought = afterId < 0;
    request.onerror = () => reject(request.error ?? new Error("IndexedDB cursor failed"));
    request.onsuccess = () => {
      const cursor = request.result;
      if (!cursor) { resolve(events); return; }
      if (!sought) {
        sought = true;
        const nextId = Math.min(Number.MAX_SAFE_INTEGER, afterId + 1);
        if (Number(cursor.primaryKey) < nextId) {
          cursor.continuePrimaryKey(key, nextId);
          return;
        }
      }
      if (Number(cursor.primaryKey) > afterId) events.push(cursor.value as LogEvent);
      if (events.length >= limit) { resolve(events); return; }
      cursor.continue();
    };
  });
}

/** Existing bucket sections use unpadded decimal strings. Find the next
 * numeric bucket in the interval in IndexedDB's lexicographic key order. */
export function nextArtifactBucket(after: string | undefined, first: number, last: number): string | undefined {
  let best: string | undefined;
  for (let length = 1; length <= String(last).length; length++) {
    const min = Math.max(first, length === 1 ? 0 : 10 ** (length - 1));
    const max = Math.min(last, 10 ** length - 1);
    if (min > max) continue;
    let candidate = min;
    if (after !== undefined) {
      const bound = length <= after.length ? Number(after.slice(0, length)) + 1 : Number(after.padEnd(length, "0"));
      candidate = Math.max(candidate, bound);
    }
    if (!Number.isSafeInteger(candidate) || candidate > max) continue;
    const text = String(candidate);
    if ((after === undefined || text > after) && (best === undefined || text < best)) best = text;
  }
  return best;
}

export class IndexedDbEventStore implements EventStore {
  readonly supportsArtifactParts = true;
  private dbPromise?: Promise<IDBDatabase>;
  private artifactPartLoads = new Map<string, Promise<LogEvent[]>>();

  private open(): Promise<IDBDatabase> {
    if (this.dbPromise) return this.dbPromise;
    if (typeof indexedDB === "undefined") return Promise.reject(new Error("IndexedDB is unavailable"));

    this.dbPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => upgradeEventStore(request.result, request.transaction!);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error ?? new Error("IndexedDB open failed"));
    });
    return this.dbPromise;
  }

  async append(event: Omit<LogEvent, "id">): Promise<LogEvent> {
    return (await this.appendMany([event]))[0]!;
  }

  async appendPartitioned(artifact: Omit<LogEvent, "id">, parts: readonly Omit<LogEvent, "id">[]): Promise<LogEvent> {
    return (await this.writeArtifact(artifact, parts)).artifact;
  }

  async appendArtifactAnd(artifact: Omit<LogEvent, "id">, terminal: Omit<LogEvent, "id">, link: "resultArtifactId", parts: readonly Omit<LogEvent, "id">[] = []): Promise<{ artifact: LogEvent; terminal: LogEvent }> {
    const result = await this.writeArtifact(artifact, parts, terminal, link);
    return { artifact: result.artifact, terminal: result.terminal! };
  }

  private async writeArtifact(artifact: Omit<LogEvent, "id">, parts: readonly Omit<LogEvent, "id">[], terminal?: Omit<LogEvent, "id">, link?: "resultArtifactId"): Promise<{ artifact: LogEvent; terminal?: LogEvent }> {
    const db = await this.open();
    const transaction = db.transaction([EVENT_STORE, ARTIFACT_INDEX_STORE], "readwrite");
    const done = transactionDone(transaction);
    const store = transaction.objectStore(EVENT_STORE);
    try {
      const index = transaction.objectStore(ARTIFACT_INDEX_STORE);
      // Limit simultaneously queued structured clones while keeping every part,
      // its derived index entry, and the terminal in one atomic transaction.
      for (let offset = 0; offset < parts.length; offset += 64) {
        const batch = parts.slice(offset, offset + 64);
        const partIds = await Promise.all(batch.map((part) => requestResult<IDBValidKey>(store.add(part))));
        for (const [position, part] of batch.entries()) {
          const coordinates = part.artifactPart;
          if (!coordinates || coordinates.key !== artifact.artifactGraph?.key) throw new Error("Invalid artifact part coordinates");
          index.add(Number(partIds[position]), [coordinates.key, coordinates.node, coordinates.section, coordinates.part]);
        }
      }
      const artifactId = Number(await requestResult<IDBValidKey>(store.add(artifact)));
      let linked: Omit<LogEvent, "id"> | undefined, terminalId: number | undefined;
      if (terminal && link) {
        const content = fromLogValue(terminal.content, terminal.valueEncoding);
        if (!content || typeof content !== "object" || Array.isArray(content)) throw new Error("Job terminal content must be an object");
        linked = { ...terminal, content: toLogValue({ ...content, [link]: artifactId }, undefined, 5) };
        terminalId = Number(await requestResult<IDBValidKey>(store.add(linked)));
      }
      await done;
      return { artifact: { ...artifact, id: artifactId }, ...(linked && terminalId !== undefined ? { terminal: { ...linked, id: terminalId } } : {}) };
    } catch (error) {
      try { transaction.abort(); } catch { /* Transaction may already have aborted. */ }
      await done.catch(() => undefined);
      throw error;
    }
  }

  async artifactParts(key: string, node: number, section?: string, first?: number, last?: number): Promise<LogEvent[]> {
    const query = JSON.stringify([key, node, section ?? null, first ?? null, last ?? null]);
    let task = this.artifactPartLoads.get(query);
    if (!task) {
      task = this.readArtifactParts(key, node, section, first, last);
      this.artifactPartLoads.set(query, task);
    }
    try { return await task; }
    finally { if (this.artifactPartLoads.get(query) === task) this.artifactPartLoads.delete(query); }
  }

  private async readArtifactParts(key: string, node: number, section?: string, first?: number, last?: number): Promise<LogEvent[]> {
    const db = await this.open();
    const transaction = db.transaction([EVENT_STORE, ARTIFACT_INDEX_STORE], "readonly");
    const done = transactionDone(transaction);
    const lower = [key, node, section ?? "", first ?? 0];
    const upper = [key, node, section ?? "\uffff", last ?? Number.MAX_SAFE_INTEGER];
    const ids = await requestResult<IDBValidKey[]>(transaction.objectStore(ARTIFACT_INDEX_STORE).getAll(IDBKeyRange.bound(lower, upper)));
    const store = transaction.objectStore(EVENT_STORE);
    const values = await Promise.all(ids.map((id) => requestResult<LogEvent | undefined>(store.get(id))));
    await done;
    if (values.some((value) => !value)) throw new Error("Artifact index points to a missing event");
    return values as LogEvent[];
  }

  async artifactBucketParts(key: string, node: number, prefix: "i:" | "e:", first: number, last: number): Promise<LogEvent[]> {
    const query = JSON.stringify(["buckets", key, node, prefix, first, last]);
    let task = this.artifactPartLoads.get(query);
    if (!task) {
      task = this.readArtifactBucketParts(key, node, prefix, first, last);
      this.artifactPartLoads.set(query, task);
    }
    try { return await task; }
    finally { if (this.artifactPartLoads.get(query) === task) this.artifactPartLoads.delete(query); }
  }

  private async readArtifactBucketParts(key: string, node: number, prefix: "i:" | "e:", first: number, last: number): Promise<LogEvent[]> {
    if (!Number.isSafeInteger(first) || !Number.isSafeInteger(last) || first < 0 || last < first) throw new Error("Invalid artifact bucket range");
    const initial = nextArtifactBucket(undefined, first, last);
    if (initial === undefined) return [];
    const db = await this.open();
    const transaction = db.transaction([EVENT_STORE, ARTIFACT_INDEX_STORE], "readonly");
    const done = transactionDone(transaction);
    const index = transaction.objectStore(ARTIFACT_INDEX_STORE);
    const ids = await new Promise<IDBValidKey[]>((resolve, reject) => {
      const found: IDBValidKey[] = [];
      const request = index.openCursor(IDBKeyRange.bound([key, node, prefix + initial, 0], [key, node, prefix + "\uffff", Number.MAX_SAFE_INTEGER]));
      request.onerror = () => reject(request.error ?? new Error("Artifact index cursor failed"));
      request.onsuccess = () => {
        const cursor = request.result;
        if (!cursor) { resolve(found); return; }
        const section = (cursor.key as IDBValidKey[])[2];
        if (typeof section !== "string" || !section.startsWith(prefix)) { resolve(found); return; }
        const suffix = section.slice(prefix.length);
        const bucket = Number(suffix);
        if (!/^(?:0|[1-9]\d*)$/.test(suffix) || !Number.isSafeInteger(bucket)) { cursor.continue(); return; }
        if (bucket >= first && bucket <= last) { found.push(cursor.value as IDBValidKey); cursor.continue(); return; }
        const next = nextArtifactBucket(suffix, first, last);
        if (next === undefined) { resolve(found); return; }
        cursor.continue([key, node, prefix + next, 0]);
      };
    });
    const store = transaction.objectStore(EVENT_STORE);
    const values = await Promise.all(ids.map((id) => requestResult<LogEvent | undefined>(store.get(id))));
    await done;
    if (values.some((value) => !value)) throw new Error("Artifact index points to a missing event");
    return values as LogEvent[];
  }

  async get(id: number): Promise<LogEvent | undefined> {
    const db = await this.open();
    const transaction = db.transaction(EVENT_STORE, "readonly");
    const event = await requestResult<LogEvent | undefined>(transaction.objectStore(EVENT_STORE).get(id));
    await transactionDone(transaction);
    return event;
  }

  async getMany(ids: readonly number[]): Promise<Array<LogEvent | undefined>> {
    if (!ids.length) return [];
    const db = await this.open();
    const transaction = db.transaction(EVENT_STORE, "readonly");
    const done = transactionDone(transaction);
    const store = transaction.objectStore(EVENT_STORE);
    const events = await Promise.all(ids.map((id) => requestResult<LogEvent | undefined>(store.get(id))));
    await done;
    return events;
  }

  async latestByType(type: string): Promise<LogEvent | undefined> {
    const db = await this.open();
    const transaction = db.transaction(EVENT_STORE, "readonly");
    const done = transactionDone(transaction);
    const cursor = await requestResult(transaction.objectStore(EVENT_STORE).index(TYPE_INDEX).openCursor(IDBKeyRange.only(type), "prev"));
    const event = cursor?.value as LogEvent | undefined;
    await done;
    return event;
  }

  async appendMany(events: readonly Omit<LogEvent, "id">[]): Promise<LogEvent[]> {
    const db = await this.open();
    const transaction = db.transaction([EVENT_STORE, DIAGNOSTIC_INDEX_STORE], "readwrite");
    const done = transactionDone(transaction);
    const store = transaction.objectStore(EVENT_STORE);
    try {
      const ids = await Promise.all(events.map((event) => requestResult<IDBValidKey>(store.add(event))));
      const diagnosticIndex = transaction.objectStore(DIAGNOSTIC_INDEX_STORE);
      for (const [index, event] of events.entries()) {
        const decoded = fromLogValue(event.content, event.valueEncoding);
        const content = decoded && typeof decoded === "object" && !Array.isArray(decoded) ? decoded as Record<string, unknown> : undefined;
        if (event.type === "browser.diagnostic" && typeof event.conversationId === "string" && typeof content?.tabId === "number" && typeof content.epoch === "string") {
          const id = Number(ids[index]);
          diagnosticIndex.put(id, [event.conversationId, content.tabId, content.epoch, id]);
        }
      }
      await done;
      return events.map((event, index) => ({ ...event, id: Number(ids[index]) }));
    } catch (error) {
      // A synchronous key/clone error must not leave canonical events written
      // without their corresponding diagnostic index entries.
      try { transaction.abort(); } catch { /* Transaction may already have aborted. */ }
      await done.catch(() => undefined);
      throw error;
    }
  }

  async all(): Promise<LogEvent[]> {
    const db = await this.open();
    const transaction = db.transaction(EVENT_STORE, "readonly");
    const events = await requestResult<LogEvent[]>(transaction.objectStore(EVENT_STORE).getAll());
    await transactionDone(transaction);
    return events.sort((left, right) => left.id - right.id);
  }

  async byTypes(types: readonly string[], conversationId?: string, afterId = -1, limit = Infinity): Promise<LogEvent[]> {
    const db = await this.open();
    const transaction = db.transaction(EVENT_STORE, "readonly");
    const done = transactionDone(transaction);
    const index = transaction.objectStore(EVENT_STORE).index(conversationId ? CONVERSATION_TYPE_INDEX : TYPE_INDEX);
    const batches = await Promise.all(types.map((type) => indexEventsAfter(index, conversationId ? [conversationId, type] : type, afterId, limit)));
    await done;
    return batches.flat().sort((left, right) => left.id - right.id).slice(0, limit);
  }

  async byRunTypes(runIds: readonly string[], types: readonly string[], afterId = -1): Promise<LogEvent[]> {
    const db = await this.open();
    const transaction = db.transaction(EVENT_STORE, "readonly");
    const done = transactionDone(transaction);
    const index = transaction.objectStore(EVENT_STORE).index(RUN_TYPE_INDEX);
    const batches = await Promise.all(runIds.flatMap((runId) => types.map((type) =>
      indexEventsAfter(index, [runId, type], afterId))));
    await done;
    return batches.flat().sort((left, right) => left.id - right.id);
  }

  async terminalEvents(events: readonly Omit<LogEvent, "id">[], afterId: number): Promise<LogEvent[]> {
    const db = await this.open();
    const transaction = db.transaction(EVENT_STORE, "readonly");
    const done = transactionDone(transaction);
    const store = transaction.objectStore(EVENT_STORE);
    const keys = new Set(events.flatMap((event) => { const key = terminalKey(event); return key ? [key] : []; }));
    const batches = await Promise.all(events.filter((event) => terminalKey(event)).flatMap((event) =>
      event.type.startsWith("tool.")
        ? ["tool.finished", "tool.failed"].map((type) => indexEventsAfter(store.index(RUN_TOOL_TYPE_INDEX), [event.runId!, event.toolCallId!, type], afterId))
        : ["conversation.finished", "conversation.failed", "conversation.aborted"].map((type) => indexEventsAfter(store.index(RUN_TYPE_INDEX), [event.runId!, type], afterId))));
    await done;
    return batches.flat().filter((event) => keys.has(terminalKey(event)!)).sort((a, b) => a.id - b.id);
  }

  async diagnosticsByCapture(conversationId: string, tabId: number, epoch: string, afterId: number): Promise<LogEvent[]> {
    const db = await this.open();
    const transaction = db.transaction([EVENT_STORE, DIAGNOSTIC_INDEX_STORE], "readonly");
    const done = transactionDone(transaction);
    const range = IDBKeyRange.bound([conversationId, tabId, epoch, Math.max(0, afterId + 1)], [conversationId, tabId, epoch, Number.MAX_SAFE_INTEGER]);
    const ids = await requestResult<number[]>(transaction.objectStore(DIAGNOSTIC_INDEX_STORE).getAll(range));
    const events = await Promise.all(ids.map((id) => requestResult<LogEvent | undefined>(transaction.objectStore(EVENT_STORE).get(id))));
    await done;
    return events.filter((event): event is LogEvent => Boolean(event));
  }

  async conversation(conversationId: string, afterId = -1): Promise<LogEvent[]> {
    const db = await this.open();
    const transaction = db.transaction(EVENT_STORE, "readonly");
    const events = await indexEventsAfter(transaction.objectStore(EVENT_STORE).index(CONVERSATION_INDEX), conversationId, afterId);
    await transactionDone(transaction);
    return events.sort((left, right) => left.id - right.id);
  }

}

let sharedStore: EventStore | undefined;
const TERMINAL_EVENT_TYPES = ["tool.finished", "tool.failed", "conversation.finished", "conversation.failed", "conversation.aborted"];
let localTerminalWrite: Promise<unknown> = Promise.resolve();
let localJobStateWrite: Promise<unknown> = Promise.resolve();

function terminalKey(event: Pick<LogEvent, "type" | "runId" | "toolCallId" | "content" | "valueEncoding">): string | undefined {
  if (!event.runId || !TERMINAL_EVENT_TYPES.includes(event.type)) return undefined;
  if (event.type.startsWith("conversation.")) return JSON.stringify(["run", event.runId]);
  if (!event.toolCallId) return undefined;
  const content = fromLogValue(event.content, event.valueEncoding) as { callId?: unknown } | null;
  return JSON.stringify(["tool", event.runId, content?.callId ?? "", event.toolCallId]);
}

function withTerminalWriteLock<T>(write: () => Promise<T>): Promise<T> {
  if (typeof navigator !== "undefined" && navigator.locks) return navigator.locks.request("surf-wax:terminal-log", write);
  // Tests and environments without Web Locks still serialize all local writers.
  const task = localTerminalWrite.then(write, write);
  localTerminalWrite = task.catch(() => undefined);
  return task;
}

function withJobStateWriteLock<T>(write: () => Promise<T>, allowLocalFallback: boolean): Promise<T> {
  if (typeof navigator !== "undefined" && navigator.locks) return navigator.locks.request("surf-wax:job-state-log", write);
  if (!allowLocalFallback || (typeof chrome !== "undefined" && Boolean(chrome.runtime?.id))) {
    return Promise.reject(new Error("Web Locks are required for cross-context job state and log clearing"));
  }
  const task = localJobStateWrite.then(write, write);
  localJobStateWrite = task.catch(() => undefined);
  return task;
}

function getEventStore(): EventStore {
  sharedStore ??= new IndexedDbEventStore();
  return sharedStore;
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = "";
  for (let index = 0; index < bytes.length; index += 0x8000) {
    binary += String.fromCharCode(...bytes.subarray(index, index + 0x8000));
  }
  return btoa(binary);
}

const RESERVED_LOG_TYPES = new Set(["undefined", "number", "bigint", "symbol", "function", "circular-reference", "error", "date", "array-buffer", "typed-array", "map", "set", "escaped-object", "sparse-array"]);

export function toLogValue(value: unknown, active = new WeakSet<object>(), version?: 2 | 3 | 4 | 5): JsonValue {
  if (value === null) return null;
  if (value === undefined) return { $type: "undefined", value: null };
  if (typeof value === "string" || typeof value === "boolean") return value;
  if (typeof value === "number") return version !== undefined && Object.is(value, -0) ? { $type: "number", value: "-0" }
    : Number.isFinite(value) ? value : { $type: "number", value: String(value) };
  if (typeof value === "bigint") return { $type: "bigint", value: value.toString() };
  if (typeof value === "symbol") return { $type: "symbol", value: String(value) };
  if (typeof value === "function") return { $type: "function", value: value.name || "anonymous" };
  if (active.has(value)) return { $type: "circular-reference", value: "$" };

  active.add(value);
  try {
    if (value instanceof Error) {
      const details: Record<string, JsonValue> = { $type: "error", name: value.name, message: value.message, stack: value.stack ?? null };
      for (const key of ["statusCode", "status", "responseBody", "responseText", "headers", "requestId", "data", "cause", "providerMetadata"]) {
        try {
          const item = (value as unknown as Record<string, unknown>)[key];
          if (item !== undefined) details[key] = item instanceof Headers ? toLogValue(Object.fromEntries(item.entries()), active, version) : toLogValue(item, active, version);
        } catch { /* Ignore throwing provider error getters. */ }
      }
      for (const [key, item] of Object.entries(value)) if (!(key in details)) details[key] = toLogValue(item, active, version);
      return details;
    }
    if (isDate(value)) return { $type: "date", value: Number.isNaN(dateValue(value)) ? "Invalid Date" : dateISOString(value) };
    if (version !== undefined && version >= 4 && isRegExp(value)) return { $type: "regexp", source: regexpSource(value), flags: regexpFlagString(value), lastIndex: toLogValue(value.lastIndex, active, version) };
    if (isArrayBuffer(value)) return { $type: "array-buffer", byteLength: arrayBufferLength(value), base64: bytesToBase64(new Uint8Array(value)) };
    if (ArrayBuffer.isView(value)) {
      const layout = viewLayout(value);
      const bytes = new Uint8Array(layout.buffer, layout.byteOffset, layout.byteLength);
      return { $type: "typed-array", name: arrayViewName(value), byteLength: layout.byteLength, base64: bytesToBase64(bytes) };
    }
    if (isMap(value)) return { $type: "map", entries: Array.from(mapEntries(value), ([key, item]) => [toLogValue(key, active, version), toLogValue(item, active, version)]) };
    if (isSet(value)) return { $type: "set", values: Array.from(setValues(value), (item) => toLogValue(item, active, version)) };
    if (Array.isArray(value)) {
      if (version !== undefined && version >= 3 && value.length >= 32768) {
        const keys = Object.getOwnPropertyNames(value).filter((key) => /^(?:0|[1-9]\d*)$/.test(key) && Number(key) < value.length);
        if (keys.length < value.length * 0.8) return { $type: "sparse-array", length: value.length,
          entries: keys.map((key) => [Number(key), toLogValue(value[Number(key)], active, version)]) };
      }
      const copy: JsonValue[] = new Array(value.length);
      for (let index = 0; index < value.length; index++) if (Object.hasOwn(value, index)) copy[index] = toLogValue(value[index], active, version);
      return copy;
    }

    const entries = Object.entries(value).map(([key, item]) => [key, toLogValue(item, active, version)] as const);
    const tag = entries.find(([key]) => key === "$type")?.[1];
    if (version !== undefined && typeof tag === "string" && (RESERVED_LOG_TYPES.has(tag) || version >= 4 && tag === "regexp" || version >= 5 && tag === "object-graph"))
      return { $type: "escaped-object", entries: entries.map(([key, item]) => [key, item]) };
    return Object.fromEntries(entries);
  } finally {
    active.delete(value);
  }
}

export function fromLogValue(value: unknown, version?: 2 | 3 | 4 | 5): unknown {
  if (Array.isArray(value)) return value.map((item) => fromLogValue(item, version));
  if (!value || typeof value !== "object") return value;
  const record = value as Record<string, unknown>;
  if (version !== undefined && record.$type === "escaped-object") {
    if (Object.keys(record).length !== 2 || !Array.isArray(record.entries)
      || record.entries.some((entry) => !Array.isArray(entry) || entry.length !== 2 || typeof entry[0] !== "string")
      || new Set(record.entries.map((entry) => entry[0])).size !== record.entries.length)
      throw new Error("Invalid escaped log object");
    return Object.fromEntries(record.entries.map(([key, item]) => [key, fromLogValue(item, version)]));
  }
  if (version !== undefined && version >= 3 && record.$type === "sparse-array") {
    if (Object.keys(record).length !== 3 || !Number.isSafeInteger(record.length) || Number(record.length) < 0 || Number(record.length) > 0xffff_ffff || !Array.isArray(record.entries)) throw new Error("Invalid encoded sparse array");
    const result = new Array(Number(record.length));
    let previous = -1;
    for (const entry of record.entries) {
      if (!Array.isArray(entry) || entry.length !== 2 || !Number.isSafeInteger(entry[0]) || entry[0] <= previous || entry[0] >= result.length) throw new Error("Invalid encoded sparse array entry");
      previous = entry[0]; result[entry[0]] = fromLogValue(entry[1], version);
    }
    return result;
  }
  if (version !== undefined && Object.keys(record).length === 2 && record.$type === "number") {
    if (record.value === "NaN") return NaN;
    if (record.value === "Infinity") return Infinity;
    if (record.value === "-Infinity") return -Infinity;
    if (record.value === "-0") return -0;
    throw new Error("Invalid encoded log number");
  }
  if (version !== undefined && Object.keys(record).length === 2 && record.$type === "bigint") {
    if (typeof record.value !== "string" || !/^-?(?:0|[1-9]\d*)$/.test(record.value)) throw new Error("Invalid encoded log bigint");
    return BigInt(record.value);
  }
  if (version !== undefined && record.$type === "date") {
    if (Object.keys(record).length !== 2 || typeof record.value !== "string") throw new Error("Invalid encoded log date");
    if (record.value === "Invalid Date") return new Date(NaN);
    const date = new Date(record.value);
    if (!Number.isFinite(date.getTime()) || date.toISOString() !== record.value) throw new Error("Invalid encoded log date");
    return date;
  }
  if (version !== undefined && version >= 4 && record.$type === "regexp") {
    if (Object.keys(record).length !== 4 || typeof record.source !== "string" || typeof record.flags !== "string" || !Object.hasOwn(record, "lastIndex")) throw new Error("Invalid encoded log regexp");
    const regexp = new RegExp(record.source, record.flags);
    regexp.lastIndex = fromLogValue(record.lastIndex, version) as number;
    return regexp;
  }
  if (version === 5 && record.$type === "object-graph") return decodeLogGraph(record);
  if (version !== undefined && (record.$type === "array-buffer" || record.$type === "typed-array")) {
    const view = record.$type === "typed-array";
    if (Object.keys(record).length !== (view ? 4 : 3) || typeof record.base64 !== "string" || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(record.base64)
      || !Number.isSafeInteger(record.byteLength) || Number(record.byteLength) < 0 || (view && typeof record.name !== "string")) throw new Error("Invalid encoded log buffer");
    const decoded = atob(record.base64);
    if (decoded.length !== record.byteLength) throw new Error("Invalid encoded log buffer length");
    const bytes = Uint8Array.from(decoded, (character) => character.charCodeAt(0));
    if (!view) return bytes.buffer;
    if (record.name === "DataView") return new DataView(bytes.buffer);
    const constructors: Record<string, new (buffer: ArrayBuffer) => ArrayBufferView> = {
      Int8Array, Uint8Array, Uint8ClampedArray, Int16Array, Uint16Array, Int32Array, Uint32Array,
      Float32Array, Float64Array, BigInt64Array, BigUint64Array,
      ...("Float16Array" in globalThis ? { Float16Array: (globalThis as any).Float16Array } : {}),
    };
    const constructor = constructors[record.name as string];
    if (!Object.hasOwn(constructors, record.name as string) || !constructor) throw new Error("Invalid encoded log buffer type");
    try { return new constructor(bytes.buffer); } catch { throw new Error("Invalid encoded log buffer alignment"); }
  }
  if (version !== undefined && record.$type === "map") {
    if (Object.keys(record).length !== 2 || !Array.isArray(record.entries) || record.entries.some((entry) => !Array.isArray(entry) || entry.length !== 2)) throw new Error("Invalid encoded log map");
    return new Map(record.entries.map(([key, item]) => [fromLogValue(key, version), fromLogValue(item, version)]));
  }
  if (version !== undefined && record.$type === "set") {
    if (Object.keys(record).length !== 2 || !Array.isArray(record.values)) throw new Error("Invalid encoded log set");
    return new Set(record.values.map((item) => fromLogValue(item, version)));
  }
  if (record.$type === "undefined" && record.value === null && Object.keys(record).length === 2) return undefined;
  return Object.fromEntries(Object.entries(record).map(([key, item]) => [key, fromLogValue(item, version)]));
}

/** Keep ordinary JSON byte-for-byte stable; encode JavaScript-only numbers without collisions. */
export function stringifyLogSafe(value: unknown, space?: number): string | undefined {
  let hasSpecial = false;
  const ordinary = JSON.stringify(value, (_key, item) => {
    if (typeof item === "bigint" || typeof item === "number" && (!Number.isFinite(item) || Object.is(item, -0))) {
      hasSpecial = true; return null;
    }
    return item;
  }, space);
  if (!hasSpecial) return ordinary;
  return `[Surf Wax log value encoding v2]\n${JSON.stringify(toLogValue(value, undefined, 2), null, space)}`;
}

const ARTIFACT_CACHE_BYTES = 8 * 1024 * 1024;

/** Conservative retained-size estimate; large holey arrays may still have dense backing storage. */
function artifactRetainedBytes(value: unknown, limit = ARTIFACT_CACHE_BYTES): number {
  let used = 0;
  const seen = new WeakSet<object>();
  const visitProperties = (item: object, depth: number) => {
    for (const key of graphProperties(item)) {
      used += 64 + key.length * 2;
      visit((item as any)[key], depth + 1);
      if (used > limit) break;
    }
  };
  const visit = (item: unknown, depth: number): void => {
    if (used > limit) return;
    if (depth > 100) { used = Infinity; return; }
    if (typeof item === "string") { used += 64 + item.length * 2; return; }
    if (typeof item === "bigint") { used += 64 + item.toString().length * 2; return; }
    if (!item || typeof item !== "object") { used += 16; return; }
    if (seen.has(item)) return;
    seen.add(item);
    used += 128;
    if (isArrayBuffer(item)) { used += arrayBufferLength(item); if (used <= limit) visitProperties(item, depth); return; }
    if (ArrayBuffer.isView(item)) { visit(viewLayout(item).buffer, depth + 1); if (used <= limit) visitProperties(item, depth); return; }
    if (isDate(item)) { visitProperties(item, depth); return; }
    if (isRegExp(item)) { used += 64 + (regexpSource(item).length + regexpFlagString(item).length) * 2; visit(item.lastIndex, depth + 1); visitProperties(item, depth); return; }
    if (item instanceof Error) { visit(item.name, depth + 1); visit(item.message, depth + 1); visit(item.stack, depth + 1); if (Object.hasOwn(item, "cause")) visit((item as any).cause, depth + 1); visitProperties(item, depth); return; }
    if (Array.isArray(item)) {
      used += item.length * 8;
      if (used > limit) return;
    }
    if (isMap(item)) {
      for (const [key, entry] of mapEntries(item)) { used += 64; visit(key, depth + 1); visit(entry, depth + 1); if (used > limit) break; }
      if (used <= limit) visitProperties(item, depth);
      return;
    }
    if (isSet(item)) {
      for (const entry of setValues(item)) { used += 48; visit(entry, depth + 1); if (used > limit) break; }
      if (used <= limit) visitProperties(item, depth);
      return;
    }
    for (const key in item) if (Object.hasOwn(item, key)) {
      used += 64 + key.length * 2;
      visit((item as Record<string, unknown>)[key], depth + 1);
      if (used > limit) break;
    }
  };
  visit(value, 0);
  return used;
}

/** Never expose the mutable decoded cache. Preserve sparse holes and native values. */
function cloneArtifactValue(value: unknown, seen = new WeakMap<object, unknown>()): unknown {
  if (!value || typeof value !== "object") return value;
  if (seen.has(value)) return seen.get(value);
  const copyProperties = (target: any) => { for (const key of graphProperties(value)) Object.defineProperty(target, key, { value: cloneArtifactValue((value as any)[key], seen), enumerable: true, configurable: true, writable: true }); return target; };
  if (isDate(value)) { const result = new Date(dateValue(value)); seen.set(value, result); return copyProperties(result); }
  const copyBuffer = (source: ArrayBuffer) => { const result = new ArrayBuffer(arrayBufferLength(source)); new Uint8Array(result).set(new Uint8Array(source)); return result; };
  if (isArrayBuffer(value)) { const result = copyBuffer(value); seen.set(value, result); return copyProperties(result); }
  if (ArrayBuffer.isView(value)) {
    const layout = viewLayout(value); const source = layout.buffer;
    const hadBuffer = seen.has(source);
    const buffer = hadBuffer ? seen.get(source) as ArrayBuffer : copyBuffer(source);
    if (!hadBuffer) seen.set(source, buffer);
    const result = createArrayView(arrayViewName(value), buffer, layout.byteOffset, layout.length);
    seen.set(value, result);
    if (!hadBuffer) for (const key of graphProperties(source)) Object.defineProperty(buffer, key, { value: cloneArtifactValue((source as any)[key], seen), enumerable: true, configurable: true, writable: true });
    return copyProperties(result);
  }
  if (isRegExp(value)) {
    const result = new RegExp(regexpSource(value), regexpFlagString(value)); seen.set(value, result);
    result.lastIndex = cloneArtifactValue(value.lastIndex, seen) as number;
    return copyProperties(result);
  }
  if (isMap(value)) {
    const result = new Map(); seen.set(value, result);
    for (const [key, entry] of mapEntries(value)) result.set(cloneArtifactValue(key, seen), cloneArtifactValue(entry, seen));
    return copyProperties(result);
  }
  if (isSet(value)) {
    const result = new Set(); seen.set(value, result);
    for (const entry of setValues(value)) result.add(cloneArtifactValue(entry, seen));
    return copyProperties(result);
  }
  if (value instanceof Error) {
    const constructor = [Error, TypeError, RangeError, SyntaxError, ReferenceError, EvalError, URIError].find((kind) => Object.getPrototypeOf(value) === kind.prototype);
    if (!constructor) throw new Error("Cannot clone this Error subtype from a native object graph");
    const result = new constructor(); seen.set(value, result);
    result.name = cloneArtifactValue(value.name, seen) as string; result.message = cloneArtifactValue(value.message, seen) as string;
    result.stack = cloneArtifactValue(value.stack, seen) as string | undefined;
    if (Object.hasOwn(value, "cause")) Object.defineProperty(result, "cause", { value: cloneArtifactValue((value as any).cause, seen), enumerable: Object.prototype.propertyIsEnumerable.call(value, "cause"), configurable: true, writable: true });
    for (const key of graphProperties(value)) if (key !== "cause") Object.defineProperty(result, key, { value: cloneArtifactValue((value as any)[key], seen), enumerable: true, configurable: true, writable: true });
    return result;
  }
  const result: any = Array.isArray(value) ? new Array(value.length) : Object.getPrototypeOf(value) === null ? Object.create(null) : {};
  seen.set(value, result);
  for (const key in value) if (Object.hasOwn(value, key))
    Object.defineProperty(result, key, { value: cloneArtifactValue((value as any)[key], seen), enumerable: true, configurable: true, writable: true });
  return result;
}

export function isConversationMessage(value: unknown): value is ConversationMessage {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const message = value as Partial<ConversationMessage>;
  return typeof message.id === "string"
    && (message.role === "system" || message.role === "user" || message.role === "assistant")
    && Array.isArray(message.parts);
}

/** Message fields remain encoded so replay never decodes unchanged historical tool payloads. */
function encodedMessageFields(event: LogEvent): Record<string, JsonValue> | undefined {
  const value = event.content;
  if (!value || typeof value !== "object" || Array.isArray(value)) return undefined;
  if (event.valueEncoding !== undefined && value.$type === "escaped-object") {
    const entries = value.entries;
    if (Object.keys(value).length !== 2 || !Array.isArray(entries) || entries.some((entry) => !Array.isArray(entry) || entry.length !== 2 || typeof entry[0] !== "string")
      || new Set(entries.map((entry) => (entry as JsonValue[])[0])).size !== entries.length) return undefined;
    return Object.fromEntries(entries as [string, JsonValue][]);
  }
  return value;
}

/** Read message identity and shape without touching historical tool payloads. */
export function conversationMessageHeader(event: LogEvent): { id: string; valid: boolean } | undefined {
  if (event.type !== "conversation.message") return undefined;
  const fields = encodedMessageFields(event);
  if (typeof fields?.id !== "string") return undefined;
  const parts = fields.parts;
  const array = Array.isArray(parts) || event.valueEncoding !== undefined && event.valueEncoding >= 3
    && parts !== null && typeof parts === "object" && !Array.isArray(parts) && parts.$type === "sparse-array";
  return { id: fields.id, valid: (fields.role === "user" || fields.role === "assistant" || fields.role === "system") && array };
}

export type ConversationMessageEntry = {
  eventId: number; firstEventId: number; runId?: string; parentId: string | null; message: ConversationMessage;
};

/** Select revisions while still encoded; only each message's latest content needs decoding. */
export function projectConversationMessageEntries(events: readonly LogEvent[]): Map<string, ConversationMessageEntry> {
  const revisions = new Map<string, { event: LogEvent; firstEventId: number }>();
  for (const event of materializeMessageEvents(events)) {
    const header = conversationMessageHeader(event);
    if (!header?.valid) continue;
    revisions.set(header.id, { event, firstEventId: revisions.get(header.id)?.firstEventId ?? event.id });
  }
  const messages = new Map<string, ConversationMessageEntry>();
  for (const [id, { event, firstEventId }] of revisions) {
    const message = fromLogValue(event.content, event.valueEncoding);
    if (isConversationMessage(message)) messages.set(id, { eventId: event.id, firstEventId, runId: event.runId, parentId: event.parentId ?? null, message });
  }
  return messages;
}

/** Decode sparse durable message changes before any conversation projection sees them. */
export function materializeMessageEvents(events: readonly LogEvent[]): LogEvent[] {
  const messages = new Map<string, LogEvent>();
  return events.map((event) => {
    if (event.type !== "conversation.message") return event;
    const fields = encodedMessageFields(event);
    if (typeof fields?.id !== "string") return event;
    const key = JSON.stringify([event.conversationId, fields.id]);
    const materialized = materializeMessageEvent(event, messages.get(key));
    messages.set(key, materialized);
    return materialized;
  });
}

export function materializeMessageEvent(event: LogEvent, previous?: LogEvent): LogEvent {
  if (!event.messagePatch) return event;
  const patch = event.messagePatch;
  const message = encodedMessageFields(event);
  const before = previous && encodedMessageFields(previous);
  if (!previous || previous.id !== patch.baseId || previous.conversationId !== event.conversationId
    || !message || !before || before.id !== message.id || before.role !== message.role || !Array.isArray(message.parts) || !Array.isArray(before.parts)
    || !Number.isSafeInteger(patch.partsLength) || patch.partsLength < 0 || patch.indices.length !== message.parts.length
    || patch.indices.some((index, position) => !Number.isSafeInteger(index) || index < 0 || index >= patch.partsLength || position > 0 && index <= patch.indices[position - 1]!))
    throw new Error(`Conversation message change ${event.id} has no valid base; reload the conversation.`);
  // Only a historical encoding transition needs to normalize old parts.
  const oldParts = previous.valueEncoding === event.valueEncoding ? before.parts
    : toLogValue(fromLogValue(before.parts, previous.valueEncoding), undefined, event.valueEncoding) as JsonValue[];
  const parts = oldParts.slice(0, patch.partsLength);
  for (const [position, index] of patch.indices.entries()) parts[index] = message.parts[position]!;
  if (parts.length !== patch.partsLength || Array.from({ length: patch.partsLength }, (_, index) => index).some((index) => !Object.hasOwn(parts, index)))
    throw new Error(`Conversation message change ${event.id} is incomplete; reload the conversation.`);
  const { messagePatch: _patch, ...metadata } = event;
  const fields = { ...message, parts };
  return { ...metadata, content: event.valueEncoding !== undefined && event.content && typeof event.content === "object" && !Array.isArray(event.content) && event.content.$type === "escaped-object"
    ? { $type: "escaped-object", entries: Object.entries(fields) } : fields };
}

export type LogCommit = { lastId: number; conversationIds: string[]; external: boolean; cleared: boolean; types: string[] };
type CommitChannel = Pick<BroadcastChannel, "postMessage" | "close" | "addEventListener" | "removeEventListener">;
const localLogWriters = new WeakMap<EventStore, Set<EventLogger>>();

export function rebuildConversation(events: readonly LogEvent[]): ConversationMessage[] {
  return [...projectConversationMessageEntries(events).values()].sort((a, b) => a.firstEventId - b.firstEventId).map(({ message }) => message);
}

export type ConversationSummary = {
  id: string;
  title: string;
  runStatus: "idle" | "running" | "interrupted";
  createdAt: string;
  lastMessageAt: string;
};

export class ConversationListProjection {
  private conversations = new Map<string, ConversationSummary>();
  private deleted = new Set<string>();

  reset(events: readonly LogEvent[]): ConversationSummary[] {
    this.conversations.clear(); this.deleted.clear();
    for (const event of events) this.apply(event);
    return this.snapshot();
  }

  apply(event: LogEvent): boolean {
    if (!event.conversationId) return false;
    if (event.type === "conversation.created") {
      const content = fromLogValue(event.content, event.valueEncoding) as { title?: unknown };
      this.conversations.set(event.conversationId, { id: event.conversationId,
        title: typeof content?.title === "string" && content.title.trim() ? content.title : "新对话",
        runStatus: "idle", createdAt: event.timestamp, lastMessageAt: event.timestamp });
      return true;
    }
    const conversation = this.conversations.get(event.conversationId);
    if (!conversation) return false;
    if (event.type === "conversation.deleted") { this.deleted.add(event.conversationId); return true; }
    if (event.type === "conversation.restored") { this.deleted.delete(event.conversationId); return true; }
    if (event.type !== "conversation.selected") conversation.lastMessageAt = event.timestamp;
    if (event.type === "conversation.title.updated") {
      const content = fromLogValue(event.content, event.valueEncoding) as { title?: unknown };
      if (typeof content?.title === "string" && content.title.trim()) conversation.title = content.title.trim();
    }
    if (event.type === "conversation.submitted") conversation.runStatus = "running";
    if (event.type === "conversation.finished") conversation.runStatus = "idle";
    if (event.type === "conversation.aborted" || event.type === "conversation.failed") conversation.runStatus = "interrupted";
    return true;
  }

  snapshot(): ConversationSummary[] {
    return [...this.conversations.values()].filter(({ id }) => !this.deleted.has(id))
      .sort((left, right) => right.lastMessageAt.localeCompare(left.lastMessageAt));
  }
}

export function rebuildConversationList(events: readonly LogEvent[]): ConversationSummary[] {
  return new ConversationListProjection().reset(events);
}

export function selectedConversationId(events: readonly LogEvent[]): string | undefined {
  const ids = new Set(rebuildConversationList(events).map(({ id }) => id));
  return [...events].reverse().find((event) => event.type === "conversation.selected" && event.conversationId && ids.has(event.conversationId))?.conversationId;
}

export type ConversationRepository = {
  headId: string | null;
  messages: Array<{ parentId: string | null; message: ConversationMessage }>;
};

export function selectedHeadId(
  events: readonly LogEvent[],
  stored: Map<string, { eventId: number }>,
): string | null {
  const createdAt = new Map<string, number>();
  for (const event of events) {
    if (event.type !== "conversation.message") continue;
    const id = conversationMessageHeader(event)?.id;
    if (id === undefined || !stored.has(id)) continue;
    createdAt.set(id, Math.min(createdAt.get(id) ?? event.id, event.id));
  }
  const latest = [...stored].reduce<{ id: string | null; eventId: number }>(
    (head, [id, item]) => {
      const eventId = createdAt.get(id) ?? item.eventId;
      return eventId > head.eventId ? { id, eventId } : head;
    },
    { id: null, eventId: -1 },
  );
  // Only a new message node advances the head. A submitted run may fail or be
  // cancelled before creating one, and must not discard an explicit branch.
  // Updating an existing node only refreshes its contents.
  const selectionFloor = latest.eventId;
  for (const event of events) {
    if (event.type !== "conversation.branch.selected") continue;
    const content = fromLogValue(event.content, event.valueEncoding) as { headId?: unknown };
    if (typeof content?.headId === "string" && stored.has(content.headId) && event.id > selectionFloor && event.id > latest.eventId) {
      latest.id = content.headId;
      latest.eventId = event.id;
    }
  }
  return latest.id;
}

export function rebuildConversationRepository(events: readonly LogEvent[]): ConversationRepository {
  const stored = projectConversationMessageEntries(events);
  const messages = [...stored.values()].sort((left, right) => left.firstEventId - right.firstEventId).map(({ parentId, message }) => ({ parentId, message }));
  return { headId: selectedHeadId(events, stored), messages };
}

export class EventLogger {
  private pending: Promise<unknown> = Promise.resolve();
  private buffered: Omit<LogEvent, "id">[] = [];
  private bufferTimer: ReturnType<typeof setTimeout> | undefined;
  private activeRuns = new Map<string, string>();
  private phases = new Map<string, number>();
  private callOwners = new Map<string, { runId: string; phase: number | undefined }>();
  private accepting = true;
  private fatalError?: unknown;
  private ready: Promise<void> = Promise.resolve();
  private generation: number | undefined = 0;
  private handshakePaused = false;
  private listeners = new Set<(event: LogEvent) => void>();
  private commitListeners = new Set<(commit: LogCommit) => void>();
  private channel?: CommitChannel;
  private writerPort?: chrome.runtime.Port;
  private readonly writerId = crypto.randomUUID();
  private readonly localStore: EventStore;
  private disposed = false;
  private messageWrites = new Map<string, Promise<void>>();
  private messageHeads = new Map<string, { event: LogEvent; source: ConversationMessage; epoch: string }>();
  private readonly channelMessage = (event: MessageEvent) => {
    const commit = event.data;
    if (!commit || commit.writerId === this.writerId || !Number.isSafeInteger(commit.lastId)
      || !Array.isArray(commit.types) || commit.types.some((type: unknown) => typeof type !== "string")
      || !Array.isArray(commit.conversationIds) || commit.conversationIds.some((id: unknown) => typeof id !== "string")) return;
    this.receiveCommit({ lastId: commit.lastId, conversationIds: commit.conversationIds, types: commit.types, cleared: commit.cleared === true, external: true });
  };
  private artifactEpoch: string | undefined;
  private artifactRevision = 0;
  private artifactBytes = 0;
  private artifactCache = new Map<number, { conversationId: string | undefined; value: unknown; bytes: number; graph?: ArtifactGraph }>();
  private artifactLoads = new Map<number, Promise<{ conversationId: string | undefined; value: unknown; bytes: number; graph?: ArtifactGraph } | undefined>>();

  constructor(private readonly options: {
    store?: EventStore;
    now?: () => Date;
    onError?: (error: unknown) => void;
    writerPort?: chrome.runtime.Port;
    channelFactory?: (name: string) => CommitChannel;
    ioTimeoutMs?: number;
  } = {}) {
    this.localStore = options.store ?? getEventStore();
    let writers = localLogWriters.get(this.localStore);
    if (!writers) { writers = new Set(); localLogWriters.set(this.localStore, writers); }
    writers.add(this);
    if (options.channelFactory || !options.store && typeof chrome !== "undefined" && chrome.runtime?.id && typeof BroadcastChannel !== "undefined") {
      this.channel = options.channelFactory?.("surf-wax:canonical-log") ?? new BroadcastChannel("surf-wax:canonical-log");
      this.channel.addEventListener("message", this.channelMessage as EventListener);
    }
    if (options.writerPort || !options.store && typeof document !== "undefined" && typeof chrome !== "undefined" && chrome.runtime?.connect) {
      const port = this.writerPort = options.writerPort ?? chrome.runtime.connect({ name: "surf-wax-log-writer" });
      this.generation = undefined;
      let ready!: () => void;
      this.ready = new Promise<void>((resolve) => { ready = resolve; });
      let maintenance = 0;
      port.onDisconnect.addListener(() => {
        if (this.disposed) return;
        maintenance += 1;
        if (this.generation === undefined) this.handshakePaused = true;
        this.stop();
        ready();
        if (!this.disposed) this.options.onError?.(new Error("后台日志连接已断开，请重新加载侧栏。"));
      });
      port.onMessage.addListener((message) => {
        if (message.type === "writer-error") {
          this.handshakePaused = true;
          this.stop();
          ready();
          this.options.onError?.(new Error(message.error || "后台初始化失败，请重新加载扩展后重试。"));
        }
        if (message.type === "writer-ready") {
          this.generation = message.generation;
          this.handshakePaused = Boolean(message.paused);
          if (message.paused) this.stop();
          ready();
        }
        if (message.type === "prepare-clear") {
          const request = ++maintenance;
          void import("./agent/coordinator").then(({ settleAllConversationWork }) => settleAllConversationWork("log-cleared"))
            .then(() => { if (request === maintenance) { this.stop(); return this.flush(); } })
            .then(() => { if (request === maintenance) this.generation = message.generation ?? (this.generation ?? 0) + 1; })
            .then(() => port.postMessage({ id: message.id, ok: true }), (error) => port.postMessage({ id: message.id, ok: false, error: String(error) }));
        }
        if (message.type === "clear-complete") {
          maintenance += 1;
          if (/\/(sidepanel|userscripts)\.html$/.test(location.pathname)) location.reload();
          else this.resume();
        }
        if (message.type === "clear-failed") { maintenance += 1; this.resume(); }
      });
    }
  }

  private receiveCommit(commit: LogCommit): void {
    if (this.disposed) return;
    if (commit.cleared) { this.messageHeads.clear(); this.resetArtifactCache(); }
    else if (commit.external) for (const [key, head] of this.messageHeads) {
      if (head.event.conversationId && commit.conversationIds.includes(head.event.conversationId)) this.messageHeads.delete(key);
    }
    for (const listener of this.commitListeners) {
      try { listener(commit); } catch (error) { this.options.onError?.(error); }
    }
  }

  /** ID-only invalidation; consumers replay committed records from their own cursors. */
  subscribeCommits(listener: (commit: LogCommit) => void): () => void {
    this.commitListeners.add(listener);
    return () => this.commitListeners.delete(listener);
  }

  async dispose(): Promise<void> {
    if (this.disposed) return;
    this.disposed = true;
    this.stop();
    this.channel?.removeEventListener("message", this.channelMessage as EventListener);
    localLogWriters.get(this.localStore)?.delete(this);
    this.listeners.clear(); this.commitListeners.clear(); this.messageHeads.clear();
    try { await this.flush(); }
    finally { this.channel?.close(); this.writerPort?.disconnect(); }
  }

  private rememberMessage(event: LogEvent, source: ConversationMessage, epoch: string): void {
    const key = JSON.stringify([event.conversationId, source.id]);
    const current = this.messageHeads.get(key);
    if (current?.epoch === epoch && current.event.id > event.id) return;
    this.messageHeads.delete(key); this.messageHeads.set(key, { event, source, epoch });
    while (this.messageHeads.size > 64) this.messageHeads.delete(this.messageHeads.keys().next().value!);
  }

  private async materializeEvents(store: EventStore, floor: number, events: readonly LogEvent[]): Promise<LogEvent[]> {
    if (!events.some((event) => event.type === "conversation.message")) return [...events];
    const epoch = JSON.stringify([this.generation ?? null, floor]);
    const available = new Map(events.map((event) => [event.id, event]));
    const resolved = new Map<number, LogEvent>();
    const resolve = async (event: LogEvent, visiting = new Set<number>()): Promise<LogEvent> => {
      const header = conversationMessageHeader(event);
      const key = header ? JSON.stringify([event.conversationId, header.id]) : "";
      const head = this.messageHeads.get(key);
      if (head?.epoch === epoch && head.event.id === event.id) return head.event;
      if (!event.messagePatch) return event;
      if (resolved.has(event.id)) return resolved.get(event.id)!;
      if (visiting.has(event.id) || event.messagePatch.baseId >= event.id || event.messagePatch.baseId <= floor)
        throw new Error(`Conversation message change ${event.id} has an invalid dependency.`);
      visiting.add(event.id);
      const baseId = event.messagePatch.baseId;
      const base = head?.epoch === epoch && head.event.id === baseId ? head.event
        : available.get(baseId) ?? (store.get ? await store.get(baseId) : (await store.all()).find((item) => item.id === baseId));
      if (!base) throw new Error(`Conversation message change ${event.id} is missing its durable base.`);
      const full = materializeMessageEvent(event, await resolve(base, visiting));
      visiting.delete(event.id); resolved.set(event.id, full);
      return full;
    };
    const output: LogEvent[] = [];
    for (const event of events) {
      const full = event.type === "conversation.message" ? await resolve(event) : event;
      output.push(full);
      if (full.type === "conversation.message") {
        const message = encodedMessageFields(full);
        if (isConversationMessage(message)) this.rememberMessage(full, message, epoch);
      }
    }
    return output;
  }

  beginRun(conversationId: string, runId: string): void {
    this.activeRuns.set(conversationId, runId);
  }

  setRunPhase(runId: string, phase: number): void { this.phases.set(runId, phase); }

  toolIdentity(conversationId: string, toolCallId: string): { runId?: string; toolCallId: string; toolCallIdCanonical: true } {
    const runId = this.activeRuns.get(conversationId);
    const phase = runId ? this.phases.get(runId) : undefined;
    return { runId, toolCallId: phase && phase > 0 ? `${phase}:${toolCallId}` : toolCallId, toolCallIdCanonical: true };
  }

  endRun(conversationId: string, runId?: string): void {
    if (!runId || this.activeRuns.get(conversationId) === runId) this.activeRuns.delete(conversationId);
    if (runId) this.phases.delete(runId);
  }

  private event(record: LogRecord): Omit<LogEvent, "id"> {
    const callId = record.content && typeof record.content === "object" && "callId" in record.content
      && typeof record.content.callId === "string" ? record.content.callId : undefined;
    let owner = callId ? this.callOwners.get(callId) : undefined;
    const run = record.runId ?? owner?.runId ?? (record.conversationId ? this.activeRuns.get(record.conversationId) : undefined);
    if (callId && run && (!owner || owner.runId !== run)) {
      owner = { runId: run, phase: this.phases.get(run) };
      this.callOwners.set(callId, owner);
      if (this.callOwners.size > 1024) this.callOwners.delete(this.callOwners.keys().next().value!);
    }
    const phase = owner && owner.runId === run ? owner.phase : run ? this.phases.get(run) : undefined;
    return {
      timestamp: (this.options.now?.() ?? new Date()).toISOString(),
      type: record.type,
      valueEncoding: 5,
      content: toLogValue(Object.hasOwn(record, "content") ? record.content : null, undefined, 5),
      ...(record.conversationId ? { conversationId: record.conversationId } : {}),
      ...(record.parentId !== undefined ? { parentId: record.parentId } : {}),
      ...(run ? { runId: run } : {}),
      ...(Object.hasOwn(record, "stopReason") ? { stopReason: toLogValue(record.stopReason, undefined, 5) } : {}),
      ...(Object.hasOwn(record, "usage") ? { usage: toLogValue(record.usage, undefined, 5) } : {}),
      ...(Object.hasOwn(record, "providerMetadata") ? { providerMetadata: toLogValue(record.providerMetadata, undefined, 5) } : {}),
      ...(record.toolCallId !== undefined ? { toolCallId: !record.toolCallIdCanonical && phase !== undefined && phase > 0 ? `${phase}:${record.toolCallId}` : record.toolCallId } : {}),
      ...(Object.hasOwn(record, "input") ? { input: toLogValue(record.input, undefined, 5) } : {}),
      ...(Object.hasOwn(record, "output") ? { output: record.type !== "tool.failed" && requiresLogGraph(record.output) ? encodeLogGraph(record.output) : toLogValue(record.output, undefined, 5) } : {}),
      ...(Object.hasOwn(record, "error") ? { error: toLogValue(record.error, undefined, 5) } : {}),
      ...(Object.hasOwn(record, "retry") ? { retry: toLogValue(record.retry, undefined, 5) } : {}),
      ...(Object.hasOwn(record, "abort") ? { abort: toLogValue(record.abort, undefined, 5) } : {}),
      ...(record.latencyMs !== undefined ? { latencyMs: record.latencyMs } : {}),
    };
  }

  private partitionedArtifact(record: LogRecord): { event: Omit<LogEvent, "id">; parts: Omit<LogEvent, "id">[] } {
    if (record.type !== "tool.result.data" || !Object.hasOwn(record, "output") || artifactRetainedBytes(record.output, 256 * 1024) <= 256 * 1024)
      return { event: this.event(record), parts: [] };
    const { graph, parts } = partitionArtifact(record.output);
    const { output: _output, ...metadata } = record;
    const event = { ...this.event(metadata), output: null, artifactGraph: graph };
    return { event, parts: parts.map((part) => ({ type: "artifact.part", timestamp: event.timestamp, content: null,
      artifactPart: { key: graph.key, owner: event.conversationId, node: part.node, section: part.section, part: part.part }, output: part.value })) };
  }

  private enqueue(events: readonly Omit<LogEvent, "id">[], expectedEpoch?: string, expectedJobStateId?: number, artifactLink?: "resultArtifactId", artifactParts: readonly Omit<LogEvent, "id">[] = [], requireAtomic = false): Promise<LogEvent[]> {
    const generation = this.generation;
    const task = this.pending.then(async () => {
      await this.ready;
      const store = this.options.store ?? getEventStore();
      const write = async () => {
        // Recheck after the cross-page lock: maintenance may have advanced while
        // this writer was waiting for another page's terminal transaction.
        if (generation === undefined ? this.handshakePaused : generation !== this.generation) return [];
        if (requireAtomic) {
          const dispatch = events.find((event) => event.type === "conversation.followup.dispatched");
          const followup = fromLogValue(dispatch?.content, dispatch?.valueEncoding) as { id?: unknown } | null;
          if (!dispatch?.conversationId || typeof followup?.id !== "string") throw new Error("Invalid follow-up submission");
          const floor = await this.latestClearIdFresh(store);
          const history = store.byTypes ? await store.byTypes([...FOLLOWUP_EVENT_TYPES], dispatch.conversationId, floor)
            : (await store.all()).filter((event) => event.id > floor && event.conversationId === dispatch.conversationId && FOLLOWUP_EVENT_TYPES.includes(event.type as typeof FOLLOWUP_EVENT_TYPES[number]));
          const current = history.filter((event) => (fromLogValue(event.content, event.valueEncoding) as { id?: unknown } | null)?.id === followup.id)
            .sort((left, right) => left.id - right.id).at(-1);
          if (current?.type !== "conversation.followup.queued") return [];
        }
        const floor = expectedEpoch === undefined && expectedJobStateId === undefined ? undefined : await this.latestClearIdFresh(store);
        if (expectedEpoch !== undefined && JSON.stringify([this.generation ?? null, floor]) !== expectedEpoch) return [];
        if (expectedJobStateId !== undefined) {
          const requested = events.find((event) => event.type === "browser.job.state");
          const jobId = (fromLogValue(requested?.content, requested?.valueEncoding) as { jobId?: unknown } | null)?.jobId;
          if (!requested?.conversationId || typeof jobId !== "string" || expectedJobStateId <= (floor ?? -1)) return [];
          const original = store.get ? await store.get(expectedJobStateId) : (await store.all()).find((event) => event.id === expectedJobStateId);
          if (!original || original.type !== "browser.job.state" || original.conversationId !== requested.conversationId
            || (fromLogValue(original.content, original.valueEncoding) as { jobId?: unknown } | null)?.jobId !== jobId) return [];
          let cursor = expectedJobStateId;
          while (true) {
            const rows = store.byTypes ? await store.byTypes(["browser.job.state"], requested.conversationId, cursor, 256)
              : (await store.all()).filter((event) => event.type === "browser.job.state" && event.conversationId === requested.conversationId && event.id > cursor);
            const newer = rows.filter((event) => event.id > cursor).sort((a, b) => a.id - b.id).slice(0, 256);
            if (newer.some((event) => (fromLogValue(event.content, event.valueEncoding) as { jobId?: unknown } | null)?.jobId === jobId)) return [];
            if (newer.length < 256) break;
            cursor = newer.at(-1)!.id;
          }
        }
        const runIds = [...new Set(events.filter((event) => terminalKey(event)).map((event) => event.runId!))];
        const terminalFloor = runIds.length ? floor ?? await this.latestClearIdFresh(store) : -1;
        const prior = runIds.length ? store.terminalEvents
          ? await store.terminalEvents(events, terminalFloor)
          : store.byRunTypes ? await store.byRunTypes(runIds, TERMINAL_EVENT_TYPES, terminalFloor)
          : (await store.all()).filter((event) => event.runId && runIds.includes(event.runId) && TERMINAL_EVENT_TYPES.includes(event.type)) : [];
        const existing = new Map<string | undefined, LogEvent>();
        for (const event of prior.filter((item) => item.id > terminalFloor).sort((a, b) => a.id - b.id)) {
          const key = terminalKey(event); if (!existing.has(key)) existing.set(key, event);
        }
        const accepted: Omit<LogEvent, "id">[] = [];
        const keys = new Set(existing.keys());
        for (const event of events) {
          const key = terminalKey(event);
          if (key && keys.has(key)) continue;
          if (key) keys.add(key);
          accepted.push(event);
        }
        const stored: LogEvent[] = [];
        if (artifactParts.length && (!store.supportsArtifactParts || !store.artifactParts || !store.artifactBucketParts)) throw new Error("Event store does not support partitioned artifacts");
        if (artifactLink && accepted.length) {
          if (accepted.length !== 2 || !store.appendArtifactAnd) throw new Error("Event store does not support atomic artifact and job state writes");
          const pair = await store.appendArtifactAnd(accepted[0]!, accepted[1]!, artifactLink, artifactParts);
          stored.push(pair.artifact, pair.terminal);
        } else if (artifactParts.length && accepted.length) {
          if (accepted.length !== 1 || !store.appendPartitioned) throw new Error("Event store does not support atomic partitioned artifact writes");
          stored.push(await store.appendPartitioned(accepted[0]!, artifactParts));
        } else if (requireAtomic && accepted.length && !store.appendMany) throw new Error("Event store does not support atomic conversation submission");
        else if (accepted.length && store.appendMany) stored.push(...await store.appendMany(accepted));
        else for (const event of accepted) stored.push(await store.append(event));
        if (stored.length) {
          const published = stored.some((event) => event.type === "conversation.message")
            ? await this.materializeEvents(store, terminalFloor >= 0 ? terminalFloor : await this.latestClearIdFresh(store), stored) : stored;
          for (const event of published) for (const listener of this.listeners) {
            try { listener(event); } catch (error) { this.options.onError?.(error); }
          }
          const commit = { types: [...new Set(stored.map(event => event.type))], lastId: Math.max(...stored.map((event) => event.id)), conversationIds: [...new Set(stored.flatMap((event) => event.conversationId ? [event.conversationId] : []))], cleared: stored.some((event) => event.type === "log.cleared") };
          for (const writer of localLogWriters.get(this.localStore) ?? []) writer.receiveCommit({ ...commit, external: writer !== this });
          this.channel?.postMessage({ ...commit, writerId: this.writerId });
        }
        // Return the accepted durable terminal to a competing callback, without
        // publishing a second event or replacing the original reason/result.
        for (const event of stored) { const key = terminalKey(event); if (key) existing.set(key, event); }
        const appended = new Map(accepted.map((event, index) => [event, stored[index]!]));
        return events.map((event) => terminalKey(event) ? existing.get(terminalKey(event)!)! : appended.get(event)!)
          .filter((event): event is LogEvent => Boolean(event));
      };
      const terminalWrite = () => events.some((event) => terminalKey(event) || FOLLOWUP_EVENT_TYPES.includes(event.type as typeof FOLLOWUP_EVENT_TYPES[number])) ? withTerminalWriteLock(write) : write();
      return expectedEpoch !== undefined || events.some((event) => event.type === "browser.job.state" || event.type === "log.cleared")
        ? withJobStateWriteLock(terminalWrite, Boolean(this.options.store)) : terminalWrite();
    });
    const bounded = logIO(task, "写入", this.options.ioTimeoutMs);
    this.pending = bounded.catch((error) => {
      this.fatalError = error;
      this.stop();
      this.options.onError?.(error);
      throw error;
    });
    // Retain the failed queue to block later writes; the caller owns the error.
    void this.pending.catch(() => undefined);
    return bounded;
  }

  private flushBuffer(): void {
    if (this.bufferTimer !== undefined) clearTimeout(this.bufferTimer);
    this.bufferTimer = undefined;
    if (this.buffered.length === 0) return;
    const events = this.buffered;
    this.buffered = [];
    void this.enqueue(events).catch((error) => {
      console.error("Side Agent event log write failed", error);
    });
  }

  append(record: LogRecord): Promise<LogEvent | undefined> {
    if (this.fatalError !== undefined) return Promise.reject(this.fatalError);
    if (!this.accepting) return Promise.resolve(undefined);
    this.flushBuffer();
    const prepared = this.partitionedArtifact(record);
    return this.enqueue([prepared.event], undefined, undefined, undefined, prepared.parts).then(([event]) => event);
  }

  /** Commit a result and its job-state reference as one canonical transaction. */
  async appendArtifactAnd(input: { artifact: LogRecord; terminal: LogRecord; link: "resultArtifactId"; expectedEpoch?: string; expectedJobStateId?: number }): Promise<{ artifact: LogEvent; terminal: LogEvent } | undefined> {
    if (this.fatalError !== undefined) throw this.fatalError;
    if (!this.accepting) return undefined;
    if (input.artifact.type !== "tool.result.data" || input.terminal.type !== "browser.job.state"
      || input.artifact.conversationId !== input.terminal.conversationId || input.link !== "resultArtifactId") throw new Error("Invalid artifact and job state transaction");
    this.flushBuffer();
    const prepared = this.partitionedArtifact(input.artifact);
    const [artifact, terminal] = await this.enqueue([prepared.event, this.event(input.terminal)], input.expectedEpoch, input.expectedJobStateId, input.link, prepared.parts);
    return artifact && terminal ? { artifact, terminal } : undefined;
  }

  /** Conditional append for recovery derived from a particular clear/writer epoch. */
  appendIfEpoch(record: LogRecord, epoch: string, expectedJobStateId?: number): Promise<LogEvent | undefined> {
    if (this.fatalError !== undefined) return Promise.reject(this.fatalError);
    if (!this.accepting) return Promise.resolve(undefined);
    this.flushBuffer();
    return this.enqueue([this.event(record)], epoch, expectedJobStateId).then(([event]) => event);
  }

  /** Best-effort diagnostics only. State restoration must never depend on it. */
  telemetry(record: LogRecord): void {
    if (!this.accepting) return;
    this.buffered.push(this.event(record));
    this.bufferTimer ??= setTimeout(() => this.flushBuffer(), 16);
  }

  async appendMessage(conversationId: string, message: ConversationMessage, options: { runId?: string; parentId?: string | null; changedParts?: readonly number[] } = {}): Promise<void> {
    const key = JSON.stringify([conversationId, message.id]);
    const priorWrite = this.messageWrites.get(key) ?? Promise.resolve();
    const write = priorWrite.then(async () => {
      if (this.fatalError !== undefined) throw this.fatalError;
      if (!this.accepting) throw new DOMException("日志维护已阻止消息保存。", "AbortError");
      const epoch = await this.canonicalEpoch();
      let previous = this.messageHeads.get(key);
      if (previous?.epoch !== epoch) previous = undefined;
      if (options.changedParts?.some((index) => !Number.isSafeInteger(index) || index < 0 || index >= message.parts.length)) throw new Error("Invalid changed message part index");
      const indices = previous && options.changedParts ? [...new Set([...options.changedParts,
        ...Array.from({ length: Math.max(0, message.parts.length - previous.source.parts.length) }, (_, index) => previous.source.parts.length + index)])].sort((a, b) => a - b)
        : message.parts.flatMap((part, index) => previous && index < previous.source.parts.length
          && JSON.stringify(toLogValue(part, undefined, 5)) === JSON.stringify(previous.source.parts[index]) ? [] : [index]);
      const prepared = this.event({ type: "conversation.message", conversationId, runId: options.runId, parentId: options.parentId,
        content: previous ? { ...message, parts: indices.map((index) => message.parts[index]) } : message });
      if (previous) prepared.messagePatch = { baseId: previous.event.id, partsLength: message.parts.length, indices };
      this.flushBuffer();
      const [saved] = await this.enqueue([prepared]);
      if (!saved) throw new DOMException("日志维护已阻止消息保存。", "AbortError");
      const full = materializeMessageEvent(saved, previous?.event);
      this.rememberMessage(full, encodedMessageFields(full) as ConversationMessage, epoch);
    });
    this.messageWrites.set(key, write);
    try { await write; } finally { if (this.messageWrites.get(key) === write) this.messageWrites.delete(key); }
  }

  /** A follow-up leaves its queue only when its message and run are durable. */
  async appendFollowupSubmission(input: { conversationId: string; runId: string; chatId: string; message: ConversationMessage;
    parentId: string | null; followup: { id: string; mode: "followup" | "immediate" } }): Promise<void> {
    if (this.fatalError !== undefined) throw this.fatalError;
    if (!this.accepting) throw new DOMException("日志维护已阻止后续消息发送。", "AbortError");
    this.flushBuffer();
    const { conversationId, runId, message, parentId, followup } = input;
    const saved = await this.enqueue([
      this.event({ type: "conversation.message", conversationId, runId, parentId, content: message }),
      this.event({ type: "conversation.followup.dispatched", conversationId, runId, content: followup }),
      this.event({ type: "conversation.submitted", conversationId, runId, content: { chatId: input.chatId, messageId: message.id } }),
    ], undefined, undefined, undefined, [], true);
    if (saved.length !== 3) throw new Error("后续消息已发送、移除或日志正在维护。");
  }

  async repository(conversationId: string): Promise<ConversationRepository> {
    return rebuildConversationRepository(await this.eventsByTypes(["conversation.message", "conversation.branch.selected"], conversationId));
  }

  private async eventsByTypes(types: readonly string[], conversationId?: string): Promise<LogEvent[]> {
    return this.readCanonical((store, floor) => this.eventsByTypesAt(store, floor, types, conversationId));
  }

  private async eventsByTypesAt(store: EventStore, floor: number, types: readonly string[], conversationId?: string): Promise<LogEvent[]> {
    const events = store.byTypes ? (await store.byTypes(types, conversationId, floor)).filter((event) => event.id > floor)
      : (await store.all()).filter((event) => event.id > floor && types.includes(event.type) && (!conversationId || event.conversationId === conversationId));
    return this.materializeEvents(store, floor, events);
  }

  private async latestClearIdFresh(store: EventStore): Promise<number> {
    const latest = store.latestByType ? await store.latestByType("log.cleared")
      : store.byTypes ? (await store.byTypes(["log.cleared"])).at(-1)
      : (await store.all()).filter((event) => event.type === "log.cleared").at(-1);
    return latest?.id ?? -1;
  }

  /** A cross-writer clear may race any read; discard that read and retry. */
  private async readCanonicalSnapshot<T>(read: (store: EventStore, floor: number) => Promise<T>): Promise<{ value: T; epoch: string }> {
    return logIO((async () => { while (true) {
      await this.flush();
      const store = this.options.store ?? getEventStore();
      const generation = this.generation;
      const floor = await this.latestClearIdFresh(store);
      const value = await read(store, floor);
      if (generation === this.generation && floor === await this.latestClearIdFresh(store)) return { value, epoch: JSON.stringify([generation ?? null, floor]) };
    } })(), "读取", this.options.ioTimeoutMs);
  }

  private async readCanonical<T>(read: (store: EventStore, floor: number) => Promise<T>): Promise<T> {
    return (await this.readCanonicalSnapshot(read)).value;
  }

  summaryEvents(conversationId?: string): Promise<LogEvent[]> {
    return this.eventsByTypes(SUMMARY_EVENT_TYPES, conversationId);
  }

  summaryEventsSince(afterId = -1): Promise<{ value: LogEvent[]; epoch: string }> {
    if (!Number.isSafeInteger(afterId) || afterId < -1) throw new Error("Invalid summary event cursor");
    return this.readCanonicalSnapshot(async (store, floor) => {
      const start = Math.max(floor, afterId);
      const events = store.byTypes ? await store.byTypes(SUMMARY_EVENT_TYPES, undefined, start) : await store.all();
      return events.filter((event) => event.id > start && SUMMARY_EVENT_TYPES.includes(event.type as typeof SUMMARY_EVENT_TYPES[number])).sort((a, b) => a.id - b.id);
    });
  }

  contextEvents(conversationId: string): Promise<LogEvent[]> {
    return this.eventsByTypes(CONTEXT_EVENT_TYPES, conversationId);
  }

  diagnosticEvents(conversationId: string): Promise<LogEvent[]> {
    return this.eventsByTypes(["browser.diagnostic"], conversationId);
  }

  /** Diagnostic replay and its log epoch must be observed together. */
  diagnosticEventsSnapshot(conversationId: string, capture?: { tabId: number; epoch: string; afterId?: number }): Promise<{ value: LogEvent[]; epoch: string }> {
    return this.readCanonicalSnapshot(async (store, floor) => {
      const afterId = Math.max(floor, capture?.afterId ?? -1);
      if (capture && store.diagnosticsByCapture) return store.diagnosticsByCapture(conversationId, capture.tabId, capture.epoch, afterId);
      if (store.byTypes) return (await store.byTypes(["browser.diagnostic"], conversationId, afterId)).filter((event) => event.id > afterId);
      return (await store.all()).filter((event) => event.id > afterId && event.type === "browser.diagnostic" && event.conversationId === conversationId);
    });
  }

  /** Validate derived data against the current log-clear/writer epoch. */
  async canonicalEpoch(): Promise<string> {
    return (await this.readCanonicalSnapshot(async () => undefined)).epoch;
  }

  jobEvents(conversationId: string): Promise<LogEvent[]> {
    return this.eventsByTypes(["browser.job.state", "browser.job.progress"], conversationId);
  }

  /** Incremental, bounded reads of canonical job events. The epoch changes on log maintenance. */
  async jobEventsSince(conversationId: string, afterId: number, limit = 256): Promise<{ epoch: string; floor: number; events: LogEvent[]; hasMore: boolean }> {
    if (!Number.isSafeInteger(afterId) || afterId < -1 || !Number.isSafeInteger(limit) || limit < 1) throw new Error("Invalid job event cursor or limit");
    const types = ["browser.job.state", "browser.job.progress"];
    while (true) {
      await this.flush();
      const store = this.options.store ?? getEventStore();
      const generation = this.generation;
      const floor = await this.latestClearIdFresh(store);
      const start = Math.max(floor, afterId);
      const values = store.byTypes
        ? await store.byTypes(types, conversationId, start, limit + 1)
        : (await store.all()).filter((event) => event.id > start && event.conversationId === conversationId && types.includes(event.type));
      const nextFloor = await this.latestClearIdFresh(store);
      if (generation !== this.generation || floor !== nextFloor) continue;
      const events = values.filter((event) => event.id > start && event.conversationId === conversationId && types.includes(event.type))
        .sort((left, right) => left.id - right.id);
      return { epoch: JSON.stringify([generation ?? null, floor]), floor, events: events.slice(0, limit), hasMore: events.length > limit };
    }
  }

  /** Read a bounded page by canonical IDs; return null if log maintenance changed its epoch. */
  async jobEventsByIds(conversationId: string, ids: readonly number[], epoch: string): Promise<LogEvent[] | null> {
    if (ids.some((id) => !Number.isSafeInteger(id) || id < 1)) throw new Error("Invalid job event ID");
    await this.flush();
    const store = this.options.store ?? getEventStore();
    const generation = this.generation;
    const floor = await this.latestClearIdFresh(store);
    if (JSON.stringify([generation ?? null, floor]) !== epoch) return null;
    const values = store.getMany ? await store.getMany(ids) : store.get ? await Promise.all(ids.map((id) => store.get!(id)))
      : await store.all().then((all) => ids.map((id) => all.find((event) => event.id === id)));
    if (generation !== this.generation || floor !== await this.latestClearIdFresh(store)) return null;
    return values.map((event, index) => {
      if (!event || event.id !== ids[index] || event.id <= floor || event.conversationId !== conversationId
        || !["browser.job.state", "browser.job.progress"].includes(event.type)) throw new Error(`Job event ${ids[index]} is unavailable`);
      return event;
    });
  }

  inputStateEvents(): Promise<LogEvent[]> { return this.eventsByTypes(["browser.input.state"]); }

  modelUsageEvents(conversationId: string): Promise<LogEvent[]> {
    return this.eventsByTypes(["model.step.finished"], conversationId);
  }

  followupEvents(conversationId: string): Promise<LogEvent[]> {
    return this.eventsByTypes([...FOLLOWUP_EVENT_TYPES, ...RUN_EVENT_TYPES], conversationId);
  }

  messageEvents(): Promise<LogEvent[]> {
    return this.eventsByTypes(["conversation.message"]);
  }

  messageEventsSince(afterId = -1): Promise<{ value: LogEvent[]; epoch: string }> {
    return this.readCanonicalSnapshot(async (store, floor) => {
      const start = Math.max(floor, afterId);
      const events = store.byTypes ? await store.byTypes(["conversation.message"], undefined, start)
        : (await store.all()).filter(event => event.id > start && event.type === "conversation.message");
      return this.materializeEvents(store, floor, events);
    });
  }

  private async eventsByRunTypes(runIds: readonly string[], types: readonly string[]): Promise<LogEvent[]> {
    return this.readCanonical((store, floor) => this.eventsByRunTypesAt(store, floor, runIds, types));
  }

  private async eventsByRunTypesAt(store: EventStore, floor: number, runIds: readonly string[], types: readonly string[]): Promise<LogEvent[]> {
    const events = store.byRunTypes ? (await store.byRunTypes(runIds, types, floor)).filter((event) => event.id > floor)
      : (await store.all()).filter((event) => event.id > floor && event.runId && runIds.includes(event.runId) && types.includes(event.type));
    return this.materializeEvents(store, floor, events);
  }

  /** Incremental projection input paired with the log-maintenance epoch. */
  async contextProjectionEvents(conversationId: string, afterId = -1): Promise<{ value: LogEvent[]; epoch: string }> {
    if (!Number.isSafeInteger(afterId) || afterId < -1) throw new Error("Invalid context event cursor");
    const types = [...RUN_EVENT_TYPES, "conversation.message", "conversation.branch.selected", "conversation.deleted", "conversation.restored",
      "tool.started", "tool.finished", "tool.failed", ...CONTEXT_EVENT_TYPES, "agent.goal.continued"];
    return this.readCanonicalSnapshot(async (store, floor) => {
      const start = Math.max(floor, afterId);
      const events = store.byTypes ? await store.byTypes(types, conversationId, start)
        : (await store.all()).filter((event) => event.id > start && event.conversationId === conversationId && types.includes(event.type));
      return this.materializeEvents(store, floor, events.filter((event) => event.id > start && event.conversationId === conversationId && types.includes(event.type))
        .sort((left, right) => left.id - right.id));
    });
  }

  async restorationEvents(conversationId: string, { modelTiming = false }: { modelTiming?: boolean } = {}): Promise<LogEvent[]> {
    return this.readCanonical(async (store, floor) => {
      const lifecycle = await this.eventsByTypesAt(store, floor, [...RUN_EVENT_TYPES, "conversation.message", "conversation.branch.selected", "tool.finished", "tool.failed"], conversationId);
      const runIds = [...new Set(lifecycle.flatMap((event) => event.runId ? [event.runId] : []))];
      if (!runIds.length) return lifecycle;
      const [starts, responses] = await Promise.all([
        this.eventsByRunTypesAt(store, floor, runIds, ["tool.started"]),
        modelTiming ? this.eventsByTypesAt(store, floor, ["model.request.started", "model.response.received"], conversationId) : [],
      ]);
      const runs = new Set(runIds);
      return [...lifecycle, ...starts.filter((event) => event.conversationId === conversationId),
        ...responses.filter((event) => event.runId && runs.has(event.runId))].sort((left, right) => left.id - right.id);
    });
  }

  async messages(conversationId?: string): Promise<ConversationMessage[]> {
    if (conversationId) return (await this.repository(conversationId)).messages.map(({ message }) => message);
    return rebuildConversation(await this.eventsByTypes(["conversation.message"]));
  }

  async all(): Promise<LogEvent[]> {
    await this.flush();
    return logIO((this.options.store ?? getEventStore()).all(), "读取原始记录", this.options.ioTimeoutMs);
  }

  private resetArtifactCache(epoch?: string): void {
    this.artifactEpoch = epoch;
    this.artifactRevision++;
    this.artifactBytes = 0;
    this.artifactCache.clear();
    this.artifactLoads.clear();
  }

  private async loadArtifact(store: EventStore, floor: number, id: number): Promise<{ conversationId: string | undefined; value: unknown; bytes: number; graph?: ArtifactGraph } | undefined> {
    const epoch = JSON.stringify([this.generation ?? null, floor]);
    if (this.artifactEpoch !== epoch) this.resetArtifactCache(epoch);
    if (id <= floor) return undefined;
    const cached = this.artifactCache.get(id);
    if (cached) {
      this.artifactCache.delete(id);
      this.artifactCache.set(id, cached);
      return cached;
    }
    let task = this.artifactLoads.get(id);
    if (!task) {
      const revision = this.artifactRevision;
      task = (async () => {
        const event = store.get ? await store.get(id) : (await store.all()).find((item) => item.id === id);
        if (event?.type !== "tool.result.data") return undefined;
        const graph = event.artifactGraph;
        const value = graph ? undefined : fromLogValue(event.output, event.valueEncoding);
        const bytes = graph ? artifactRetainedBytes(graph) + 128 + (event.conversationId?.length ?? 0) * 2 : artifactRetainedBytes(value);
        const entry = { conversationId: event.conversationId, value, bytes, ...(graph ? { graph } : {}) };
        if (bytes <= ARTIFACT_CACHE_BYTES && this.artifactRevision === revision && this.artifactEpoch === epoch) {
          while (this.artifactBytes + bytes > ARTIFACT_CACHE_BYTES) {
            const oldest = this.artifactCache.keys().next().value!;
            this.artifactBytes -= this.artifactCache.get(oldest)!.bytes;
            this.artifactCache.delete(oldest);
          }
          this.artifactCache.set(id, entry);
          this.artifactBytes += bytes;
        }
        return entry;
      })();
      this.artifactLoads.set(id, task);
    }
    try { return await task; }
    finally { if (this.artifactLoads.get(id) === task) this.artifactLoads.delete(id); }
  }

  async result(id: number, selection: { path?: string | Array<string | number>; offset?: number; limit?: number } = {}, conversationId?: string): Promise<unknown> {
    if (!Number.isSafeInteger(id) || id < 1) throw new Error("Invalid result event ID");
    for (const field of ["offset", "limit"] as const) {
      const value = selection[field];
      if (value !== undefined && (!Number.isSafeInteger(value) || value < 0))
        throw Object.assign(new Error(`Artifact ${field} must be a non-negative safe integer`), { code: "invalid-result-range" });
    }
    const loaded = await this.readCanonical(async (store, floor) => {
      const event = await this.loadArtifact(store, floor, id);
      if (!event || conversationId !== undefined && event.conversationId !== conversationId) throw new Error(`Tool result ${id} is unavailable`);
      if (!event.graph) return { partitioned: false as const, value: event.value };
      if (!store.artifactParts || !store.artifactBucketParts) throw new Error("Event store does not support partitioned artifact reads");
      const graph = event.graph;
      const validate = (rows: LogEvent[], node: number, matches: (part: NonNullable<LogEvent["artifactPart"]>) => boolean): ArtifactPart[] => rows.map((row) => {
        const part = row.artifactPart;
        if (row.type !== "artifact.part" || row.id <= floor || row.id >= id || !part || part.key !== graph.key || part.owner !== event.conversationId
          || part.node !== node || !matches(part)) throw new Error("Invalid artifact part");
        return { node: part.node, section: part.section, part: part.part, value: row.output };
      });
      const value = await readPartitionedArtifact(graph, async (node, section, first, last) => {
        const rows = await store.artifactParts!(graph.key, node, section, first, last);
        return validate(rows, node, (part) => (section === undefined || part.section === section)
          && (first === undefined || part.part >= first) && (last === undefined || part.part <= last));
      }, selection, id, async (node, prefix, first, last) => {
        const rows = await store.artifactBucketParts!(graph.key, node, prefix, first, last);
        return validate(rows, node, (part) => {
          const suffix = part.section.slice(prefix.length);
          const bucket = Number(suffix);
          return part.section.startsWith(prefix) && /^(?:0|[1-9]\d*)$/.test(suffix)
            && Number.isSafeInteger(bucket) && bucket >= first && bucket <= last;
        });
      });
      return { partitioned: true as const, value };
    });
    if (loaded.partitioned) return loaded.value;
    let value = loaded.value;
    const path = typeof selection.path === "string" ? [selection.path] : selection.path ?? [];
    if (!Array.isArray(path) || path.some((part) => typeof part !== "string" && (!Number.isSafeInteger(part) || part < 0)))
      throw new Error("Tool result path must contain only strings and nonnegative integer indices");
    for (const part of path) {
      if (typeof part === "number" && (isMap(value) || isSet(value))) {
        const size = isMap(value) ? mapSizeOf(value) : setSizeOf(value as Set<unknown>);
        if (part >= size) throw Object.assign(new Error(`Tool result ${id} has no path ${JSON.stringify(path)}`), { code: "result-path-not-found" });
        const iterator = isMap(value) ? mapEntries(value) : setValues(value as Set<unknown>);
        for (let index = 0; index < part; index++) iterator.next();
        value = iterator.next().value;
        continue;
      }
      if (value === null || typeof value !== "object" && typeof value !== "string" || !Object.hasOwn(Object(value), part))
        throw Object.assign(new Error(`Tool result ${id} has no path ${JSON.stringify(path)}`), { code: "result-path-not-found" });
      value = (value as any)[part];
    }
    if (selection.offset !== undefined || selection.limit !== undefined) {
      if (!Array.isArray(value) && typeof value !== "string" && !isMap(value) && !isSet(value) && !isArrayBuffer(value) && !ArrayBuffer.isView(value)) {
        const keys = value && typeof value === "object" ? Object.keys(value).filter(key => key.length <= 128).slice(0, 16) : [];
        const nextPath = await artifactPagePath(value, path, {
          keys: (item) => item && typeof item === "object" ? Object.keys(item) : [],
          field: (item, key) => Object.getOwnPropertyDescriptor(item, key)?.value,
          kind: (item) => Array.isArray(item) || isMap(item) || isSet(item) || isArrayBuffer(item) || ArrayBuffer.isView(item) ? "collection"
            : typeof item === "string" ? "string" : item && typeof item === "object" ? "object" : "scalar",
        });
        throw artifactPagingError(id, path, value === null ? "null" : typeof value, nextPath, keys);
      }
      const offset = Math.max(0, selection.offset ?? 0);
      const end = selection.limit === undefined ? undefined : offset + Math.max(0, selection.limit);
      if (Array.isArray(value)) {
        const array = value;
        // Array.prototype.slice scans every position, including holes. A native
        // artifact read can request an unbounded suffix of a huge sparse array.
        const index = (position: number) => Math.min(array.length, Math.max(0, Math.trunc(position) || 0));
        const first = index(offset), last = end === undefined ? array.length : index(end);
        const sliced = new Array(Math.max(0, last - first));
        if (last - first > 32768) {
          const keys = Object.getOwnPropertyNames(array).filter((key) => /^(?:0|[1-9]\d*)$/.test(key) && Number(key) < array.length);
          if (keys.length < array.length * 0.8) {
            for (const key of keys) {
              const position = Number(key);
              if (position >= first && position < last) sliced[position - first] = array[position];
            }
          } else for (let position = first; position < last; position++) if (Object.hasOwn(array, position)) sliced[position - first] = array[position];
        } else for (let position = first; position < last; position++) if (Object.hasOwn(array, position)) sliced[position - first] = array[position];
        value = sliced;
      } else if (isMap(value) || isSet(value)) {
        const size = isMap(value) ? mapSizeOf(value) : setSizeOf(value as Set<unknown>);
        const first = Math.min(size, Math.max(0, Math.trunc(offset) || 0));
        const last = end === undefined ? size : Math.min(size, Math.max(0, Math.trunc(end) || 0));
        const result = isMap(value) ? new Map() : new Set();
        let index = 0;
        const iterator = isMap(value) ? mapEntries(value) : setValues(value as Set<unknown>);
        for (const item of first < last ? iterator : []) {
          if (index >= last) break;
          if (index++ < first) continue;
          if (result instanceof Map) result.set((item as [unknown, unknown])[0], (item as [unknown, unknown])[1]);
          else result.add(item);
        }
        value = result;
      } else if (ArrayBuffer.isView(value)) {
        const layout = viewLayout(value); const first = Math.min(layout.length, Math.max(0, Math.trunc(offset) || 0));
        const last = end === undefined ? layout.length : Math.min(layout.length, Math.max(0, Math.trunc(end) || 0));
        const width = isDataView(value) ? 1 : layout.length ? layout.byteLength / layout.length : 1;
        const bytes = new Uint8Array(layout.buffer, layout.byteOffset + first * width, Math.max(0, last - first) * width).slice();
        value = createArrayView(arrayViewName(value), bytes.buffer, 0, Math.max(0, last - first));
      } else if (isArrayBuffer(value)) {
        const size = arrayBufferLength(value); const first = Math.min(size, Math.max(0, Math.trunc(offset) || 0));
        const last = end === undefined ? size : Math.min(size, Math.max(0, Math.trunc(end) || 0));
        value = new Uint8Array(value, first, Math.max(0, last - first)).slice().buffer;
      } else value = value.slice(offset, end);
    }
    return cloneArtifactValue(value);
  }

  async conversation(conversationId: string): Promise<LogEvent[]> {
    return this.readCanonical(async (store, floor) => this.materializeEvents(store, floor, store.conversation
      ? (await store.conversation(conversationId, floor)).filter((event) => event.id > floor)
      : (await store.all()).filter((event) => event.id > floor && event.conversationId === conversationId)));
  }

  async deleteConversation(conversationId: string): Promise<void> {
    await this.append({ type: "conversation.deleted", conversationId, content: null });
  }

  async restoreConversation(conversationId: string): Promise<void> {
    await this.append({ type: "conversation.restored", conversationId, content: null });
  }

  private async artifactForCall(event: LogEvent, events: readonly LogEvent[], source?: { store: EventStore; floor: number }): Promise<{ id: number } | undefined> {
    const store = source?.store ?? this.options.store ?? getEventStore();
    const floor = source?.floor ?? await this.latestClearIdFresh(store);
    let stored = [...events].reverse().find((item) => item.type === "tool.result.data" && item.toolCallId === event.toolCallId && item.id > event.id && item.id > floor
      && typeof (fromLogValue(item.content, item.valueEncoding) as { filename?: unknown } | null)?.filename === "string");
    const referenced = [...events].reverse().find(item => item.type === "browser.artifact.used" && item.toolCallId === event.toolCallId && item.id > event.id && item.id > floor);
    const referencedId = (fromLogValue(referenced?.content, referenced?.valueEncoding) as { artifactId?: number } | null)?.artifactId;
    if (!stored && Number.isSafeInteger(referencedId) && referencedId! > floor) {
      const saved = store.get ? await store.get(referencedId!) : (await store.all()).find(item => item.id === referencedId);
      if (saved?.type === "tool.result.data" && saved.conversationId === event.conversationId && typeof (fromLogValue(saved.content, saved.valueEncoding) as { filename?: unknown } | null)?.filename === "string") stored = saved;
    }
    const input = fromLogValue(event.input, event.valueEncoding) as { id?: number } | null;
    if (!stored && (fromLogValue(event.content, event.valueEncoding) as { toolName?: string })?.toolName === "artifact-save" && Number.isSafeInteger(input?.id) && input!.id! > floor) {
      const saved = store.get ? await store.get(input!.id!) : (await store.all()).find((item) => item.id === input!.id);
      if (saved?.type === "tool.result.data" && saved.conversationId === event.conversationId && typeof (fromLogValue(saved.content, saved.valueEncoding) as { filename?: unknown } | null)?.filename === "string") stored = saved;
    }
    return stored ? { id: stored.id, ...(fromLogValue(stored.content, stored.valueEncoding) as object) } : undefined;
  }

  async toolArtifact(conversationId: string, identity: { runId?: string; toolCallId: string }): Promise<{ id: number } | undefined> {
    if (!identity.runId) return undefined;
    return this.readCanonical(async (store, floor) => {
      const events = await this.eventsByRunTypesAt(store, floor, [identity.runId!], ["tool.started", "tool.result.data", "browser.artifact.used"]);
      const started = [...events].reverse().find((event) => event.type === "tool.started" && event.conversationId === conversationId && event.toolCallId === identity.toolCallId);
      return started ? this.artifactForCall(started, events, { store, floor }) : undefined;
    });
  }

  async closePendingTools(runId: string, conversationId: string, reason: unknown): Promise<void> {
    await this.closePendingToolsInEpoch(runId, conversationId, reason);
  }

  private async closePendingToolsInEpoch(runId: string, conversationId: string, reason: unknown, requiredEpoch?: string): Promise<boolean> {
    const snapshot = await this.readCanonicalSnapshot((store, floor) => this.eventsByRunTypesAt(store, floor, [runId], ["conversation.message", "tool.started", "tool.finished", "tool.failed", "tool.progress", "tool.result.data", "browser.artifact.used"]));
    if (requiredEpoch !== undefined && snapshot.epoch !== requiredEpoch) return false;
    const { value: events, epoch } = snapshot;
    const key = (event: LogEvent) => `${(fromLogValue(event.content, event.valueEncoding) as { callId?: string })?.callId ?? ""}\0${event.toolCallId}`;
    const terminal = new Set(events.filter((event) => ["tool.finished", "tool.failed"].includes(event.type)).map(key));
    for (const event of events) {
      if (event.type !== "tool.started" || !event.toolCallId || terminal.has(key(event))) continue;
      terminal.add(key(event));
      const progress = [...events].reverse().find((item) => item.type === "tool.progress" && item.toolCallId === event.toolCallId);
      const progressContent = progress ? fromLogValue(progress.content, progress.valueEncoding) as { nextIndex: number; steps: unknown[] } : undefined;
      const progressOutput = progress ? fromLogValue(progress.output, progress.valueEncoding) as { completed: unknown[]; elapsedMs: number } : undefined;
      // After an owner disappears there is no reliable end instant. Preserve
      // only elapsed work already observed, rather than counting time offline.
      const observedMs = typeof progressOutput?.elapsedMs === "number" && Number.isFinite(progressOutput.elapsedMs)
        ? Math.max(0, progressOutput.elapsedMs) : 0;
      const input = fromLogValue(event.input, event.valueEncoding) as { steps?: unknown[] } | undefined;
      const steps = progressContent?.steps ?? input?.steps;
      const index = progressContent?.nextIndex ?? 0;
      const completedAll = Boolean(steps && index === steps.length);
      const failure = { code: "interrupted", message: String(reason), effectUnknown: true };
      const artifact = await this.artifactForCall(event, events);
      const output = steps ? {
        ok: completedAll, completed: progressOutput?.completed ?? [],
        ...(completedAll ? {} : { error: failure, failed: { index, step: steps[index], error: failure }, notRun: steps.slice(index + 1) }),
        elapsedMs: progressOutput?.elapsedMs ?? 0,
      } : { ok: false, error: failure };
      const saved = await this.appendIfEpoch({ type: completedAll ? "tool.finished" : "tool.failed", conversationId, runId, toolCallId: event.toolCallId, toolCallIdCanonical: true,
        content: { ...((fromLogValue(event.content, event.valueEncoding) as object) ?? {}), status: completedAll ? "completed" : "interrupted", effectUnknown: !completedAll, timingIncomplete: true },
        input: fromLogValue(event.input, event.valueEncoding), output: { ...output, ...(artifact ? { artifact } : {}) },
        latencyMs: observedMs, ...(completedAll ? {} : { error: failure, abort: { reason } }) }, epoch);
      if (!saved) return false;
    }
    const started = new Set(events.filter((event) => event.type === "tool.started" || event.type === "tool.finished" || event.type === "tool.failed").map((event) => event.toolCallId));
    const messages = new Map<string, ConversationMessage>();
    for (const event of events) if (event.type === "conversation.message") {
      const message = fromLogValue(event.content, event.valueEncoding);
      if (isConversationMessage(message)) messages.set(message.id, message);
    }
    // A complete response can contain several calls. Cancellation before their
    // execution still needs a terminal result for every accepted call.
    for (const message of messages.values()) for (const part of message.parts) {
      if (!part || typeof part !== "object" || !("toolCallId" in part) || !("state" in part)
        || typeof part.toolCallId !== "string" || !["input-available", "output-error"].includes(String(part.state)) || started.has(part.toolCallId)) continue;
      started.add(part.toolCallId);
      const input = "input" in part ? part.input : undefined;
      const toolName = "toolName" in part ? part.toolName : "type" in part ? String(part.type).slice(5) : undefined;
      const invalid = part.state === "output-error";
      const error = { code: invalid ? "invalid-tool-call" : "interrupted",
        message: invalid && "errorText" in part ? String(part.errorText) : "工具调用已中断，此操作未执行。", effectUnknown: false };
      const saved = await this.appendIfEpoch({ type: "tool.failed", conversationId, runId, toolCallId: part.toolCallId, toolCallIdCanonical: true,
        content: { toolName, status: invalid ? "failed" : "interrupted", effectUnknown: false }, input, output: { ok: false, error }, error, latencyMs: 0,
        ...(invalid ? {} : { abort: { reason } }) }, epoch);
      if (!saved) return false;
    }
    return true;
  }

  async recoverDanglingRuns(activeRunIds: readonly string[] | (() => Promise<readonly string[]>) = [], reason = "owner-disconnected"): Promise<void> {
    const recover = async () => {
      const { value: events, epoch } = await this.readCanonicalSnapshot((store, floor) => this.eventsByTypesAt(store, floor, RUN_EVENT_TYPES));
      const terminal = new Set(events.filter((event) => event.runId && event.type !== "conversation.submitted").map((event) => event.runId));
      for (const event of events) {
        if (event.type !== "conversation.submitted" || !event.runId || !event.conversationId || terminal.has(event.runId)) continue;
        const owners = typeof activeRunIds === "function" ? await activeRunIds() : activeRunIds;
        if (owners.includes(event.runId)) continue;
        terminal.add(event.runId);
        if (!await this.closePendingToolsInEpoch(event.runId, event.conversationId, reason, epoch)) return;
        const saved = await this.appendIfEpoch({ type: "conversation.aborted", conversationId: event.conversationId, runId: event.runId,
          content: null, abort: { reason } }, epoch);
        if (!saved) return;
      }
    };
    if (typeof navigator !== "undefined" && navigator.locks) await navigator.locks.request("surf-wax:log-recovery", recover);
    else await recover();
  }

  async clear(): Promise<void> {
    await this.flush();
    const event = this.event({ type: "log.cleared", content: null });
    const [stored] = await this.enqueue([event]);
    if (!stored) throw new Error("Could not persist log clear");
    this.resetArtifactCache();
  }

  resume(): void { this.accepting = true; }

  stop(): void {
    this.accepting = false;
    this.activeRuns.clear();
    this.resetArtifactCache();
  }

  subscribe(listener: (event: LogEvent) => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  async flush(): Promise<void> {
    this.flushBuffer();
    await logIO(Promise.all([this.ready, this.pending]), "等待提交", this.options.ioTimeoutMs);
  }
}

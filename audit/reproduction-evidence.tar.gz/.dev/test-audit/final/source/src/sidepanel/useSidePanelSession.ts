import { useEffect, useState } from "react";
import type { ModelConfig } from "../types";
import { activeRunIdentity } from "../agent/coordinator";
import { CATALOG_CACHE_KEY } from "../agent/model-limits";
import {
  EMPTY_MODEL_CONFIG,
  MODEL_CONFIG_STORAGE_KEY,
  isCompleteModelConfig,
  loadModelConfig,
  selectedModelConfig,
} from "./config";

const EMPTY_CONFIG: ModelConfig = { sdk: "@ai-sdk/openai-compatible", providerSettings: {}, baseURL: "", model: "" };

export type SidePanelSession = {
  config: ModelConfig;
  systemPrompt?: string;
  configReady: boolean;
  error?: unknown;
  configured: boolean;
};

export function useSidePanelSession(): SidePanelSession {
  const [modelSettings, setModelSettings] = useState(EMPTY_MODEL_CONFIG);
  const [configReady, setConfigReady] = useState(false);
  const [error, setError] = useState<unknown>();

  useEffect(() => {
    let active = true;
    let deferred = false;
    let hydrated = false;
    let controller: AbortController | undefined;
    const refresh = async () => {
      controller?.abort();
      const current = new AbortController();
      controller = current;
      const isCurrent = () => active && controller === current && !current.signal.aborted;
      try {
        // Runtime hydration is read-only: a stale load must never write an old
        // settings snapshot over a newer choice. Options Save persists routing.
        const stored = await loadModelConfig(undefined, undefined, { signal: current.signal, persistMigration: false });
        if (!isCurrent()) return;
        // A catalog commit may supersede the very first read. Only defer
        // updates after this panel actually has a configuration to retain.
        const running = hydrated && await activeRunIdentity();
        if (!isCurrent()) return;
        if (running) { deferred = true; return; }
        deferred = false;
        hydrated = true;
        setModelSettings(stored);
        setError(undefined);
      } catch (cause) {
        if (isCurrent()) setError(cause);
      } finally {
        if (isCurrent()) setConfigReady(true);
      }
    };
    const storageChanged = (changes: { [key: string]: chrome.storage.StorageChange }, area: string) => {
      if (area === "local" && (changes[MODEL_CONFIG_STORAGE_KEY] || changes[CATALOG_CACHE_KEY])) void refresh();
    };
    const runChanged = (message: { type?: string; identity?: unknown }) => {
      if (deferred && message.type === "surf-wax:run-state" && !message.identity) void refresh();
    };

    void refresh();
    chrome.storage.onChanged.addListener(storageChanged);
    chrome.runtime.onMessage.addListener(runChanged);
    return () => {
      active = false;
      controller?.abort();
      chrome.storage.onChanged.removeListener(storageChanged);
      chrome.runtime.onMessage.removeListener(runChanged);
    };
  }, []);

  const config = selectedModelConfig(modelSettings) ?? EMPTY_CONFIG;
  return {
    config,
    systemPrompt: modelSettings.systemPrompt,
    configReady,
    error,
    configured: configReady && Boolean(modelSettings.selectedProviderId) && isCompleteModelConfig(config),
  };
}

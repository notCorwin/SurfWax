import { isModelSdk, MODEL_ENDPOINT_TYPES, type ModelConfig, type ModelSdk } from "../types";
import { modelConfigErrors } from "../agent/model-sdks";
import { isAbortError, retryModelOperation } from "../agent/model";
import { loadModelCatalog, MODEL_ROUTING_VERSION, normalizeModelProviderOverride, type ModelCatalog } from "../agent/model-limits";

export const MODEL_CONFIG_STORAGE_KEY = "side-agent:model-config";
export type ModelProfile = ModelConfig & { providerId: string; sdk: ModelSdk; providerSettings: Record<string, string>; catalogRouteVersion?: number };
export type PersistedModelConfig = { selectedProviderId: string; profiles: Record<string, ModelProfile>; systemPrompt?: string };
export const EMPTY_MODEL_CONFIG: PersistedModelConfig = { selectedProviderId: "", profiles: {} };

export type StorageAreaLike = Pick<chrome.storage.StorageArea, "get" | "set">;

export function isCompleteModelConfig(config: ModelConfig | undefined): boolean {
  return Boolean(config && Object.keys(modelConfigErrors(config)).length === 0);
}

export function selectedModelConfig(config: PersistedModelConfig): ModelProfile | undefined {
  return config.profiles[config.selectedProviderId];
}

function getStorageArea(): StorageAreaLike | null {
  if (typeof chrome === "undefined" || !chrome.storage?.local) return null;
  return chrome.storage.local;
}

export async function loadModelConfig(
  fallback: PersistedModelConfig = EMPTY_MODEL_CONFIG,
  storage = getStorageArea(),
  options: {
    loadCatalog?: (options: { signal: AbortSignal; refresh?: boolean; staleFallback?: boolean }) => Promise<ModelCatalog>;
    migrateCatalogRouting?: boolean;
    persistMigration?: boolean;
    signal?: AbortSignal;
    sleep?: (ms: number) => Promise<void>;
  } = {},
): Promise<PersistedModelConfig> {
  const signal = options.signal ?? new AbortController().signal;
  signal.throwIfAborted();
  if (!storage) return fallback;

  const stored = await storage.get(MODEL_CONFIG_STORAGE_KEY);
  signal.throwIfAborted();
  const value = stored[MODEL_CONFIG_STORAGE_KEY];
  if (!value || typeof value !== "object") return fallback;

  const candidate = value as Record<string, unknown>;
  if (candidate.profiles && typeof candidate.profiles === "object" && !Array.isArray(candidate.profiles)) {
    const profiles = Object.fromEntries(Object.entries(candidate.profiles).flatMap(([providerId, raw]) => {
      if (!raw || typeof raw !== "object" || Array.isArray(raw)) return [];
      const profile = raw as Record<string, unknown>;
      const restoredProvider = normalizeModelProviderOverride(profile.modelProvider);
      // An unavailable persisted SDK is an error, not permission to use another protocol.
      const modelProvider = typeof profile.sdk === "string" && !isModelSdk(profile.sdk) && restoredProvider?.npm === undefined
        ? { ...restoredProvider, npm: profile.sdk } : restoredProvider;
      const sdk = isModelSdk(profile.sdk) ? profile.sdk : "@ai-sdk/openai-compatible";
      const rawSettings = profile.providerSettings && typeof profile.providerSettings === "object" && !Array.isArray(profile.providerSettings)
        ? profile.providerSettings as Record<string, unknown> : {};
      const providerSettings = Object.fromEntries(Object.entries(rawSettings).filter((entry): entry is [string, string] => typeof entry[1] === "string"));
      return [[providerId, {
        providerId,
        sdk,
        ...(profile.catalogRouteVersion === MODEL_ROUTING_VERSION ? { catalogRouteVersion: MODEL_ROUTING_VERSION } : {}),
        ...(modelProvider ? { modelProvider } : {}),
        providerSettings,
        baseURL: typeof profile.baseURL === "string" ? profile.baseURL : "",
        ...(typeof profile.baseURLOverride === "string" && profile.baseURLOverride.trim() ? { baseURLOverride: profile.baseURLOverride } : {}),
        model: typeof profile.model === "string" ? profile.model : "",
        ...(typeof profile.endpointType === "string" && (MODEL_ENDPOINT_TYPES as readonly string[]).includes(profile.endpointType) ? { endpointType: profile.endpointType as ModelConfig["endpointType"] } : {}),
        ...(typeof profile.canonicalModelId === "string" ? { canonicalModelId: profile.canonicalModelId } : {}),
        ...(typeof profile.modelFamily === "string" ? { modelFamily: profile.modelFamily } : {}),
        imageInput: profile.imageInput === "enabled" || profile.imageInput === "disabled" ? profile.imageInput : "auto",
        ...(Number.isSafeInteger(profile.contextWindowOverride) && Number(profile.contextWindowOverride) > 0
          ? { contextWindowOverride: Number(profile.contextWindowOverride) } : {}),
        ...(Number.isSafeInteger(profile.maxTokensOverride) && Number(profile.maxTokensOverride) > 0
          ? { maxTokensOverride: Number(profile.maxTokensOverride) } : {}),
      } satisfies ModelProfile]];
    }));
    const result: PersistedModelConfig = {
      selectedProviderId: typeof candidate.selectedProviderId === "string" ? candidate.selectedProviderId : "",
      profiles,
      ...(typeof candidate.systemPrompt === "string" && candidate.systemPrompt.trim() ? { systemPrompt: candidate.systemPrompt } : {}),
    };
    const selected = selectedModelConfig(result);
    if (options.migrateCatalogRouting !== false && selected && selected.providerId !== "custom" && !selected.modelProvider && selected.catalogRouteVersion !== MODEL_ROUTING_VERSION) {
      // Profiles created before model-level routing must be enriched before dispatch.
      // Recoverable catalog failures retry until recovery or cancellation. Permanent
      // failures leave storage untouched rather than selecting the wrong protocol.
      let catalog: ModelCatalog;
      const loadCatalog = (refresh = false) => retryModelOperation(
        () => (options.loadCatalog ?? loadModelCatalog)({ signal, ...(refresh ? { refresh: true, staleFallback: false } : {}) }),
        { signal, purpose: "model-catalog-migration", sleep: options.sleep },
      );
      try {
        catalog = await loadCatalog();
        const bundledProvider = catalog[selected.providerId];
        const bundledModel = bundledProvider?.models?.[selected.model]
          ?? Object.values(bundledProvider?.models ?? {}).find((model) => model.id === selected.model);
        // Bundle/cache resolution keeps offline startup immediate. Only wait for
        // live data when it may contain a provider or corrected per-model route.
        if (!bundledProvider || !bundledModel) catalog = await loadCatalog(true);
      } catch (cause) {
        if (isAbortError(cause, signal)) throw cause;
        throw new Error("模型路由目录更新失败，请检查配置后重试。", { cause });
      }
      signal.throwIfAborted();
      const provider = catalog[selected.providerId];
      if (!provider) throw new Error(`模型目录中找不到 Provider：${selected.providerId}；请在设置中重新选择 Provider。`);
      const model = provider.models?.[selected.model] ?? Object.values(provider.models ?? {}).find((model) => model.id === selected.model);
      const modelProvider = normalizeModelProviderOverride(model?.provider)
        ?? (model && provider.npm !== undefined && !isModelSdk(provider.npm) ? { npm: provider.npm } : undefined);
      result.profiles[selected.providerId] = {
        ...selected,
        ...(modelProvider ? { modelProvider } : {}),
        sdk: isModelSdk(modelProvider?.npm) ? modelProvider.npm : selected.sdk,
        baseURL: modelProvider?.api ?? selected.baseURL,
        ...(model?.canonical_model_id ? { canonicalModelId: model.canonical_model_id } : {}),
        ...(model?.family ? { modelFamily: model.family } : {}),
        catalogRouteVersion: MODEL_ROUTING_VERSION,
      };
      if (options.persistMigration !== false) {
        const current = await storage.get(MODEL_CONFIG_STORAGE_KEY);
        signal.throwIfAborted();
        if (JSON.stringify(current[MODEL_CONFIG_STORAGE_KEY]) !== JSON.stringify(value)) {
          throw new DOMException("Model configuration changed during migration", "AbortError");
        }
        await storage.set({ [MODEL_CONFIG_STORAGE_KEY]: result });
        signal.throwIfAborted();
      }
    }
    return result;
  }

  return fallback;
}

export async function saveModelConfig(
  config: PersistedModelConfig,
  storage = getStorageArea(),
): Promise<void> {
  if (!storage) throw new Error("Chrome storage is unavailable");

  await storage.set({
    [MODEL_CONFIG_STORAGE_KEY]: {
      selectedProviderId: config.selectedProviderId,
      profiles: Object.fromEntries(Object.entries(config.profiles).map(([providerId, profile]) => [providerId, {
        providerId,
        sdk: profile.sdk,
        ...(profile.catalogRouteVersion === MODEL_ROUTING_VERSION ? { catalogRouteVersion: MODEL_ROUTING_VERSION } : {}),
        ...(profile.modelProvider ? { modelProvider: normalizeModelProviderOverride(profile.modelProvider) } : {}),
        providerSettings: Object.fromEntries(Object.entries(profile.providerSettings).map(([key, value]) => [key, value.trim()])),
        baseURL: profile.baseURL.trim(),
        ...(profile.baseURLOverride?.trim() ? { baseURLOverride: profile.baseURLOverride.trim() } : {}),
        model: profile.model.trim(),
        ...(profile.endpointType ? { endpointType: profile.endpointType } : {}),
        ...(profile.canonicalModelId ? { canonicalModelId: profile.canonicalModelId } : {}),
        ...(profile.modelFamily ? { modelFamily: profile.modelFamily } : {}),
        imageInput: profile.imageInput ?? "auto",
        ...(profile.contextWindowOverride ? { contextWindowOverride: profile.contextWindowOverride } : {}),
        ...(profile.maxTokensOverride ? { maxTokensOverride: profile.maxTokensOverride } : {}),
      }])),
      ...(config.systemPrompt?.trim() ? { systemPrompt: config.systemPrompt } : {}),
    } satisfies PersistedModelConfig,
  });
}

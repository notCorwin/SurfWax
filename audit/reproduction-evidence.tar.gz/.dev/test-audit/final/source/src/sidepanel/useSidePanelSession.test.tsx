import { act } from "react";
import { createRoot } from "react-dom/client";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { activeRunIdentity } from "../agent/coordinator";
import { CATALOG_CACHE_KEY } from "../agent/model-limits";
import { MODEL_CONFIG_STORAGE_KEY } from "./config";
import { useSidePanelSession, type SidePanelSession } from "./useSidePanelSession";

vi.mock("../agent/coordinator", () => ({ activeRunIdentity: vi.fn(async () => undefined) }));

function deferred<T>() {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>((done) => { resolve = done; });
  return { promise, resolve };
}

const legacy = () => ({ selectedProviderId: "openai", profiles: { openai: {
  providerId: "openai", sdk: "@ai-sdk/openai", baseURL: "https://provider.test/v1", model: "legacy", providerSettings: { apiKey: "saved" },
} } });
const custom = (model: string) => ({ selectedProviderId: "custom", profiles: { custom: {
  providerId: "custom", sdk: "@ai-sdk/openai-compatible", baseURL: "https://custom.test/v1", model, providerSettings: { apiKey: "saved" },
} } });
const catalog = { openai: { npm: "@ai-sdk/openai", models: { legacy: { provider: { shape: "completions" } } } } };

type ChangeListener = (changes: Record<string, chrome.storage.StorageChange>, area: string) => void;
let listeners: Set<ChangeListener>;
let values: Record<string, unknown>;
let set: ReturnType<typeof vi.fn>;
let latest: SidePanelSession;
let root: ReturnType<typeof createRoot>;
let host: HTMLDivElement;
let mounted: boolean;

function Harness() {
  latest = useSidePanelSession();
  return <output>{latest.config.model}</output>;
}

beforeEach(() => {
  (globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
  listeners = new Set();
  values = { [MODEL_CONFIG_STORAGE_KEY]: legacy() };
  set = vi.fn(async (items: Record<string, unknown>) => { Object.assign(values, items); });
  vi.stubGlobal("chrome", {
    storage: {
      local: { get: vi.fn(async (key: string) => ({ [key]: values[key] })), set },
      onChanged: { addListener: (listener: ChangeListener) => listeners.add(listener), removeListener: (listener: ChangeListener) => listeners.delete(listener) },
    },
    runtime: { onMessage: { addListener: vi.fn(), removeListener: vi.fn() } },
  });
  vi.mocked(activeRunIdentity).mockReset().mockResolvedValue(undefined);
  host = document.createElement("div");
  document.body.append(host);
  root = createRoot(host);
  mounted = true;
});

afterEach(async () => {
  if (mounted) await act(async () => root.unmount());
  host.remove();
  vi.restoreAllMocks();
});

async function replaceSettings(settings: unknown) {
  await act(async () => {
    values[MODEL_CONFIG_STORAGE_KEY] = settings;
    for (const listener of listeners) listener({ [MODEL_CONFIG_STORAGE_KEY]: { newValue: settings } }, "local");
  });
}

describe("sidepanel configuration refresh", () => {
  it.each([MODEL_CONFIG_STORAGE_KEY, CATALOG_CACHE_KEY])("completes first hydration during another panel's run when %s supersedes its initial read", async (key) => {
    const first = deferred<Record<string, unknown>>();
    vi.mocked(chrome.storage.local.get).mockImplementationOnce(() => first.promise);
    vi.mocked(activeRunIdentity).mockResolvedValue({ runId: "other-run", ownerId: "other-panel", generation: 1 });
    await act(async () => root.render(<Harness />));
    const saved = custom("saved-model");
    values[MODEL_CONFIG_STORAGE_KEY] = saved;
    await act(async () => {
      for (const listener of listeners) listener({ [key]: { newValue: values[key] } }, "local");
    });
    expect(latest.configured).toBe(true);
    expect(latest.config.model).toBe("saved-model");
    await act(async () => first.resolve({ [MODEL_CONFIG_STORAGE_KEY]: custom("stale-model") }));
    expect(latest.config.model).toBe("saved-model");
    expect(set).not.toHaveBeenCalled();
  });

  it("defers configuration changes once hydration is complete and a run is active", async () => {
    values[MODEL_CONFIG_STORAGE_KEY] = custom("running-model");
    await act(async () => root.render(<Harness />));
    expect(latest.configured).toBe(true);
    vi.mocked(activeRunIdentity).mockResolvedValue({ runId: "active-run", ownerId: "owner", generation: 1 });
    await replaceSettings(custom("next-model"));
    expect(latest.configured).toBe(true);
    expect(latest.config.model).toBe("running-model");
  });

  it("retains the last configuration and exposes the cause when a later read fails", async () => {
    values[MODEL_CONFIG_STORAGE_KEY] = custom("initial");
    await act(async () => root.render(<Harness />));
    await vi.waitFor(() => expect(latest.configured).toBe(true));
    vi.mocked(chrome.storage.local.get).mockRejectedValueOnce(new Error("settings storage unavailable"));
    await replaceSettings(custom("changed"));
    expect(latest.config.model).toBe("initial");
    expect(latest.error).toEqual(expect.objectContaining({ message: "settings storage unavailable" }));
  });
  it("uses the bundled catalog immediately when offline without changing settings", async () => {
    values[MODEL_CONFIG_STORAGE_KEY] = { ...legacy(), profiles: { openai: { ...legacy().profiles.openai, model: "gpt-5" } } };
    const original = values[MODEL_CONFIG_STORAGE_KEY];
    const fetch = vi.fn()
      .mockRejectedValueOnce(new TypeError("offline"))
      .mockResolvedValueOnce(new Response("temporarily unavailable", { status: 503 }))
      .mockResolvedValueOnce(Response.json(catalog));
    vi.stubGlobal("fetch", fetch);
      await act(async () => root.render(<Harness />));
      await vi.waitFor(() => expect(fetch).toHaveBeenCalledOnce());
      await vi.waitFor(() => expect(latest.configReady).toBe(true));
      expect(latest.configured).toBe(true);
      expect(latest.error).toBeUndefined();
      expect(latest.config.model).toBe("gpt-5");
      expect(latest.config.modelProvider).toBeUndefined();
      expect(latest.error).toBeUndefined();
      expect(values[MODEL_CONFIG_STORAGE_KEY]).toBe(original);
      expect(set.mock.calls.some(([items]) => Object.hasOwn(items, MODEL_CONFIG_STORAGE_KEY))).toBe(false);
  });

  it("hydrates legacy routing from the bundled snapshot without persisting settings", async () => {
    values[MODEL_CONFIG_STORAGE_KEY] = { ...legacy(), profiles: { openai: { ...legacy().profiles.openai, model: "gpt-5" } } };
    const original = values[MODEL_CONFIG_STORAGE_KEY];
    vi.stubGlobal("fetch", vi.fn(async () => Response.json(catalog)));
    await act(async () => root.render(<Harness />));
    await vi.waitFor(() => expect(latest.configReady).toBe(true));
    expect(latest.config.modelProvider).toBeUndefined();
    expect(latest.configured).toBe(true);
    expect(values[MODEL_CONFIG_STORAGE_KEY]).toBe(original);
    expect(set.mock.calls.some(([items]) => Object.hasOwn(items, MODEL_CONFIG_STORAGE_KEY))).toBe(false);
  });

  it("rehydrates settings when a background catalog refresh commits", async () => {
    values[MODEL_CONFIG_STORAGE_KEY] = custom("current-model");
    await act(async () => root.render(<Harness />));
    await vi.waitFor(() => expect(latest.configReady).toBe(true));
    const previous = latest.config;
    await act(async () => {
      for (const listener of listeners) listener({ [CATALOG_CACHE_KEY]: { newValue: { version: 2 } } }, "local");
    });
    await vi.waitFor(() => expect(latest.config).not.toBe(previous));
    expect(latest.error).toBeUndefined();
  });

  it("aborts an old refresh and never lets its late result replace newer settings", async () => {
    const pending = deferred<Response>();
    let signal: AbortSignal | undefined;
    vi.stubGlobal("fetch", vi.fn((_input: RequestInfo | URL, init?: RequestInit) => {
      signal = init?.signal ?? undefined;
      // Deliberately ignore cancellation to exercise stale-result guards too.
      return pending.promise;
    }));
    await act(async () => root.render(<Harness />));
    await vi.waitFor(() => expect(signal).toBeDefined());
    expect(signal?.aborted).toBe(false);
    const newer = custom("new-profile");
    await replaceSettings(newer);
    expect(signal?.aborted).toBe(true);
    expect(latest.config.model).toBe("new-profile");
    expect(latest.error).toBeUndefined();
    await act(async () => pending.resolve(Response.json(catalog)));
    expect(latest.config.model).toBe("new-profile");
    expect(latest.error).toBeUndefined();
    expect(values[MODEL_CONFIG_STORAGE_KEY]).toBe(newer);
    expect(set.mock.calls.some(([items]) => Object.hasOwn(items, MODEL_CONFIG_STORAGE_KEY))).toBe(false);
  });

  it("aborts an in-flight catalog request and removes listeners on unmount", async () => {
    values[MODEL_CONFIG_STORAGE_KEY] = { ...legacy(), profiles: { openai: { ...legacy().profiles.openai, model: "gpt-5" } } };
    let signal: AbortSignal | undefined;
    const fetch = vi.fn((_input: RequestInfo | URL, init?: RequestInit) => new Promise<Response>((_resolve, reject) => {
      signal = init?.signal ?? undefined;
      signal!.addEventListener("abort", () => reject(signal!.reason), { once: true });
    }));
    vi.stubGlobal("fetch", fetch);
    await act(async () => root.render(<Harness />));
    await vi.waitFor(() => expect(signal).toBeDefined());
    expect(signal?.aborted).toBe(false);
    await act(async () => { root.unmount(); mounted = false; });
    expect(signal?.aborted).toBe(true);
    expect(listeners.size).toBe(0);
    expect(fetch).toHaveBeenCalledOnce();
    expect(set).not.toHaveBeenCalled();
  });

  it("also ignores a stale result delayed by the active-run check", async () => {
    values[MODEL_CONFIG_STORAGE_KEY] = custom("initial");
    await act(async () => root.render(<Harness />));
    const pending = deferred<Awaited<ReturnType<typeof activeRunIdentity>>>();
    vi.mocked(activeRunIdentity).mockImplementationOnce(() => pending.promise);
    await replaceSettings(custom("older"));
    expect(latest.config.model).toBe("initial");
    await replaceSettings(custom("newest"));
    expect(latest.config.model).toBe("newest");
    await act(async () => pending.resolve(undefined));
    expect(latest.config.model).toBe("newest");
    expect(latest.error).toBeUndefined();
  });

  it("does not schedule a retry backoff after the bundled offline fallback succeeds", async () => {
    values[MODEL_CONFIG_STORAGE_KEY] = { ...legacy(), profiles: { openai: { ...legacy().profiles.openai, model: "gpt-5" } } };
    const fetch = vi.fn(async () => { throw new TypeError("offline"); });
    vi.stubGlobal("fetch", fetch);
      await act(async () => root.render(<Harness />));
      await vi.waitFor(() => expect(fetch).toHaveBeenCalledOnce());
      await vi.waitFor(() => expect(latest.configReady).toBe(true));
      expect(latest.error).toBeUndefined();
      await act(async () => { root.unmount(); mounted = false; });
      expect(fetch).toHaveBeenCalledOnce();
      expect(set).not.toHaveBeenCalled();
  });
});

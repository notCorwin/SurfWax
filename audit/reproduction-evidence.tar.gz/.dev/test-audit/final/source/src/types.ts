export type JsonPrimitive = string | number | boolean | null;
export type JsonValue = JsonPrimitive | JsonValue[] | { [key: string]: JsonValue };

export type BrowserSelector = {
  by: "role" | "text" | "label" | "placeholder" | "alt" | "title" | "testId" | "css";
  value: string;
  name?: string;
  exact?: boolean;
  index?: number;
  scope?: { by: "css"; value: string } | { by: "role"; value: string; name?: string; exact?: boolean };
  frame?: { by: "css"; value: string } | { ref: string };
};

export type BrowserTarget =
  | { ref: string }
  | BrowserSelector
  | { point: { observationId: string; x: number; y: number } };

export const MODEL_SDKS = [
  "@ai-sdk/amazon-bedrock",
  "@ai-sdk/amazon-bedrock/mantle",
  "@ai-sdk/anthropic",
  "@ai-sdk/azure",
  "@ai-sdk/cerebras",
  "@ai-sdk/cohere",
  "@ai-sdk/deepinfra",
  "@ai-sdk/deepseek",
  "@ai-sdk/gateway",
  "@ai-sdk/google",
  "@ai-sdk/google-vertex",
  "@ai-sdk/google-vertex/anthropic",
  "@ai-sdk/groq",
  "@ai-sdk/mistral",
  "@ai-sdk/openai",
  "@ai-sdk/openai-compatible",
  "@ai-sdk/perplexity",
  "@ai-sdk/togetherai",
  "@ai-sdk/vercel",
  "@ai-sdk/xai",
  "@aihubmix/ai-sdk-provider",
  "@jerome-benoit/sap-ai-provider-v2",
  "@openrouter/ai-sdk-provider",
  "@qvac/ai-sdk-provider",
  "@saladtechnologies-oss/ai-sdk-provider",
  "ai-gateway-provider",
  "gitlab-ai-provider",
  "merge-gateway-ai-sdk-provider",
  "venice-ai-sdk-provider",
  "watsonx-ai-provider",
] as const;

export type ModelSdk = typeof MODEL_SDKS[number];

export function isModelSdk(value: unknown): value is ModelSdk {
  return typeof value === "string" && (MODEL_SDKS as readonly string[]).includes(value);
}

export type ModelConfig = {
  providerId?: string;
  sdk?: ModelSdk;
  providerSettings?: Record<string, string>;
  /** Models.dev per-model transport defaults, kept separate from user credentials. */
  modelProvider?: ModelProviderOverride;
  baseURL: string;
  /** Optional user override for a Models.dev provider endpoint. */
  baseURLOverride?: string;
  model: string;
  contextWindowOverride?: number;
  maxTokensOverride?: number;
  endpointType?: ModelEndpointType;
  canonicalModelId?: string;
  modelFamily?: string;
  imageInput?: "auto" | "enabled" | "disabled";
};

export const MODEL_ENDPOINT_TYPES = [
  "openai-chat-completions",
  "openai-completions",
  "openai-responses",
  "anthropic-messages",
  "google-generate-content",
  "google-interactions",
] as const;
export type ModelEndpointType = typeof MODEL_ENDPOINT_TYPES[number];

export type ModelProviderOverride = {
  npm?: string;
  api?: string;
  shape?: string;
  body?: Record<string, JsonValue>;
  headers?: Record<string, string>;
};

import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { ChevronRightIcon, LoaderCircleIcon } from "lucide-react";
import { Tabs } from "radix-ui";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "../components/ui/card";
import { Field, FieldDescription, FieldGroup, FieldLabel } from "../components/ui/field";
import { Input } from "../components/ui/input";
import { Textarea } from "../components/ui/textarea";
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { ErrorNotice } from "../components/ui/error-notice";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "../components/ui/alert-dialog";
import { SearchCombobox, type SearchComboboxOption } from "./SearchCombobox";
import { EventLogger } from "../logging";
import { applyModelPreset, loadModelCatalog, modelPresetFields, modelProviderPresets, type ModelProviderPreset } from "../agent/model-limits";
import { useModelLimit } from "./useModelLimit";
import { modelConfigErrors, resolvedBaseURL, type ProviderSettingField } from "../agent/model-sdks";
import type { ModelProfile } from "../sidepanel/config";
import {
  EMPTY_MODEL_CONFIG,
  loadModelConfig,
  saveModelConfig,
  selectedModelConfig,
} from "../sidepanel/config";
import "../styles.css";
import "./styles.css";

type Status = "idle" | "saving" | "clearing" | "saved" | "error";
type ModelField = "providerId" | "baseURL" | "baseURLOverride" | "model" | "contextWindowOverride" | "maxTokensOverride" | "endpointType" | "imageInput" | string;

export function OptionsApp() {
  const [modelSettings, setModelSettings] = useState(EMPTY_MODEL_CONFIG);
  const [providers, setProviders] = useState<ModelProviderPreset[]>([]);
  const [providerInput, setProviderInput] = useState("");
  const [catalogError, setCatalogError] = useState<unknown>();
  const [catalogStale, setCatalogStale] = useState(false);
  const [ready, setReady] = useState(false);
  const [status, setStatus] = useState<Status>("idle");
  const [message, setMessage] = useState("");
  const [errorDetail, setErrorDetail] = useState<unknown>();
  const [fieldErrors, setFieldErrors] = useState<Partial<Record<ModelField, string>>>({});
  const [clearConfirmationOpen, setClearConfirmationOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("model");
  const [errorFocus, setErrorFocus] = useState<string>();
  const [clearMessage, setClearMessage] = useState("");
  const [clearError, setClearError] = useState<unknown>();
  const savedConfig = useRef(JSON.stringify({ modelSettings: EMPTY_MODEL_CONFIG, providerInput: "" }));
  const dirty = ready && JSON.stringify({ modelSettings, providerInput }) !== savedConfig.current;
  const storedProfile = selectedModelConfig(modelSettings);
  const selectedProvider = providers.find((provider) => provider.id === modelSettings.selectedProviderId);
  const providerOptions = useMemo<SearchComboboxOption[]>(() => [
    { value: "custom", label: "自定义 Endpoint" },
    ...providers.map((provider) => ({ value: provider.id, label: provider.name })),
  ], [providers]);
  const config = storedProfile && selectedProvider
    ? applyModelPreset(storedProfile, selectedProvider)
    : storedProfile;
  const matchedLimit = useModelLimit(config, ready);
  const settingFields: ProviderSettingField[] = config ? modelPresetFields(config, selectedProvider) : [];
  const routingErrors = config ? modelConfigErrors(config, settingFields) : {};
  const routingError = routingErrors.sdk ?? routingErrors.shape ?? routingErrors.body ?? routingErrors.headers;
  const fail = (summary: string, error: unknown) => {
    setStatus("error");
    setMessage(summary);
    setErrorDetail(error);
  };
  const logger = useMemo(() => new EventLogger({ onError: (error) => fail("事件日志不可用。", error) }), []);

  useEffect(() => {
    let active = true;
    const catalog = loadModelCatalog({ refresh: true, onStale: () => { if (active) setCatalogStale(true); } });
    void Promise.all([
      // Always restore all settings for repair, even when migration cannot fetch a catalog.
      loadModelConfig(undefined, undefined, { migrateCatalogRouting: false }),
      catalog.then(modelProviderPresets).catch((error) => { if (active) setCatalogError(error); return []; }),
    ]).then(([stored, catalogProviders]) => {
      if (!active) return;
      setModelSettings(stored);
      setProviderInput(stored.selectedProviderId);
      setProviders(catalogProviders);
      savedConfig.current = JSON.stringify({ modelSettings: stored, providerInput: stored.selectedProviderId });
    }).catch((error) => {
      if (!active) return;
      fail("配置读取失败。", error);
    }).finally(() => {
      if (active) setReady(true);
    });
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    const warn = (event: BeforeUnloadEvent) => {
      if (JSON.stringify({ modelSettings, providerInput }) === savedConfig.current) return;
      event.preventDefault();
      event.returnValue = "";
    };
    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, [modelSettings, providerInput]);

  useEffect(() => {
    if (!errorFocus || activeTab !== "model") return;
    const field = document.getElementById(errorFocus);
    field?.closest("details")?.setAttribute("open", "");
    field?.focus();
    setErrorFocus(undefined);
  }, [activeTab, errorFocus]);

  const update = (field: Exclude<ModelField, "providerId">, value: string) => {
    if (!config) return;
    setModelSettings((current) => ({ ...current, profiles: { ...current.profiles, [config.providerId]: {
      ...config, [field]: field === "contextWindowOverride" || field === "maxTokensOverride" ? (value ? Number(value) : undefined) : value,
      // A new free-text model must never inherit the previous model's route.
      ...(field === "model" ? {
        modelProvider: undefined,
        canonicalModelId: selectedProvider?.models.find((model) => model.id === value)?.canonicalModelId,
        modelFamily: selectedProvider?.models.find((model) => model.id === value)?.family,
        ...(config.modelProvider?.api !== undefined && selectedProvider ? { baseURL: selectedProvider.baseURL } : {}),
      } : {}),
    } } }));
    setFieldErrors((current) => field === "model" ? {} : { ...current, [field]: undefined });
    setStatus("idle");
    setMessage("");
    setErrorDetail(undefined);
  };

  const updateSetting = (key: string, value: string) => {
    if (!config) return;
    setModelSettings((current) => ({ ...current, profiles: { ...current.profiles, [config.providerId]: {
      ...config, providerSettings: { ...config.providerSettings, [key]: value },
    } } }));
    setFieldErrors((current) => ({ ...current, [key]: undefined }));
    setStatus("idle");
    setMessage("");
    setErrorDetail(undefined);
  };

  const updateSystemPrompt = (value: string) => {
    setModelSettings((current) => ({ ...current, systemPrompt: value }));
    setStatus("idle");
    setMessage("");
    setErrorDetail(undefined);
  };

  const changeProvider = (value: string) => {
    setProviderInput(value);
    const preset = providers.find((provider) => provider.id === value);
    if (value !== "custom" && !preset) return;
    setModelSettings((current) => ({
      ...current,
      selectedProviderId: value,
      profiles: current.profiles[value] ? current.profiles : { ...current.profiles, [value]: {
        providerId: value,
        sdk: preset?.sdk ?? "@ai-sdk/openai-compatible",
        providerSettings: {},
        baseURL: preset?.baseURL ?? "",
        model: "",
        ...(value === "custom" ? { endpointType: "openai-chat-completions" as const } : {}),
        imageInput: "auto",
      } satisfies ModelProfile },
    }));
    setFieldErrors({});
    setStatus("idle");
    setMessage("");
    setErrorDetail(undefined);
  };

  const save = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const errors: Partial<Record<ModelField, string>> = {};
    if (!modelSettings.selectedProviderId || providerInput !== modelSettings.selectedProviderId) errors.providerId = "请选择 Provider";
    if (config) Object.assign(errors, modelConfigErrors(config, settingFields));
    setFieldErrors(errors);
    if (Object.keys(errors).length) {
      setStatus("error");
      setMessage("请检查标出的字段");
      setErrorDetail(undefined);
      const firstMainError = ["providerId", "baseURL", "baseURLOverride", "model", ...settingFields.map(({ key }) => key), "contextWindowOverride", "maxTokensOverride"]
        .find((key) => errors[key]) as ModelField | undefined;
      const firstErrorId = firstMainError
        ? ({ providerId: "provider-id", baseURL: "base-url", baseURLOverride: "base-url", model: "model-id", apiKey: "api-key", contextWindowOverride: "context-window", maxTokensOverride: "max-tokens", imageInput: "image-input" }[firstMainError] ?? `provider-setting-${firstMainError}`)
        : undefined;
      if (firstErrorId) {
        setActiveTab("model");
        setErrorFocus(firstErrorId);
      }
      return;
    }

    setStatus("saving");
    setMessage("正在保存配置…");
    try {
      const savedModelSettings = { ...modelSettings, profiles: { ...modelSettings.profiles,
        ...(config ? { [config.providerId]: config } : {}),
      } };
      await saveModelConfig(savedModelSettings);
      setModelSettings(savedModelSettings);
      savedConfig.current = JSON.stringify({ modelSettings: savedModelSettings, providerInput });
      setStatus("saved");
      setMessage("配置已保存，Side Panel 会立即使用新配置");
    } catch (error) {
      fail("配置保存失败。", error);
    }
  };

  const clearLog = async () => {
    setStatus("clearing");
    setClearMessage("正在清空对话与日志…");
    setClearError(undefined);
    try {
      const result = await chrome.runtime.sendMessage({ type: "side-agent:clear-log" });
      if (!result?.ok) throw new Error(result?.error ?? "后台未确认日志清空，请重试。");
      setClearMessage("对话与事件日志已清空");
    } catch (error) {
      setClearMessage("日志清空失败。");
      setClearError(error);
    } finally {
      setStatus("idle");
    }
  };

  const busy = !ready || status === "saving" || status === "clearing";
  const customProvider = modelSettings.selectedProviderId === "custom";
  const baseURLField = config && <Field data-disabled={busy || undefined} data-invalid={!!(fieldErrors.baseURL || fieldErrors.baseURLOverride) || undefined}>
    <FieldLabel htmlFor="base-url">Base URL</FieldLabel>
    <Input id="base-url" name={customProvider ? "baseURL" : "baseURLOverride"} type="url" autoComplete="url"
      aria-invalid={!!(fieldErrors.baseURL || fieldErrors.baseURLOverride)} aria-describedby={fieldErrors.baseURL || fieldErrors.baseURLOverride ? "base-url-error" : undefined}
      value={customProvider ? config.baseURL : config.baseURLOverride ?? ""} disabled={busy}
      placeholder={customProvider ? "https://provider.example/v1" : resolvedBaseURL({ ...config, baseURLOverride: undefined }) || "由 SDK 自动配置"}
      onChange={(event) => update(customProvider ? "baseURL" : "baseURLOverride", event.target.value)} />
    {(fieldErrors.baseURL || fieldErrors.baseURLOverride) && <p id="base-url-error" className="field-error" role="alert">{fieldErrors.baseURL || fieldErrors.baseURLOverride}</p>}
    <FieldDescription>{customProvider ? "填写所选协议的根地址；可包含 /v1、/v1beta 或 /v1beta/openai。" : "留空使用 Models.dev 绑定地址；填写后覆盖当前 Provider 地址。"}</FieldDescription>
  </Field>;

  return (
    <main className="options-shell">
      <a className="skip-link" href="#options-content">跳转到配置</a>
      <header className="options-header">
        <h1>设置</h1>
      </header>

      <Tabs.Root id="options-content" tabIndex={-1} className="options-tabs" value={activeTab} onValueChange={setActiveTab}>
        <Tabs.List className="options-tabs-list" aria-label="设置分类">
          <Tabs.Trigger className="options-tab" value="model">模型与连接</Tabs.Trigger>
          <Tabs.Trigger className="options-tab" value="agent">智能体</Tabs.Trigger>
          <Tabs.Trigger className="options-tab" value="data">数据管理</Tabs.Trigger>
        </Tabs.List>
        {(activeTab !== "data" || dirty) && <div className="options-save-area">
          {status === "error" && (errorDetail !== undefined
            ? <ErrorNotice summary={message} error={errorDetail} />
            : <p className="options-status" data-state="error" role="alert">{message}</p>)}
          <div className="options-actions">
            <p className="options-status" role="status" aria-live="polite">
              {!ready ? "正在读取配置…" : status === "saving" ? "正在保存配置…" : dirty ? "有未保存的更改" : status === "saved" ? message : "所有更改已保存"}
            </p>
            <Button type="submit" form="options-form" disabled={busy} aria-busy={status === "saving"}>
              {status === "saving" && <LoaderCircleIcon className="animate-spin" aria-hidden="true" />}
              保存配置
            </Button>
          </div>
        </div>}
        <form id="options-form" className="options-form" noValidate onSubmit={(event) => void save(event)}>
        <Tabs.Content value="model" forceMount hidden={activeTab !== "model"}>
        <Card data-testid="options-card">
          <CardHeader>
            <CardTitle>模型与连接</CardTitle>
          </CardHeader>
          <CardContent>
            <FieldGroup>
              <Field data-disabled={busy || undefined} data-invalid={!!fieldErrors.providerId || undefined}>
                <FieldLabel htmlFor="provider-id">Provider</FieldLabel>
                <SearchCombobox id="provider-id" name="providerId" options={providerOptions} value={providerInput}
                  onValueChange={changeProvider} disabled={busy} placeholder="搜索或选择 Provider…"
                  aria-invalid={!!fieldErrors.providerId} aria-describedby={fieldErrors.providerId ? "provider-id-error" : !ready || catalogError || catalogStale ? "provider-description" : undefined} />
                {(!ready || catalogError || catalogStale) && <FieldDescription id="provider-description">
                  {!ready ? "正在加载 Models.dev Provider 目录…" : catalogError
                    ? "Models.dev 暂时不可用；仍可选择 custom 使用自定义 Endpoint。"
                    : `Models.dev 暂时不可用，正在使用缓存目录（${providers.length.toLocaleString()} 个 Provider）。`}
                </FieldDescription>}
                {fieldErrors.providerId && <p id="provider-id-error" className="field-error" role="alert">{fieldErrors.providerId}</p>}
              </Field>
              {config && <>
                {customProvider && baseURLField}
                <Field data-disabled={busy || undefined} data-invalid={!!fieldErrors.model || undefined}>
                  <FieldLabel htmlFor="model-id">Model ID</FieldLabel>
                  <SearchCombobox id="model-id" name="model" allowCustom
                    options={selectedProvider?.models.map((model) => ({ value: model.id, label: model.name })) ?? []}
                    value={config.model} disabled={busy} onValueChange={(value) => update("model", value)}
                    aria-invalid={!!fieldErrors.model} aria-describedby={fieldErrors.model ? "model-id-error" : undefined} />
                  {fieldErrors.model && <p id="model-id-error" className="field-error" role="alert">{fieldErrors.model}</p>}
                  {routingError && <p className="field-error" role="alert">{routingError}</p>}
                  {selectedProvider && selectedProvider.models.length === 0 && <FieldDescription>
                    Models.dev 当前没有符合文本输出与 tool_call 条件的目录模型；可手填 Model ID，浏览器工具可能不可用。
                  </FieldDescription>}
                </Field>
                {settingFields.map((item) => {
                  const id = item.key === "apiKey" ? "api-key" : `provider-setting-${item.key}`;
                  const errorId = `${id}-error`;
                  const value = config.providerSettings[item.key] ?? "";
                  return <Field key={item.key} data-disabled={busy || undefined} data-invalid={!!fieldErrors[item.key] || undefined}>
                    <FieldLabel htmlFor={id}>{item.label}</FieldLabel>
                    {item.type === "textarea"
                      ? <Textarea id={id} name={item.key} autoComplete="off" placeholder={item.placeholder} aria-invalid={!!fieldErrors[item.key]}
                        aria-describedby={fieldErrors[item.key] ? errorId : undefined} value={value} disabled={busy} onChange={(event) => updateSetting(item.key, event.target.value)} />
                      : <Input id={id} name={item.key} type={item.type ?? "text"} autoComplete="off" placeholder={item.placeholder}
                        aria-invalid={!!fieldErrors[item.key]} aria-describedby={fieldErrors[item.key] ? errorId : undefined} value={value} disabled={busy}
                        onChange={(event) => updateSetting(item.key, event.target.value)} />}
                    {item.description && <FieldDescription>{item.description}</FieldDescription>}
                    {fieldErrors[item.key] && <p id={errorId} className="field-error" role="alert">{fieldErrors[item.key]}</p>}
                  </Field>;
                })}
                {matchedLimit?.source === "estimated" && <Field>
                  <FieldLabel>上下文窗口未匹配</FieldLabel>
                  <p data-testid="model-limit-match" className="model-limit-match">
                    Models.dev 未提供可靠匹配；当前按 {matchedLimit.context.toLocaleString()} tokens 估算，可在高级设置中手动覆盖。
                  </p>
                  {config.contextWindowOverride && <p className="model-limit-match">当前生效：手动指定 {config.contextWindowOverride.toLocaleString()} tokens</p>}
                </Field>}
              </>}
              <details className="advanced-settings">
                <summary><ChevronRightIcon aria-hidden="true" /><span>高级设置</span></summary>
                <div className="advanced-settings-content">
                  {customProvider && <Field data-disabled={busy || !config || undefined}>
                    <FieldLabel htmlFor="endpoint-type">协议</FieldLabel>
                    <Select value={config?.endpointType ?? "openai-chat-completions"} disabled={busy || !config} onValueChange={(value) => update("endpointType", value)}>
                      <SelectTrigger id="endpoint-type" aria-label="模型端点协议" className="w-full"><SelectValue /></SelectTrigger>
                      <SelectContent position="popper"><SelectGroup>
                        <SelectItem value="openai-chat-completions">OpenAI Chat Completions</SelectItem>
                        <SelectItem value="openai-completions">OpenAI Completions</SelectItem>
                        <SelectItem value="openai-responses">OpenAI Responses</SelectItem>
                        <SelectItem value="anthropic-messages">Anthropic Messages</SelectItem>
                        <SelectItem value="google-generate-content">Google generateContent</SelectItem>
                        <SelectItem value="google-interactions">Google Interactions</SelectItem>
                      </SelectGroup></SelectContent>
                    </Select>
                  </Field>}
                  {!customProvider && baseURLField}
                  <Field data-disabled={busy || !config || undefined} data-invalid={!!fieldErrors.contextWindowOverride || undefined}>
                    <FieldLabel htmlFor="context-window">上下文窗口（tokens）</FieldLabel>
                    <Input id="context-window" name="contextWindowOverride" type="number" min="1" step="1" aria-invalid={!!fieldErrors.contextWindowOverride} aria-describedby={fieldErrors.contextWindowOverride ? "context-window-error" : undefined} value={config?.contextWindowOverride ?? ""} disabled={busy || !config}
                      onChange={(event) => update("contextWindowOverride", event.target.value)} />
                    {fieldErrors.contextWindowOverride && <p id="context-window-error" className="field-error" role="alert">{fieldErrors.contextWindowOverride}</p>}
                  </Field>
                  <Field data-disabled={busy || !config || undefined} data-invalid={!!fieldErrors.maxTokensOverride || undefined}>
                    <FieldLabel htmlFor="max-tokens">max_tokens</FieldLabel>
                    <Input id="max-tokens" name="maxTokensOverride" type="number" min="1" step="1" aria-invalid={!!fieldErrors.maxTokensOverride}
                      aria-describedby={fieldErrors.maxTokensOverride ? "max-tokens-error" : "max-tokens-description"} value={config?.maxTokensOverride ?? ""} disabled={busy || !config}
                      onChange={(event) => update("maxTokensOverride", event.target.value)} />
                    {fieldErrors.maxTokensOverride && <p id="max-tokens-error" className="field-error" role="alert">{fieldErrors.maxTokensOverride}</p>}
                    <FieldDescription id="max-tokens-description">自动采用模型输出限制，可手动覆盖；未知模型默认 128,000。</FieldDescription>
                  </Field>
                  <Field data-disabled={busy || !config || undefined}>
                    <FieldLabel htmlFor="image-input">视觉能力</FieldLabel>
                    <Select value={config?.imageInput ?? "auto"} disabled={busy || !config} onValueChange={(value) => update("imageInput", value)}>
                      <SelectTrigger id="image-input" aria-label="图片输入能力" className="w-full"><SelectValue /></SelectTrigger>
                      <SelectContent position="popper"><SelectGroup>
                        <SelectItem value="auto">自动检测</SelectItem>
                        <SelectItem value="enabled">支持</SelectItem>
                        <SelectItem value="disabled">不支持</SelectItem>
                      </SelectGroup></SelectContent>
                    </Select>
                    <FieldDescription>自动模式读取模型目录；未知模型默认仅使用语义路径。</FieldDescription>
                  </Field>
                </div>
              </details>
            </FieldGroup>
          </CardContent>
        </Card>
        </Tabs.Content>

        <Tabs.Content value="agent" forceMount hidden={activeTab !== "agent"}>
        <Card>
          <CardHeader>
            <CardTitle>智能体</CardTitle>
          </CardHeader>
          <CardContent>
            <Field data-disabled={busy || undefined}>
              <FieldLabel htmlFor="system-prompt">自定义系统提示词</FieldLabel>
              <Textarea id="system-prompt" name="systemPrompt" autoComplete="off" value={modelSettings.systemPrompt ?? ""} disabled={busy}
                onChange={(event) => updateSystemPrompt(event.target.value)} />
              <FieldDescription>留空使用内置提示词；填写后将完整替换内置提示词。所有 Provider 共用此设置。</FieldDescription>
            </Field>
          </CardContent>
        </Card>

        </Tabs.Content>



        <Tabs.Content value="data" forceMount hidden={activeTab !== "data"}>
          <Card>
            <CardHeader>
              <CardTitle>数据管理</CardTitle>
            </CardHeader>
            <CardFooter>
              <Button type="button" variant="destructive" data-testid="event-log-clear" disabled={busy} onClick={() => setClearConfirmationOpen(true)}>
                {status === "clearing" && <LoaderCircleIcon className="animate-spin" aria-hidden="true" />}
                清空对话与日志
              </Button>
            </CardFooter>
          </Card>
          {clearMessage && (clearError !== undefined
            ? <ErrorNotice summary={clearMessage} error={clearError} />
            : <p className="options-status" role="status">{clearMessage}</p>)}
        </Tabs.Content>
        </form>
      </Tabs.Root>

      <AlertDialog open={clearConfirmationOpen} onOpenChange={setClearConfirmationOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>清空全部本地对话与事件日志？</AlertDialogTitle>
            <AlertDialogDescription>此操作不可恢复。模型配置和用户脚本不会被删除。</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={status === "clearing"}>取消</AlertDialogCancel>
            <AlertDialogAction variant="destructive" disabled={status === "clearing"} onClick={() => void clearLog()}>确认清空</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </main>
  );
}

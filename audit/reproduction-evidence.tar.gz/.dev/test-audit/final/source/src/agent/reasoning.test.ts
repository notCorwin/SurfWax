import { describe, expect, it, vi } from "vitest";
import { endpointEfforts, ReasoningSettings } from "./reasoning";

const config = { baseURL: "https://provider.test/v1", model: "test-model", providerSettings: { apiKey: "secret" } };

function storage() {
  let saved: Record<string, unknown> = {};
  return {
    async get(key: string) { return { [key]: saved[key] }; },
    async set(items: Record<string, unknown>) { saved = { ...saved, ...items }; },
  };
}

describe("reasoning settings", () => {
  it("becomes ready from local state, then applies exact endpoint options", async () => {
    const fetch = vi.fn(async () => new Response(JSON.stringify({ data: [
      { id: "other", reasoning: { supported_efforts: ["high"] } },
      { id: "test-model", reasoning: { supported_efforts: ["high", "none", "low"] } },
    ] })));
    const settings = new ReasoningSettings(config, {
      fetch,
      modelLimit: async () => ({ provider: "provider", model: "test-model", context: 1000, source: "models.dev", reasoningEfforts: ["medium"] }),
    });
    await settings.ready;
    expect(settings.snapshot()).toMatchObject({ selected: null, source: "unknown", ready: true });
    await vi.waitFor(() => expect(settings.snapshot()).toMatchObject({ selected: "low", choices: ["none", "low", "high"], source: "endpoint" }));
    expect(endpointEfforts({ data: [{ id: "different", reasoning: { supported_efforts: ["high"] } }] }, "test-model")).toBeUndefined();
    expect(endpointEfforts({ data: [{ id: "test-model", reasoning: { supported_efforts: null, mandatory: true } }] }, "test-model"))
      .toEqual(["minimal", "low", "medium", "high", "xhigh", "max"]);
  });

  it("uses provider catalog options and restores a manual choice", async () => {
    const local = storage();
    const options = {
      storage: local,
      fetch: vi.fn(async () => new Response("not found", { status: 404 })),
      modelLimit: async () => ({ provider: "provider", model: "test-model", context: 1000, source: "models.dev" as const, reasoningEfforts: ["low", "high"] }),
    };
    const first = new ReasoningSettings(config, options);
    await first.ready;
    await vi.waitFor(() => expect(first.snapshot()).toMatchObject({ selected: "low", source: "models.dev" }));
    first.select("high");
    await vi.waitFor(async () => expect((await local.get("side-agent:reasoning-selections"))["side-agent:reasoning-selections"]).toBeTruthy());
    const restored = new ReasoningSettings(config, options);
    await restored.ready;
    expect(restored.snapshot().selected).toBe("high");
    expect(restored.reject("high", ["low"])).toBe("low");
    expect(restored.snapshot().selected).toBe("low");
    const key = "@ai-sdk/openai-compatible\u0000\u0000https://provider.test/v1\u0000test-model";
    await vi.waitFor(async () => expect(((await local.get("side-agent:reasoning-selections"))["side-agent:reasoning-selections"] as Record<string, any>)[key].rejected).toContain("high"));
    const learned = new ReasoningSettings(config, options);
    await learned.ready;
    await vi.waitFor(() => expect(learned.snapshot()).toMatchObject({ selected: "low", choices: ["low"] }));
  });

  it("omits reasoning when metadata is unknown", async () => {
    const settings = new ReasoningSettings(config, {
      fetch: vi.fn(async () => new Response("not found", { status: 404 })),
      modelLimit: async () => undefined,
    });
    await settings.ready;
    await vi.waitFor(() => expect(settings.snapshot()).toMatchObject({ selected: null, source: "unknown" }));
    expect(settings.reject("minimal")).toBe("none");
    expect(settings.reject("minimal", undefined, true)).toBeNull();
    expect(settings.snapshot()).toMatchObject({ selected: null, choices: [] });
  });

  it("never restores a selected effort that is also rejected", async () => {
    const key = "@ai-sdk/openai-compatible\u0000\u0000https://provider.test/v1\u0000test-model";
    const local = {
      get: async () => ({ "side-agent:reasoning-selections": { [key]: { manual: "high", rejected: ["high"], learnedAt: Date.now() } } }),
      set: async () => {},
    };
    const settings = new ReasoningSettings(config, { storage: local, fetch: async () => new Response("", { status: 404 }), modelLimit: async () => undefined });
    await settings.ready;
    expect(settings.snapshot().selected).toBeNull();
    expect(settings.snapshot().choices).not.toContain("high");
  });

  it("preserves updates to different models when writes overlap", async () => {
    let saved: Record<string, unknown> = {};
    let release!: () => void;
    const gate = new Promise<void>((resolve) => { release = resolve; });
    const local = {
      get: vi.fn(async (key: string) => ({ [key]: structuredClone(saved[key]) })),
      set: vi.fn(async (items: Record<string, unknown>) => {
        if (local.set.mock.calls.length === 1) await gate;
        saved = { ...saved, ...structuredClone(items) };
      }),
    };
    const options = { storage: local, fetch: async () => new Response("", { status: 404 }), modelLimit: async () => undefined };
    const first = new ReasoningSettings(config, options);
    const second = new ReasoningSettings({ ...config, model: "other-model" }, options);
    await Promise.all([first.ready, second.ready]);
    first.select("low");
    await vi.waitFor(() => expect(local.set).toHaveBeenCalledTimes(1));
    second.select("high");
    release();
    await vi.waitFor(() => expect(local.set).toHaveBeenCalledTimes(2));
    const entries = saved["side-agent:reasoning-selections"] as Record<string, { manual?: string }>;
    expect(Object.values(entries).map((entry) => entry.manual).sort()).toEqual(["high", "low"]);
  });

  it("does not overwrite other model settings when reading storage fails", async () => {
    let fail = false;
    const local = {
      get: vi.fn(async () => { if (fail) throw new Error("storage unavailable"); return {}; }),
      set: vi.fn(async () => {}),
    };
    const settings = new ReasoningSettings(config, { storage: local, fetch: async () => new Response("", { status: 404 }), modelLimit: async () => undefined });
    await settings.ready;
    fail = true;
    settings.select("high");
    await vi.waitFor(() => expect(local.get).toHaveBeenCalledTimes(2));
    expect(local.set).not.toHaveBeenCalled();
  });
});

describe("reasoning diagnostics", () => {
  it("reports discovery and persistence failures under the same operation without exposing credentials", async () => {
    const diagnostics: import("./diagnostics").ModelDiagnostic[] = [];
    const settings = new ReasoningSettings(config, {
      storage: { async get() { return {}; }, async set() { throw new Error("disk full"); } },
      fetch: async () => { throw new Error("network Bearer secret"); },
      modelLimit: async () => undefined,
      onDiagnostic: (event) => diagnostics.push(event),
    });
    await settings.ready;
    await vi.waitFor(() => expect(diagnostics.some((event) => event.phase === "endpoint-fetch")).toBe(true));
    settings.select("high");
    await vi.waitFor(() => expect(diagnostics.some((event) => event.phase === "persist")).toBe(true));
    expect(new Set(diagnostics.map((event) => event.operationId)).size).toBe(1);
    expect(JSON.stringify(diagnostics)).not.toContain("Bearer secret");
    expect(diagnostics.find((event) => event.phase === "persist")?.error.message).toBe("disk full");
  });
});

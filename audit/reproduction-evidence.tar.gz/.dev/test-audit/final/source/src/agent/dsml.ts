import type { LanguageModelMiddleware } from "ai";
import type { LanguageModelV4ToolCall } from "@ai-sdk/provider";
import { PROGRAM_TOOL_REGISTRY } from "../chrome/tool";
import type { EventLogger } from "../logging";
import { repairableToolProtocolError } from "./tool-protocol-error";

type Parsed = { calls: LanguageModelV4ToolCall[] } | { error: string };
type ToolSchema = { parse(input: unknown): unknown };

const DIALECTS = [
  { calls: "<｜DSML｜ calls>", endCalls: "</｜DSML｜ calls>", invoke: "<｜DSML｜ invoke name=\"", endInvoke: "</｜DSML｜ invoke>", parameter: "<｜DSML｜ parameter name=\"", endParameter: "</｜DSML｜ parameter>" },
  { calls: "<｜DSML｜tool_calls>", endCalls: "</｜DSML｜tool_calls>", invoke: "<｜DSML｜invoke name=\"", endInvoke: "</｜DSML｜invoke>", parameter: "<｜DSML｜parameter name=\"", endParameter: "</｜DSML｜parameter>" },
] as const;
const END_SENTENCE = "<｜end▁of▁sentence｜>";
const DSML_MARKER = "<｜DSML｜";

function parseDsml(text: string, activeTools: Set<string>, additionalSchemas: Readonly<Record<string, ToolSchema>>): Parsed | undefined {
  let source = text.trim();
  if (source.endsWith(END_SENTENCE)) source = source.slice(0, -END_SENTENCE.length).trimEnd();
  const dialect = DIALECTS.find(({ calls }) => source.startsWith(calls));
  if (!dialect) return source.startsWith(DSML_MARKER) ? { error: "invalid-opening-tag" } : undefined;
  const calls: LanguageModelV4ToolCall[] = [];
  let index = dialect.calls.length;
  const skipSpace = () => { while (/\s/.test(source[index] ?? "")) index++; };
  const fail = (error: string): Parsed => ({ error });

  while (true) {
    skipSpace();
    if (source.startsWith(dialect.endCalls, index)) {
      index += dialect.endCalls.length;
      return calls.length && !source.slice(index).trim() ? { calls } : fail("incomplete-or-trailing-content");
    }
    if (!source.startsWith(dialect.invoke, index)) return fail("invalid-invoke");
    index += dialect.invoke.length;
    const nameEnd = source.indexOf('\">', index);
    if (nameEnd < 0) return fail("invalid-tool-name");
    const toolName = source.slice(index, nameEnd);
    if (!activeTools.has(toolName)) return fail("unknown-or-inactive-tool");
    index = nameEnd + 2;
    const input: Record<string, unknown> = {};
    while (true) {
      skipSpace();
      if (source.startsWith(dialect.endInvoke, index)) { index += dialect.endInvoke.length; break; }
      if (!source.startsWith(dialect.parameter, index)) return fail("invalid-parameter");
      index += dialect.parameter.length;
      const header = /^(.*?)" string="(true|false)">/.exec(source.slice(index));
      if (!header || !header[1] || Object.hasOwn(input, header[1])) return fail("invalid-parameter-name");
      index += header[0].length;
      const valueEnd = source.indexOf(dialect.endParameter, index);
      if (valueEnd < 0) return fail("incomplete-parameter");
      const raw = source.slice(index, valueEnd);
      try { input[header[1]] = header[2] === "true" ? raw : JSON.parse(raw); }
      catch { return fail("invalid-json-parameter"); }
      index = valueEnd + dialect.endParameter.length;
    }
    let validated: unknown;
    try {
      const schema = additionalSchemas[toolName] ?? PROGRAM_TOOL_REGISTRY.find(({ name }) => name === toolName)?.inputSchema;
      validated = schema?.parse(input);
    } catch { return fail("invalid-tool-arguments"); }
    if (validated === undefined) return fail("unknown-tool");
    calls.push({ type: "tool-call", toolCallId: crypto.randomUUID(), toolName, input: JSON.stringify(validated), dynamic: true });
  }
}

export function dsmlMiddleware(logger?: EventLogger, conversationId?: string, additionalSchemas: Readonly<Record<string, ToolSchema>> = {}): LanguageModelMiddleware {
  const log = (result: Parsed) => logger?.telemetry({
    type: "model.dsml.recovery",
    conversationId,
    content: "calls" in result ? { recovered: true, toolNames: result.calls.map(({ toolName }) => toolName) } : { recovered: false, reason: result.error },
  });
  return {
    specificationVersion: "v4",
    wrapGenerate: async ({ doGenerate, params }) => {
      const result = await doGenerate();
      // The SDK's notification callbacks intentionally swallow exceptions. Reject
      // malformed identities here, before it can schedule any local tool calls.
      const ids = new Set<string>();
      for (const part of result.content) if (part.type === "tool-call") {
        if (typeof part.toolCallId !== "string" || !part.toolCallId.trim() || ids.has(part.toolCallId)) {
          throw repairableToolProtocolError(Object.assign(new Error("Missing or duplicate tool call ID in model response"), { code: "invalid-tool-call-id" }), JSON.stringify(result.content));
        }
        ids.add(part.toolCallId);
      }
      if (!params.tools?.some((tool) => tool.type === "function") || params.toolChoice?.type === "none") return result;
      const textParts = result.content.filter((part) => part.type === "text");
      if (!textParts.length) return result;
      const activeTools = params.tools.filter((tool) => tool.type === "function" && (params.toolChoice?.type !== "tool" || tool.name === params.toolChoice.toolName)).map((tool) => tool.name);
      const text = textParts.map((part) => part.text).join("");
      const parsed = parseDsml(text, new Set(activeTools), additionalSchemas);
      if (!parsed) return result;
      const nativeCall = result.content.some((part) => part.type === "tool-call");
      if (!nativeCall) log(parsed);
      if (!("calls" in parsed)) {
        if (nativeCall) return result;
        throw repairableToolProtocolError(Object.assign(new Error(`Invalid DSML tool response (${parsed.error}); no tool was executed.`), { code: "dsml-tool-protocol" }), text);
      }
      if (!nativeCall && result.finishReason.unified !== "stop")
        throw repairableToolProtocolError(Object.assign(new Error("The DSML response did not finish normally; no tool was executed."), { code: "dsml-tool-protocol" }), text);
      const firstText = result.content.findIndex((part) => part.type === "text");
      return { ...result,
        content: result.content.flatMap((part, index) => part.type !== "text" ? [part] : !nativeCall && index === firstText ? parsed.calls : []),
        finishReason: nativeCall ? result.finishReason : { ...result.finishReason, unified: "tool-calls" as const },
      };
    },
  };
}

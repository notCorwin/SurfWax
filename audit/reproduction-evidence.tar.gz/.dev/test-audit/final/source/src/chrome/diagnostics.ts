import { fromLogValue, type EventLogger } from "../logging";
import { safeDiagnosticError } from "../diagnostic-error";

type Debuggee = chrome.debugger.Debuggee & { sessionId?: string };
export type NetworkRecord = {
  index: number; requestRef: string; requestId: string; debuggee: Debuggee; method: string; url: string;
  requestHeaders: Record<string, string>; requestBody?: string; frameId?: string;
  loaderId?: string; superseded?: boolean;
  status?: number; statusText?: string; responseHeaders?: Record<string, string>; failed?: string; resourceType?: string;
};
export type ConsoleRecord = { index: number; level: string; text: string; timestamp?: number };
type PendingHeaders = { request?: Record<string, string>; response?: Record<string, string> };
type RequestList = { requests: Array<Record<string, unknown>>; integrity: "complete" | "incomplete"; hasMore: boolean | null; nextOffset?: number; reason?: string };
type ConsoleList = { messages: ConsoleRecord[]; integrity: "complete" | "incomplete"; hasMore: boolean | null; nextOffset?: number; reason?: string };
type CachedPage = { kind: "requests" | "console"; value: RequestList | ConsoleList; logEpoch?: string; conversationId?: string; revision: number };
type State = { epoch: string; revision: number; networkRevision: number; consoleRevision: number; nextRequest: number; nextConsole: number; consoleGeneration: number; network: NetworkRecord[]; networkLatest: Map<string, NetworkRecord>; console: ConsoleRecord[]; pendingHeaders: Map<string, PendingHeaders>;
  historical: Map<string, NetworkRecord>; pages: Map<string, CachedPage>; latest: Map<string, number>; requestVersions: Map<string, number>; invalidations: Map<string, number>; invalidBefore: number;
  captureFailures?: Set<"network" | "console">; replayComplete?: boolean; replayEpoch?: string };
const CACHE_LIMIT = 1000;
const HISTORY_CACHE_LIMIT = 128;
const PAGE_CACHE_LIMIT = 16;
const IDENTITY_LIMIT = 16_384;
const INVALIDATION_LIMIT = 4096;
// Keep a bounded reusable projection. Larger captures still use the indexed
// canonical log and never grow this cache without limit.
const REPLAY_CACHE_LIMIT = 5000;
const REPLAY_CACHE_BYTES = 4 * 1024 * 1024;
function replayFits(state: State): boolean {
  if (state.network.length > REPLAY_CACHE_LIMIT || state.console.length > REPLAY_CACHE_LIMIT || state.pendingHeaders.size > CACHE_LIMIT) return false;
  let size = 0;
  const addHeaders = (headers?: Record<string, string>) => {
    if (headers) for (const [key, value] of Object.entries(headers)) size += 2 * (key.length + String(value).length);
  };
  for (const record of state.network) {
    size += 256 + 2 * (record.requestRef.length + record.requestId.length + record.url.length + (record.requestBody?.length ?? 0));
    addHeaders(record.requestHeaders); addHeaders(record.responseHeaders);
    if (size > REPLAY_CACHE_BYTES) return false;
  }
  for (const record of state.console) { size += 128 + 2 * record.text.length; if (size > REPLAY_CACHE_BYTES) return false; }
  for (const headers of state.pendingHeaders.values()) { addHeaders(headers.request); addHeaders(headers.response); if (size > REPLAY_CACHE_BYTES) return false; }
  return true;
}
const requestRef = (epoch: string, index: number) => `request:${epoch}:${index}`;
const sourceKey = (sessionId: string | undefined, requestId: string) => JSON.stringify([sessionId ?? null, requestId]);
function staleRequest(): Error {
  return Object.assign(new Error("Request reference is unavailable or belongs to an expired capture"), { code: "stale-request" });
}
async function waitFor<T>(task: Promise<T>, signal?: AbortSignal): Promise<T> {
  if (!signal) return task;
  signal.throwIfAborted();
  let abort!: () => void;
  try {
    const value = await Promise.race([task, new Promise<never>((_resolve, reject) => {
      abort = () => reject(signal.reason instanceof Error ? signal.reason : new DOMException(String(signal.reason ?? "Operation aborted"), "AbortError"));
      signal.addEventListener("abort", abort, { once: true });
      if (signal.aborted) abort();
    })]);
    signal.throwIfAborted();
    return value;
  } finally { if (abort) signal.removeEventListener("abort", abort); }
}

/** Disposable diagnostic caches. Raw CDP telemetry is best effort; history replay reports gaps explicitly. */
export class BrowserDiagnostics {
  private readonly tabs = new Map<number, State>();
  // A reset of the visible history cannot repair a failed CDP subscription.
  private readonly captureFailures = new Map<number, Set<"network" | "console">>();
  private readonly restorations = new WeakMap<State, { revision: number; networkRevision: number; consoleRevision: number; conversationId: string; task: Promise<State> }>();
  private readonly replays = new WeakMap<State, { revision: number; conversationId: string; lastId: number; logEpoch: string; state: State }>();
  private context: { conversationId?: string; toolCallId?: string; logIdentity?: { runId?: string; toolCallId: string; toolCallIdCanonical: true } } = {};
  constructor(private readonly logger?: EventLogger) {}
  bind(context: typeof this.context): void {
    const oldRun = this.context.logIdentity?.runId, nextRun = context.logIdentity?.runId;
    if (this.context.conversationId !== undefined && this.context.conversationId !== context.conversationId
      || oldRun !== undefined && nextRun !== undefined && oldRun !== nextRun) this.tabs.clear();
    this.context = context;
  }
  private state(tabId: number): State {
    let state = this.tabs.get(tabId);
    if (!state) { state = { epoch: crypto.randomUUID(), revision: 0, networkRevision: 0, consoleRevision: 0, nextRequest: 0, nextConsole: 0, consoleGeneration: 0, network: [], networkLatest: new Map(), console: [], pendingHeaders: new Map(), historical: new Map(), pages: new Map(), latest: new Map(), requestVersions: new Map(), invalidations: new Map(), invalidBefore: 0, captureFailures: this.captureFailures.get(tabId) }; this.tabs.set(tabId, state); }
    return state;
  }
  remove(tabId: number): void { this.tabs.delete(tabId); this.captureFailures.delete(tabId); }
  clear(): void { this.tabs.clear(); this.captureFailures.clear(); this.context = {}; }
  reset(tabId: number): void { this.tabs.delete(tabId); this.state(tabId); }
  captureFailed(source: Debuggee, method: string, error: unknown): void {
    if (source.tabId === undefined) return;
    const state = this.state(source.tabId);
    const kind = method === "Network.enable" ? "network" : method === "Log.enable" ? "console" : undefined;
    if (kind) { const failures = state.captureFailures ?? new Set(); failures.add(kind); state.captureFailures = failures; this.captureFailures.set(source.tabId, failures); state.revision++; this.invalidatePages(state, kind); }
    this.logger?.telemetry({ type: "browser.diagnostic.capture-failed", ...this.context, ...this.context.logIdentity,
      content: { source, method }, error: safeDiagnosticError(error) });
  }
  private invalidatePages(state: State, kind: "network" | "console"): void {
    const pageKind = kind === "network" ? "requests" : "console";
    if (kind === "network") state.networkRevision++; else state.consoleRevision++;
    for (const [key, page] of state.pages) if (page.kind === pageKind) state.pages.delete(key);
  }

  handle(source: Debuggee, method: string, params: any): void {
    const tabId = source.tabId;
    if (tabId === undefined) return;
    if (method === "Page.frameNavigated" && !source.sessionId && !params?.frame?.parentId) this.reset(tabId);
    const lifecycle = (method === "Page.frameNavigated" && (source.sessionId || params?.frame?.parentId))
      || method === "Page.frameDetached" || method === "Target.detachedFromTarget";
    if (!lifecycle && !method.startsWith("Network.") && method !== "Runtime.consoleAPICalled" && method !== "Log.entryAdded") return;
    const state = this.state(tabId);
    const existing = typeof params?.requestId === "string" ? state.networkLatest.get(sourceKey(source.sessionId, params.requestId)) : undefined;
    const index = method === "Network.requestWillBeSent" ? ++state.nextRequest
      : method === "Runtime.consoleAPICalled" || method === "Log.entryAdded" ? ++state.nextConsole : existing?.index;
    if (method === "Network.requestWillBeSent" && typeof params?.requestId === "string") {
      const identity = sourceKey(source.sessionId, params.requestId);
      state.latest.delete(identity); state.latest.set(identity, index!);
      while (state.latest.size > IDENTITY_LIMIT) {
        const oldest = state.latest.keys().next().value!;
        state.latest.delete(oldest); state.requestVersions.delete(oldest);
      }
    }
    const invalidation = method === "Page.frameNavigated" && typeof params?.frame?.id === "string" ? `frame:${params.frame.id}`
      : method === "Page.frameDetached" && typeof params?.frameId === "string" ? `frame:${params.frameId}`
      : method === "Target.detachedFromTarget" && typeof params?.sessionId === "string" ? `session:${params.sessionId}` : undefined;
    if (invalidation) {
      state.invalidations.delete(invalidation); state.invalidations.set(invalidation, state.nextRequest);
      while (state.invalidations.size > INVALIDATION_LIMIT) {
        const oldest = state.invalidations.keys().next().value!;
        state.invalidBefore = Math.max(state.invalidBefore, state.invalidations.get(oldest)!);
        state.invalidations.delete(oldest);
      }
    }
    state.revision += 1;
    const changesRequest = ["Network.requestWillBeSent", "Network.responseReceived", "Network.requestWillBeSentExtraInfo", "Network.responseReceivedExtraInfo", "Network.loadingFailed"].includes(method);
    if (changesRequest && typeof params?.requestId === "string") {
      const key = sourceKey(source.sessionId, params.requestId);
      if (state.latest.has(key)) state.requestVersions.set(key, state.revision);
    }
    if (lifecycle || changesRequest) this.invalidatePages(state, "network");
    if (method === "Runtime.consoleAPICalled" || method === "Log.entryAdded") this.invalidatePages(state, "console");
    // Cold references are reusable across unrelated traffic; invalidate only
    // entries whose request, frame, or debugger session may have changed.
    for (const [ref, record] of state.historical) {
      if ((params?.requestId === record.requestId && source.sessionId === record.debuggee.sessionId)
        || (method === "Page.frameNavigated" && params?.frame?.id === record.frameId)
        || (method === "Page.frameDetached" && params?.frameId === record.frameId)
        || (method === "Target.detachedFromTarget" && params?.sessionId === record.debuggee.sessionId)) state.historical.delete(ref);
    }
    this.logger?.telemetry({ type: "browser.diagnostic", ...this.context, ...this.context.logIdentity, content: { tabId, source, method, epoch: state.epoch, revision: state.revision, index, consoleGeneration: state.consoleGeneration }, output: params });
    this.apply(state, source, method, params, index);
    if (state.network.length > CACHE_LIMIT) {
      for (const record of state.network.splice(0, state.network.length - CACHE_LIMIT)) {
        const key = sourceKey(record.debuggee.sessionId, record.requestId);
        if (state.networkLatest.get(key) === record) state.networkLatest.delete(key);
      }
    }
    if (state.console.length > CACHE_LIMIT) state.console.splice(0, state.console.length - CACHE_LIMIT);
  }
  private apply(state: State, source: Debuggee, method: string, params: any, index?: number): void {
    if (method === "console.clear") { state.console = []; return; }
    if (method === "Page.frameNavigated" || method === "Page.frameDetached") {
      const frameId = method === "Page.frameNavigated" ? params?.frame?.id : params?.frameId;
      if (typeof frameId === "string") for (const record of state.network) if (record.frameId === frameId) record.superseded = true;
      return;
    }
    if (method === "Target.detachedFromTarget") {
      if (typeof params?.sessionId === "string") for (const record of state.network) if (record.debuggee.sessionId === params.sessionId) record.superseded = true;
      return;
    }
    const key = JSON.stringify([source.sessionId, params?.requestId]);
    const existing = typeof params?.requestId === "string" ? state.networkLatest.get(sourceKey(source.sessionId, params.requestId)) : undefined;
    if (method === "Network.requestWillBeSent") {
      // CDP deliberately reuses requestId across redirects. Each request event
      // needs its own identity: an earlier hop must never read the later body.
      if (existing) existing.superseded = true;
      const record: NetworkRecord = { index: index!, requestRef: requestRef(state.epoch, index!), requestId: params.requestId, debuggee: { ...source }, method: params.request.method, url: params.request.url, requestHeaders: {} };
      Object.assign(record, { method: params.request.method, url: params.request.url, requestHeaders: params.request.headers ?? {}, requestBody: params.request.postData, resourceType: params.type, frameId: params.frameId, loaderId: params.loaderId, responseHeaders: undefined });
      const headers = state.pendingHeaders.get(key);
      if (headers?.request) record.requestHeaders = headers.request;
      if (headers?.response) record.responseHeaders = headers.response;
      state.pendingHeaders.delete(key);
      state.network.push(record);
      state.networkLatest.set(sourceKey(source.sessionId, record.requestId), record);
    } else if (method === "Network.responseReceived" && existing) {
      if (existing.loaderId && params.loaderId && existing.loaderId !== params.loaderId) return;
      Object.assign(existing, { status: params.response.status, statusText: params.response.statusText, responseHeaders: existing.responseHeaders ?? params.response.headers ?? {}, resourceType: params.type ?? existing.resourceType });
    } else if (method === "Network.requestWillBeSentExtraInfo" || method === "Network.responseReceivedExtraInfo") {
      const response = method === "Network.responseReceivedExtraInfo";
      if (existing) { if (response) existing.responseHeaders = params.headers; else existing.requestHeaders = params.headers; }
      else {
        const pending = state.pendingHeaders.get(key) ?? {};
        if (response) pending.response = params.headers; else pending.request = params.headers;
        state.pendingHeaders.set(key, pending);
        if (state.pendingHeaders.size > CACHE_LIMIT) state.pendingHeaders.delete(state.pendingHeaders.keys().next().value!);
      }
    }
    else if (method === "Network.loadingFailed" && existing) existing.failed = params.errorText;
    else if (method === "Runtime.consoleAPICalled") state.console.push({ index: index!, level: params.type, text: (params.args ?? []).map((arg: any) => arg.value ?? arg.description ?? arg.type).join(" "), timestamp: params.timestamp });
    else if (method === "Log.entryAdded") state.console.push({ index: index!, level: params.entry.level, text: params.entry.text, timestamp: params.entry.timestamp });
  }
  private async restored(tabId: number, signal?: AbortSignal): Promise<State> {
    while (true) {
      signal?.throwIfAborted();
      const current = this.state(tabId);
      const conversationId = this.context.conversationId;
      if (!this.logger || !conversationId) return { ...current, replayComplete: false };
      const revision = current.revision, consoleGeneration = current.consoleGeneration;
      // Freeze the read boundary before I/O. Ongoing traffic belongs to a later
      // observation; it must never make this prefix chase a moving revision.
      const boundary = { ...current, consoleGeneration };
      let flight = this.restorations.get(current);
      if (!flight || flight.networkRevision !== current.networkRevision || flight.consoleRevision !== current.consoleRevision || flight.conversationId !== conversationId) {
        const task = (async () => {
          let cache = this.replays.get(current);
          if (cache?.conversationId !== conversationId || cache.revision > revision) cache = undefined;
          let snapshot = await this.logger!.diagnosticEventsSnapshot(conversationId, { tabId, epoch: current.epoch, afterId: cache?.lastId });
          if (cache && snapshot.epoch !== cache.logEpoch) {
            cache = undefined;
            snapshot = await this.logger!.diagnosticEventsSnapshot(conversationId, { tabId, epoch: current.epoch });
          }
          const network = cache ? structuredClone(cache.state.network) : [];
          const networkLatest = new Map(network.map((record) => [sourceKey(record.debuggee.sessionId, record.requestId), record]));
          const restored: State = cache ? { ...boundary, network, networkLatest, console: cache.state.consoleGeneration === consoleGeneration ? structuredClone(cache.state.console) : [], pendingHeaders: structuredClone(cache.state.pendingHeaders), historical: new Map(), pages: new Map(), replayComplete: true }
            : { ...boundary, network, networkLatest, console: [], pendingHeaders: new Map(), historical: new Map(), pages: new Map(), replayComplete: true };
          restored.replayEpoch = snapshot.epoch;
          let expectedRevision = (cache?.revision ?? 0) + 1, lastId = cache?.lastId ?? -1;
          for (const event of snapshot.value) {
            const content = fromLogValue(event.content, event.valueEncoding) as { tabId?: number; source: Debuggee; method: string; epoch?: string; index?: number; revision?: number; consoleGeneration?: number };
            if (content.tabId !== tabId || content.epoch !== current.epoch || (content.revision ?? 0) > revision) continue;
            lastId = Math.max(lastId, event.id);
            if (!Number.isSafeInteger(content.revision) || content.revision! !== expectedRevision) restored.replayComplete = false;
            if (!Number.isSafeInteger(content.revision) || content.revision! < expectedRevision) continue;
            expectedRevision = content.revision! + 1;
            if ((content.method === "console.clear" || content.method === "Runtime.consoleAPICalled" || content.method === "Log.entryAdded") && content.consoleGeneration !== consoleGeneration) continue;
            this.apply(restored, content.source, content.method, fromLogValue(event.output, event.valueEncoding), content.index);
          }
          if (expectedRevision !== revision + 1) restored.replayComplete = false;
          if (restored.replayComplete && replayFits(restored)
            && this.tabs.get(tabId) === current && current.consoleGeneration === consoleGeneration && this.context.conversationId === conversationId) {
            this.replays.set(current, { revision, conversationId, lastId, logEpoch: snapshot.epoch, state: restored });
          }
          return restored;
        })();
        flight = { revision, networkRevision: boundary.networkRevision, consoleRevision: boundary.consoleRevision, conversationId, task };
        this.restorations.set(current, flight);
        void task.finally(() => { if (this.restorations.get(current)?.task === task) this.restorations.delete(current); }).catch(() => undefined);
      }
      const result = await waitFor(flight.task, signal);
      // A reset changes identity; console.clear changes its generation. These
      // invalidate the boundary. Ordinary traffic never invalidates a prefix.
      if (this.tabs.get(tabId) === current && current.consoleGeneration === consoleGeneration && this.context.conversationId === conversationId) return result;
    }
  }
  async requests(tabId: number, input: { static?: boolean; filter?: string; clear?: boolean; offset?: number; limit?: number }, signal?: AbortSignal): Promise<unknown> {
    signal?.throwIfAborted();
    if (input.clear) { this.reset(tabId); return { cleared: true }; }
    const offset = input.offset ?? 0, limit = input.limit ?? 100;
    if (!Number.isSafeInteger(offset) || offset < 0 || !Number.isSafeInteger(limit) || limit < 1 || limit > 100) throw new Error("Request list offset must be nonnegative and limit must be between 1 and 100");
    const matcher = input.filter ? new RegExp(input.filter) : undefined;
    while (true) {
      signal?.throwIfAborted();
      const state = this.state(tabId), revision = state.networkRevision, conversationId = this.context.conversationId;
      const live = structuredClone(state.network);
      const key = JSON.stringify(["requests", input.static ?? false, input.filter ?? null, offset, limit]);
      const cached = state.pages.get(key);
      if (cached && cached.revision === revision && cached.conversationId === conversationId) {
        try {
          const valid = cached.logEpoch === undefined || this.logger && await waitFor(this.logger.canonicalEpoch(), signal) === cached.logEpoch;
          if (this.tabs.get(tabId) !== state || this.context.conversationId !== conversationId) continue;
          if (valid) return structuredClone(cached.value);
          state.pages.delete(key);
        } catch (error) { if (signal?.aborted) throw error; state.pages.delete(key); }
      }
      let records = live, integrity: RequestList["integrity"] = "complete", reason: string | undefined, logEpoch: string | undefined;
      if (state.nextRequest > CACHE_LIMIT) {
        try {
          const replay = await this.restored(tabId, signal);
          if (this.tabs.get(tabId) !== state || this.context.conversationId !== conversationId) continue;
          logEpoch = replay.replayEpoch;
          integrity = replay.replayComplete === true ? "complete" : "incomplete";
          if (integrity === "incomplete") reason = "diagnostic-log-incomplete";
          // Replay can miss best-effort telemetry. Retain every still-live
          // record and report incomplete rather than silently dropping it.
          const merged = new Map(replay.network.map((record) => [record.index, record]));
          for (const record of live) merged.set(record.index, record);
          records = [...merged.values()].sort((a, b) => a.index - b.index);
        } catch (error) {
          if (signal?.aborted) throw error;
          if (this.tabs.get(tabId) !== state || this.context.conversationId !== conversationId) continue;
          integrity = "incomplete"; reason = "diagnostic-log-unavailable";
        }
      }
      if (state.captureFailures?.has("network")) { integrity = "incomplete"; reason = "diagnostic-capture-failed"; }
      const filtered = records.filter((record) => {
        const isStatic = ["Image", "Font", "Stylesheet", "Script", "Media"].includes(record.resourceType ?? "") && !record.failed && (record.status ?? 0) < 400;
        return (input.static || !isStatic) && (!matcher || matcher.test(record.url));
      });
      const selected = filtered.slice(offset, offset + limit);
      const requests = selected.map(({ requestRef, method, url, status, failed, statusText, superseded }) => ({ requestRef, method, url, status: failed ? "FAILED" : status, statusText: failed ?? statusText, ...(superseded ? { superseded: true } : {}) }));
      const hasKnownMore = filtered.length > offset + limit;
      const result: RequestList = { requests, integrity, hasMore: hasKnownMore ? true : integrity === "complete" ? false : null,
        ...(hasKnownMore ? { nextOffset: offset + limit } : {}), ...(reason ? { reason } : {}) };
      // Cached history must remain tied to the canonical log epoch, including
      // a clear by another logger instance. In-memory-only pages need no disk.
      if (state.nextRequest <= CACHE_LIMIT || logEpoch !== undefined) {
        state.pages.set(key, { kind: "requests", value: structuredClone(result), logEpoch, conversationId, revision });
        while (state.pages.size > PAGE_CACHE_LIMIT) state.pages.delete(state.pages.keys().next().value!);
      }
      return result;
    }
  }
  async request(tabId: number, ref: string, signal?: AbortSignal): Promise<NetworkRecord> {
    signal?.throwIfAborted();
    while (true) {
    const state = this.state(tabId);
    if (typeof ref !== "string" || !ref.startsWith(`request:${state.epoch}:`)) throw staleRequest();
    const index = Number(ref.slice(`request:${state.epoch}:`.length));
    if (!Number.isSafeInteger(index) || index < 1 || requestRef(state.epoch, index) !== ref) throw staleRequest();
    const revision = state.revision;
    const record = state.network.find((item) => item.requestRef === ref) ?? state.historical.get(ref) ?? (await this.restored(tabId, signal)).network.find((item) => item.requestRef === ref);
    signal?.throwIfAborted();
    if (this.tabs.get(tabId) !== state || !record || record.superseded
      || state.latest.get(sourceKey(record.debuggee.sessionId, record.requestId)) !== record.index
      || record.index <= state.invalidBefore
      || (record.frameId !== undefined && (state.invalidations.get(`frame:${record.frameId}`) ?? -1) >= record.index)
      || (record.debuggee.sessionId !== undefined && (state.invalidations.get(`session:${record.debuggee.sessionId}`) ?? -1) >= record.index)) throw staleRequest();
    // Unrelated traffic never restarts a read. A late update to this exact
    // request must be replayed before combining metadata with a current body.
    if ((state.requestVersions.get(sourceKey(record.debuggee.sessionId, record.requestId)) ?? 0) > revision) continue;
    if (!state.network.includes(record)) {
      state.historical.delete(ref); state.historical.set(ref, record);
      while (state.historical.size > HISTORY_CACHE_LIMIT) state.historical.delete(state.historical.keys().next().value!);
    }
    return record;
    }
  }
  async console(tabId: number, input: { clear?: boolean; minLevel?: string; offset?: number; limit?: number }, signal?: AbortSignal): Promise<unknown> {
    signal?.throwIfAborted();
    if (input.clear) { const state = this.state(tabId); state.console = []; state.nextConsole = 0; state.consoleGeneration += 1; state.revision += 1; this.invalidatePages(state, "console"); this.logger?.telemetry({ type: "browser.diagnostic", ...this.context, ...this.context.logIdentity, content: { tabId, source: { tabId }, method: "console.clear", epoch: state.epoch, revision: state.revision, consoleGeneration: state.consoleGeneration }, output: null }); return { cleared: true }; }
    const offset = input.offset ?? 0, limit = input.limit ?? 100;
    if (!Number.isSafeInteger(offset) || offset < 0 || !Number.isSafeInteger(limit) || limit < 1 || limit > 100) throw new Error("Console list offset must be nonnegative and limit must be between 1 and 100");
    const rank: Record<string, number> = { debug: 0, info: 1, log: 1, warning: 2, warn: 2, error: 3, assert: 3 };
    while (true) {
      signal?.throwIfAborted();
      const state = this.state(tabId), revision = state.consoleRevision, conversationId = this.context.conversationId;
      const consoleGeneration = state.consoleGeneration, live = structuredClone(state.console);
      const key = JSON.stringify(["console", input.minLevel ?? "info", offset, limit]);
      const cached = state.pages.get(key);
      if (cached && cached.revision === revision && cached.conversationId === conversationId) {
        try {
          const valid = cached.logEpoch === undefined || this.logger && await waitFor(this.logger.canonicalEpoch(), signal) === cached.logEpoch;
          if (this.tabs.get(tabId) !== state || state.consoleGeneration !== consoleGeneration || this.context.conversationId !== conversationId) continue;
          if (valid) return structuredClone(cached.value);
          state.pages.delete(key);
        } catch (error) { if (signal?.aborted) throw error; state.pages.delete(key); }
      }
      let records = live, integrity: ConsoleList["integrity"] = "complete", reason: string | undefined, logEpoch: string | undefined;
      if (state.nextConsole > CACHE_LIMIT) {
        try {
          const replay = await this.restored(tabId, signal);
          if (this.tabs.get(tabId) !== state || state.consoleGeneration !== consoleGeneration || this.context.conversationId !== conversationId) continue;
          logEpoch = replay.replayEpoch;
          integrity = replay.replayComplete === true ? "complete" : "incomplete";
          if (integrity === "incomplete") reason = "diagnostic-log-incomplete";
          const merged = new Map(replay.console.map((record) => [record.index, record]));
          for (const record of live) merged.set(record.index, record);
          records = [...merged.values()].sort((a, b) => a.index - b.index);
        } catch (error) {
          if (signal?.aborted) throw error;
          if (this.tabs.get(tabId) !== state || state.consoleGeneration !== consoleGeneration || this.context.conversationId !== conversationId) continue;
          integrity = "incomplete"; reason = "diagnostic-log-unavailable";
        }
      }
      if (state.captureFailures?.has("console")) { integrity = "incomplete"; reason = "diagnostic-capture-failed"; }
      const filtered = records.filter((message) => (rank[message.level] ?? 1) >= (rank[input.minLevel ?? "info"] ?? 1));
      const messages = filtered.slice(offset, offset + limit);
      const hasKnownMore = filtered.length > offset + limit;
      const result: ConsoleList = { messages, integrity, hasMore: hasKnownMore ? true : integrity === "complete" ? false : null,
        ...(hasKnownMore ? { nextOffset: offset + limit } : {}), ...(reason ? { reason } : {}) };
      if (state.nextConsole <= CACHE_LIMIT || logEpoch !== undefined) {
        state.pages.set(key, { kind: "console", value: structuredClone(result), logEpoch, conversationId, revision });
        while (state.pages.size > PAGE_CACHE_LIMIT) state.pages.delete(state.pages.keys().next().value!);
      }
      return result;
    }
  }
}

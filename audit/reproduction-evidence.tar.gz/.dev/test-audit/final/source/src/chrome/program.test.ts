import { afterEach, describe, expect, it, vi } from "vitest";
import { EventLogger, fromLogValue, toLogValue, type LogEvent } from "../logging";
import { BrowserJobs } from "./jobs";
import { createProgramTools, prepareToolMessages } from "./tool";
import { ChromeExecutor } from "./executor";
import { ProgramScope } from "./program";
import { ATOMIC_TOOL_REGISTRY } from "./atomic-tools";
import { PROGRAM_EVENT_INVOKE } from "./program-handles";
import { LocatorFacade, PageFacade, type AutomationRuntime } from "./automation";

function log() {
  const events: LogEvent[] = [];
  const logger = new EventLogger({
    store: {
      async append(event: Omit<LogEvent, "id">) {
        const saved = { ...event, id: events.length + 1 };
        events.push(saved);
        return saved;
      },
      async all() {
        return [...events];
      },
      async clear() {
        events.length = 0;
      },
    },
  });
  return { logger, events };
}
function indexedLog() {
  const events: LogEvent[] = [];
  const byTypes = vi.fn(async (types: readonly string[], conversationId?: string, afterId = -1, limit = Infinity) =>
    events.filter((event) => event.id > afterId && types.includes(event.type) && (!conversationId || event.conversationId === conversationId)).slice(0, limit));
  const getMany = vi.fn(async (ids: readonly number[]) => ids.map((id) => events.find((event) => event.id === id)));
  const store = {
    async append(event: Omit<LogEvent, "id">) { const saved = { ...event, id: events.length + 1 }; events.push(saved); return saved; },
    async appendArtifactAnd(artifact: Omit<LogEvent, "id">, terminal: Omit<LogEvent, "id">, link: "resultArtifactId") {
      const savedArtifact = { ...artifact, id: events.length + 1 };
      const content = fromLogValue(terminal.content, terminal.valueEncoding) as object;
      const savedTerminal = { ...terminal, id: events.length + 2, content: toLogValue({ ...content, [link]: savedArtifact.id }, undefined, 5) };
      events.push(savedArtifact, savedTerminal);
      return { artifact: savedArtifact, terminal: savedTerminal };
    },
    async all() { return [...events]; }, byTypes, getMany,
  };
  const logger = new EventLogger({ store });
  return { logger, store, events, byTypes, getMany };
}
const context = { conversationId: "program-test" };
afterEach(() => vi.useRealTimers());

describe("scoped atomic program calls", () => {
  it("passes the unique scope chain through ProgramScope to the locator runtime", async () => {
    const { logger } = log();
    const scope = new ProgramScope(new AbortController().signal, "job", context, logger);
    const locatorValue = vi.fn(async (_tabId: number, _spec: unknown, _operation: string) => 1);
    const runtime = {
      locator: (tabId: number, query: unknown) => new LocatorFacade(runtime as unknown as AutomationRuntime, tabId, { queries: [query] } as never),
      locatorValue,
    };
    const page = scope.wrap(new PageFacade(runtime as unknown as AutomationRuntime, 3));
    const definition = ATOMIC_TOOL_REGISTRY.find((item) => item.name === "count_elements")!;
    const code = definition.program({ target: { by: "role", value: "button", name: "Save", scope: { by: "css", value: ".row" } } }).code;
    const AsyncFunction = Object.getPrototypeOf(async function () {}).constructor;
    expect(await new AsyncFunction("page", code)(page)).toBe(1);
    expect(locatorValue).toHaveBeenCalledWith(3, { queries: [
      { kind: "css", value: ".row" }, { kind: "uniqueScope", value: "" }, { kind: "role", value: "button", name: "Save" },
    ] }, "count", []);
    await scope.finish();
  });
});

describe("canonical browser jobs", () => {
  it("reports a terminal persistence failure with the job and original execution cause", async () => {
    const { logger } = indexedLog();
    const jobs = new BrowserJobs(logger);
    const execution = new Error("browser command failed token=secret123");
    const persistence = new Error("storage quota exceeded");
    const append = logger.appendIfEpoch.bind(logger);
    vi.spyOn(logger, "appendIfEpoch").mockImplementation((record, epoch, expected) =>
      (record.content as any)?.state === "failed" ? Promise.reject(persistence) : append(record, epoch, expected));
    const report = vi.spyOn(console, "error").mockImplementation(() => {});
    let release!: () => void;
    const gate = new Promise<void>((resolve) => { release = resolve; });
    const id = await jobs.start(context, undefined, async (_signal, _id, started) => { await started(); await gate; throw execution; });
    const done = jobs.waitForOwner(id, context.conversationId);
    release();
    await done;
    const [, details] = report.mock.calls[0]!;
    expect(details).toMatchObject({ jobId: id, conversationId: context.conversationId, phase: "write-failed" });
    expect((details as any).error.errors).toMatchObject([{ message: "browser command failed token=[redacted]" }, { message: "storage quota exceeded" }]);
    expect((details as any).error.errors[0].stack).not.toContain("secret123");
    await expect(jobs.query({ action: "status", id }, context.conversationId)).rejects.toMatchObject({ errors: [execution, persistence] });
    report.mockRestore();
  });
  it("does not start browser work after recovery wins a delayed running receipt", async () => {
    const { logger, events } = indexedLog();
    const jobs = new BrowserJobs(logger);
    const append = logger.appendIfEpoch.bind(logger);
    let release!: () => void;
    let reached!: () => void;
    const gate = new Promise<void>((resolve) => { release = resolve; });
    const waiting = new Promise<void>((resolve) => { reached = resolve; });
    vi.spyOn(logger, "appendIfEpoch").mockImplementation(async (record, epoch, expected) => {
      if (record.type === "browser.job.state" && (record.content as any)?.state === "running") { reached(); await gate; }
      return append(record, epoch, expected);
    });
    const executeEffect = vi.fn();
    const id = await jobs.start(context, undefined, async (_signal, _id, started) => {
      await started();
      executeEffect();
    });
    await waiting;
    const recovered = await new BrowserJobs(logger).query({ action: "status", id }, context.conversationId);
    expect(recovered).toMatchObject({ state: "interrupted", terminal: true });
    release();
    await jobs.waitForOwner(id, context.conversationId);
    expect(executeEffect).not.toHaveBeenCalled();
    expect(events.filter((event) => event.type === "browser.job.state").map((event) => (fromLogValue(event.content, event.valueEncoding) as any).state)).toEqual(["queued", "interrupted"]);
    expect(await jobs.query({ action: "status", id }, context.conversationId)).toMatchObject({ state: "interrupted", terminal: true });
  });

  it("rejects a second or late attempt to start the same job", async () => {
    const { logger, events } = indexedLog();
    const jobs = new BrowserJobs(logger);
    let late!: () => Promise<void>;
    const id = await jobs.start(context, undefined, async (_signal, _id, started) => {
      late = started;
      await started();
      await expect(started()).rejects.toThrow("only start once");
    });
    await jobs.waitForOwner(id, context.conversationId);
    await expect(late()).rejects.toThrow("only start once");
    expect(events.filter((event) => event.type === "browser.job.state").map((event) => (fromLogValue(event.content, event.valueEncoding) as any).state)).toEqual(["queued", "running", "succeeded"]);
  });

  it("finishes an outstanding start receipt before writing the terminal state", async () => {
    const { logger, events } = indexedLog();
    const jobs = new BrowserJobs(logger);
    const append = logger.appendIfEpoch.bind(logger);
    let release!: () => void;
    let reached!: () => void;
    const gate = new Promise<void>((resolve) => { release = resolve; });
    const waiting = new Promise<void>((resolve) => { reached = resolve; });
    vi.spyOn(logger, "appendIfEpoch").mockImplementation(async (record, epoch, expected) => {
      if (record.type === "browser.job.state" && (record.content as any)?.state === "running") { reached(); await gate; }
      return append(record, epoch, expected);
    });
    const id = await jobs.start(context, undefined, async (_signal, _id, started) => {
      void started();
      return "done";
    });
    await waiting;
    expect(events.filter((event) => event.type === "browser.job.state").map((event) => (fromLogValue(event.content, event.valueEncoding) as any).state)).toEqual(["queued"]);
    release();
    await jobs.waitForOwner(id, context.conversationId);
    expect(events.filter((event) => event.type === "browser.job.state").map((event) => (fromLogValue(event.content, event.valueEncoding) as any).state)).toEqual(["queued", "running", "succeeded"]);
  });

  it("reuses one large terminal artifact across paginated job reads and enforces conversation isolation", async () => {
    const { logger, events } = indexedLog();
    const jobs = new BrowserJobs(logger);
    const payload = "x".repeat(12_000);
    const id = await jobs.start(context, undefined, async (_signal, _id, started) => { await started(); return { payload }; });
    await jobs.waitForOwner(id, context.conversationId);
    const executor = { queryJobs: (input: any) => jobs.query(input, context.conversationId), acknowledgeBackgroundJob: () => {} } as unknown as ChromeExecutor;
    const tools = createProgramTools(executor, { logger, conversationId: context.conversationId }) as Record<string, any>;
    const first = await tools.get_job.execute({ jobId: id, limit: 1 }, { toolCallId: "first" });
    const second = await tools.get_job.execute({ jobId: id, after: first.nextCursor, limit: 10 }, { toolCallId: "second" });
    expect(first.resultAccess).toEqual(second.resultAccess);
    expect(second.events.at(-1)).toMatchObject({ state: "succeeded", outputAt: "resultAccess" });
    expect(second.hasMore).toBe(false);
    expect(events.filter((event) => event.type === "tool.result.data")).toHaveLength(1);
    expect(events.find((event) => event.type === "browser.job.state" && (fromLogValue(event.content, event.valueEncoding) as any).state === "succeeded")?.output).toBeUndefined();
    expect(await logger.result(first.$ref, { path: ["result", "payload"], offset: 0, limit: 3 }, context.conversationId)).toBe("xxx");
    await expect(logger.result(first.$ref, {}, "other")).rejects.toThrow("unavailable");
    await expect(jobs.query({ action: "status", id }, "other")).rejects.toThrow("unavailable");
  });

  it("delivers executable collection access for stored object results after host restart", async () => {
    const { logger, events } = indexedLog();
    let jobs = new BrowserJobs(logger);
    const items = [{ text: "page content ".repeat(1000) }];
    const id = await jobs.start(context, undefined, async () => ({ total: 1, items }));
    await jobs.waitForOwner(id, context.conversationId);
    jobs = new BrowserJobs(logger);
    const executor = new ChromeExecutor({ chromeApi: { debugger: {} } as never, logger });
    vi.spyOn(executor, "queryJobs").mockImplementation(async (input) => ({
      ...await jobs.query(input, context.conversationId) as Record<string, unknown>,
      events: [{ state: "succeeded", text: "large receipt ".repeat(1000) }],
    }));
    vi.spyOn(executor, "runProgram").mockImplementation(async () => jobs.query({ action: "status", id }, context.conversationId));
    const tools = createProgramTools(executor, { logger, conversationId: context.conversationId }) as Record<string, any>;
    try {
      const foreground = await tools.read_elements.execute({ target: { by: "css", value: "body" } }, { toolCallId: "elements" });
      const background = await tools.get_job.execute({ jobId: id }, { toolCallId: "job" });
      expect(background.receiptsAccess.artifactId).toBe(background.receiptsArtifactId);
      expect(background.receiptsAccess.path).toEqual(["events"]);
      expect(await logger.result(background.receiptsArtifactId, { path: ["events", 0, "text"], limit: 13 }, context.conversationId)).toBe("large receipt");
      for (const output of [foreground, background]) {
        expect(output.access).toEqual({ artifactId: output.$ref, path: ["result", "items"], offset: 0, limit: 25 });
        expect(output.resultAccess).toEqual({ artifactId: output.$ref, path: ["result"] });
        // Use the supplied parameters verbatim; a large first item can be read as text next.
        const slice = await tools.read_artifact.execute(output.access, { toolCallId: "items" });
        expect(slice).not.toHaveProperty("error");
        expect(await logger.result(slice.$ref, { path: ["result"], offset: 0, limit: 1 }, context.conversationId)).toEqual(items);
        expect(await tools.read_artifact.execute({ artifactId: output.$ref, path: [...output.access.path, 0, "text"], offset: 1000, limit: 1000 }, { toolCallId: "text" }))
          .toMatchObject({ ok: true, result: items[0]!.text.slice(1000, 2000) });
      }
      expect(events.filter((event) => event.type === "tool.result.data" && (fromLogValue(event.content, event.valueEncoding) as any)?.jobId === id)).toHaveLength(1);
    } finally { executor.dispose(); }
  });

  it("records an explicitly undefined return in the terminal receipt", async () => {
    const { logger } = indexedLog();
    const jobs = new BrowserJobs(logger);
    const id = await jobs.start(context, undefined, async () => undefined);
    await jobs.waitForOwner(id, context.conversationId);
    const result: any = await jobs.query({ action: "status", id }, context.conversationId);
    expect(result).toHaveProperty("result", undefined);
    expect(result.events.at(-1)).toMatchObject({ state: "succeeded", outputAt: "result" });
  });

  it("retains a failed large result and its bounded error across host restart", async () => {
    const { logger, events } = indexedLog();
    const jobs = new BrowserJobs(logger);
    const id = await jobs.start(context, undefined, async () => { throw Object.assign(new Error("e".repeat(12_000)), { effectUnknown: true }); });
    await jobs.waitForOwner(id, context.conversationId);
    const restarted = new BrowserJobs(logger);
    const executor = { queryJobs: (input: any) => restarted.query(input, context.conversationId), acknowledgeBackgroundJob: () => {} } as unknown as ChromeExecutor;
    const tools = createProgramTools(executor, { logger, conversationId: context.conversationId }) as Record<string, any>;
    const result = await tools.get_job.execute({ jobId: id }, { toolCallId: "failed" });
    expect(result).toMatchObject({ state: "failed", ok: false, error: { code: "execution-failed", effectUnknown: true }, errorAccess: { artifactId: result.$ref, path: ["result", "error"] } });
    expect(result.error.message.length).toBe(2000);
    expect((await logger.result(result.$ref, { path: ["result", "error", "message"] }, context.conversationId) as string).length).toBe(12_000);
    expect(events.filter((event) => event.type === "tool.result.data")).toHaveLength(1);
  });

  it("loads an inline screenshot by path after restart with conversation-scoped access", async () => {
    const { logger } = indexedLog();
    const jobs = new BrowserJobs(logger);
    const id = await jobs.start(context, undefined, async () => ({ screenshot: { data: "eA==", mediaType: "image/png" }, payload: "x".repeat(12_000) }));
    await jobs.waitForOwner(id, context.conversationId);
    const restarted = new BrowserJobs(logger);
    const executor = { queryJobs: (input: any) => restarted.query(input, context.conversationId), acknowledgeBackgroundJob: () => {} } as unknown as ChromeExecutor;
    const tools = createProgramTools(executor, { logger, conversationId: context.conversationId }) as Record<string, any>;
    const result = await tools.get_job.execute({ jobId: id }, { toolCallId: "image" });
    expect(result.screenshot).toEqual({ artifactId: result.$ref, artifactPath: ["result", "screenshot"], mediaType: "image/png" });
    const messages = [{ role: "tool", content: [{ type: "tool-result", output: { type: "json", value: result } }] }];
    const read = (artifactId: number, selection?: { path: Array<string | number> }) => logger.result(artifactId, selection, context.conversationId);
    const prepared = await prepareToolMessages(messages, 1, undefined, read);
    expect(prepared.at(-1).content).toContainEqual({ type: "file", mediaType: "image/png", data: { type: "data", data: "eA==" } });
    await expect(prepareToolMessages(messages, 1, undefined, (artifactId, selection) => logger.result(artifactId, selection, "other"))).rejects.toThrow("unavailable");
  });

  it("does not replace a recovery terminal that wins the large-result transaction", async () => {
    const { logger, events } = indexedLog();
    const jobs = new BrowserJobs(logger);
    let release!: () => void;
    const gate = new Promise<void>((resolve) => { release = resolve; });
    const id = await jobs.start(context, undefined, async () => { await gate; return "x".repeat(12_000); });
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: id, state: "interrupted" }, output: { ok: false, error: { code: "host-lost" } } });
    release();
    await jobs.waitForOwner(id, context.conversationId);
    const result: any = await jobs.query({ action: "status", id }, context.conversationId);
    expect(result.state).toBe("interrupted");
    expect(events.filter((event) => event.type === "tool.result.data")).toHaveLength(0);
  });

  it.each(["success", "undefined", "failure", "cancelled"] as const)("does not overwrite a recovery terminal with a small %s result", async (outcome) => {
    const { logger, events } = indexedLog();
    const jobs = new BrowserJobs(logger);
    const controller = new AbortController();
    let release!: () => void;
    const gate = new Promise<void>((resolve) => { release = resolve; });
    const id = await jobs.start(context, controller.signal, async (_signal, _id, started) => {
      await started();
      await gate;
      if (outcome === "failure") throw new Error("small failure");
      return outcome === "undefined" ? undefined : "small result";
    });
    await vi.waitFor(() => expect(events.some((event) => (fromLogValue(event.content, event.valueEncoding) as any)?.state === "running")).toBe(true));
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: id, state: "interrupted" }, output: { ok: false, error: { code: "host-lost" } } });
    if (outcome === "cancelled") controller.abort("cancelled");
    release();
    await jobs.waitForOwner(id, context.conversationId);
    const result: any = await jobs.query({ action: "status", id }, context.conversationId);
    expect(result).toMatchObject({ state: "interrupted", result: { error: { code: "host-lost" } } });
    const states = events.filter((event) => event.type === "browser.job.state").map((event) => (fromLogValue(event.content, event.valueEncoding) as any).state);
    expect(states).toEqual(["queued", "running", "interrupted"]);
  });

  it("never publishes a result artifact when the atomic store rejects the transaction", async () => {
    const { logger, events, store } = indexedLog();
    vi.spyOn(store, "appendArtifactAnd").mockRejectedValueOnce(new Error("transaction failed"));
    const jobs = new BrowserJobs(logger);
    const id = await jobs.start(context, undefined, async () => "x".repeat(12_000));
    await jobs.waitForOwner(id, context.conversationId);
    // A broken canonical writer is surfaced instead of publishing a false terminal.
    await expect(jobs.query({ action: "status", id }, context.conversationId)).rejects.toThrow("transaction failed");
    expect(events.filter((event) => event.type === "tool.result.data")).toHaveLength(0);
    expect(events.some((event) => (fromLogValue(event.content, event.valueEncoding) as any)?.state === "succeeded")).toBe(false);
  });
  it("decodes the current terminal result once and references it from the receipt page", async () => {
    const { logger } = indexedLog();
    const jobs = new BrowserJobs(logger);
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "job", state: "queued" } });
    await logger.append({ type: "browser.job.progress", ...context, content: { jobId: "job", operation: "emit" }, output: { partial: 7 } });
    const terminal = await logger.append({ type: "browser.job.state", ...context, content: { jobId: "job", state: "succeeded" }, output: { payload: "original" } });
    let decodes = 0;
    Object.defineProperty(terminal!.output, "payload", { enumerable: true, get: () => { decodes++; return "original"; } });
    const first: any = await jobs.query({ action: "status", id: "job", limit: 2 }, context.conversationId);
    expect(first).toMatchObject({ result: { payload: "original" }, hasMore: true,
      events: [{ state: "queued" }, { operation: "emit", output: { partial: 7 } }] });
    expect(decodes).toBe(1);
    decodes = 0;
    const second: any = await jobs.query({ action: "status", id: "job", after: first.nextCursor }, context.conversationId);
    expect(second).toMatchObject({ result: { payload: "original" }, hasMore: false, events: [{ state: "succeeded", outputAt: "result" }] });
    expect(second.events[0]).not.toHaveProperty("output");
    expect(decodes).toBe(1);
  });

  it.each(["failed", "cancelled", "interrupted"])("preserves %s terminal results and prior progress", async (state) => {
    const { logger } = indexedLog();
    const jobs = new BrowserJobs(logger);
    const error = { code: "host-lost", effectUnknown: true };
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: state, state: "running" } });
    await logger.append({ type: "browser.job.progress", ...context, content: { jobId: state, operation: "emit" }, output: { partial: 7 } });
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: state, state }, output: { ok: false, error } });
    const result: any = await jobs.query({ action: "status", id: state }, context.conversationId);
    expect(result).toMatchObject({ ok: false, state, result: { ok: false, error },
      events: [{ state: "running" }, { operation: "emit", output: { partial: 7 } }, { state, outputAt: "result" }] });
    expect(result.events[2]).not.toHaveProperty("output");
  });

  it("distinguishes a missing terminal output from an explicitly recorded undefined", async () => {
    const { logger } = indexedLog();
    const jobs = new BrowserJobs(logger);
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "missing", state: "succeeded" } });
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "explicit", state: "succeeded" }, output: undefined });
    const missing: any = await jobs.query({ action: "status", id: "missing" }, context.conversationId);
    const explicit: any = await jobs.query({ action: "status", id: "explicit" }, context.conversationId);
    expect(missing).toHaveProperty("result", undefined);
    expect(missing.events[0]).not.toHaveProperty("outputAt");
    expect(missing.events[0]).not.toHaveProperty("output");
    expect(explicit).toHaveProperty("result", undefined);
    expect(explicit.events[0]).toHaveProperty("outputAt", "result");
    expect(explicit.events[0]).not.toHaveProperty("output");
  });

  it("waits for the local owner without reading job state or retaining other conversations", async () => {
    const { logger } = indexedLog();
    const jobs = new BrowserJobs(logger);
    let release!: () => void;
    const gate = new Promise<void>((resolve) => { release = resolve; });
    const id = await jobs.start(context, undefined, async (_signal, _id, started) => { await started(); await gate; return "done"; });
    const reads = vi.spyOn(logger, "jobEventsSince");
    let done = false;
    const waiting = jobs.waitForOwner(id, context.conversationId).then(() => { done = true; });
    await jobs.waitForOwner(id, "other");
    expect(done).toBe(false);
    release();
    await waiting;
    expect(reads).not.toHaveBeenCalled();
    await jobs.waitForOwner(id, context.conversationId);
    expect(reads).not.toHaveBeenCalled();
  });

  it("bounds retained completed metadata while preserving old jobs and the complete list", async () => {
    const { logger } = indexedLog();
    const jobs = new BrowserJobs(logger, { maxCachedJobs: 3, maxIndexedEvents: 5 });
    for (let index = 0; index < 300; index++) {
      await logger.append({ type: "browser.job.state", ...context, content: { jobId: `job-${index}`, state: "queued" } });
      await logger.append({ type: "browser.job.progress", ...context, content: { jobId: `job-${index}`, index } });
      await logger.append({ type: "browser.job.state", ...context, content: { jobId: `job-${index}`, state: "succeeded" }, output: index });
    }
    const listed: any[] = [];
    let cursor: string | undefined;
    do {
      const page: any = await jobs.query({ action: "list", limit: 25, cursor }, context.conversationId);
      expect(page.jobs.length).toBeLessThanOrEqual(25);
      listed.push(...page.jobs);
      cursor = page.nextCursor;
    } while (cursor);
    expect(listed).toHaveLength(300);
    expect(listed[0]).toEqual({ id: "job-0", state: "succeeded" });
    const projection = (jobs as any).projections.get(context.conversationId);
    expect(projection.jobs.size).toBeLessThanOrEqual(3);
    expect(projection.indexedEvents).toBeLessThanOrEqual(5);
    expect(projection.cacheOrder.size).toBeLessThanOrEqual(3);
    const first: any = await jobs.query({ action: "status", id: "job-0", limit: 2 }, context.conversationId);
    expect(first).toMatchObject({ state: "succeeded", result: 0, hasMore: true, events: [{ state: "queued" }, { index: 0 }] });
    expect(await jobs.query({ action: "status", id: "job-0", after: first.nextCursor }, context.conversationId)).toMatchObject({ events: [{ state: "succeeded" }], hasMore: false });
    expect(projection.jobs.size).toBeLessThanOrEqual(3);
  });

  it("pages a stable snapshot while jobs change and new jobs are created", async () => {
    const { logger } = indexedLog();
    const jobs = new BrowserJobs(logger, { maxCachedJobs: 1 });
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "first", state: "queued" } });
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "first", state: "succeeded" } });
    let release!: () => void;
    const gate = new Promise<void>((resolve) => { release = resolve; });
    const active = await jobs.start(context, undefined, async (_signal, _id, started) => { await started(); await gate; return "done"; });
    await vi.waitFor(async () => expect(await jobs.query({ action: "status", id: active }, context.conversationId)).toMatchObject({ state: "running" }));
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "third", state: "queued" } });
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "third", state: "succeeded" } });
    const first: any = await jobs.query({ action: "list", limit: 1 }, context.conversationId);
    expect(first).toMatchObject({ jobs: [{ id: "first", state: "succeeded" }], hasMore: true, nextCursor: expect.any(String) });
    release();
    await jobs.completion(active, context.conversationId);
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "later", state: "queued" } });
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "later", state: "succeeded" } });
    const second: any = await jobs.query({ action: "list", cursor: first.nextCursor, limit: 1 }, context.conversationId);
    expect(second).toMatchObject({ jobs: [{ id: active, state: "running" }], hasMore: true });
    const third: any = await jobs.query({ action: "list", cursor: second.nextCursor, limit: 1 }, context.conversationId);
    expect(third).toEqual({ jobs: [{ id: "third", state: "succeeded" }], hasMore: false });
    expect(await jobs.query({ action: "status", id: active }, context.conversationId)).toMatchObject({ state: "succeeded" });
  });

  it("rejects wrong-conversation, malformed and expired list cursors", async () => {
    const { logger } = indexedLog();
    const jobs = new BrowserJobs(logger);
    for (const id of ["one", "two"]) {
      await logger.append({ type: "browser.job.state", ...context, content: { jobId: id, state: "queued" } });
      await logger.append({ type: "browser.job.state", ...context, content: { jobId: id, state: "succeeded" } });
    }
    const first: any = await jobs.query({ action: "list", limit: 1 }, context.conversationId);
    await expect(jobs.query({ action: "list", cursor: first.nextCursor }, "different-conversation")).rejects.toMatchObject({ code: "invalid-job-cursor" });
    await expect(jobs.query({ action: "list", cursor: "garbage" }, context.conversationId)).rejects.toMatchObject({ code: "invalid-job-cursor" });
    await logger.clear();
    await expect(jobs.query({ action: "list", cursor: first.nextCursor }, context.conversationId)).rejects.toMatchObject({ code: "job-cursor-expired" });
  });

  it("fails a continuation if the log is cleared during its page scan", async () => {
    const { logger } = indexedLog();
    const jobs = new BrowserJobs(logger, { maxCachedJobs: 0 });
    for (const id of ["one", "two", "three"]) {
      await logger.append({ type: "browser.job.state", ...context, content: { jobId: id, state: "queued" } });
      await logger.append({ type: "browser.job.state", ...context, content: { jobId: id, state: "succeeded" } });
    }
    const first: any = await jobs.query({ action: "list", limit: 1 }, context.conversationId);
    const original = logger.jobEventsSince.bind(logger);
    let reached!: () => void, release!: () => void;
    const ready = new Promise<void>((resolve) => { reached = resolve; });
    const gate = new Promise<void>((resolve) => { release = resolve; });
    vi.spyOn(logger, "jobEventsSince").mockImplementation(async (...args) => {
      const page = await original(...args);
      if (args[1] > 0 && args[1] < 6) { reached(); await gate; }
      return page;
    });
    const pending = jobs.query({ action: "list", limit: 1, cursor: first.nextCursor }, context.conversationId);
    await ready;
    await logger.clear();
    release();
    await expect(pending).rejects.toMatchObject({ code: "job-cursor-expired" });
  });

  it("validates the bounded list size at the job layer", async () => {
    const { logger } = indexedLog();
    const jobs = new BrowserJobs(logger);
    for (const limit of [0, -1, 101, 1.5]) {
      await expect(jobs.query({ action: "list", limit }, context.conversationId)).rejects.toThrow("limit");
    }
  });

  it("reuses a complete projection for the first page", async () => {
    const { logger, byTypes } = indexedLog();
    const jobs = new BrowserJobs(logger);
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "one", state: "queued" } });
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "one", state: "succeeded" } });
    await jobs.query({ action: "list" }, context.conversationId);
    byTypes.mockClear();
    expect(await jobs.query({ action: "list" }, context.conversationId)).toEqual({ jobs: [{ id: "one", state: "succeeded" }], hasMore: false });
    const jobReads = byTypes.mock.calls.filter(([types]) => types.includes("browser.job.state"));
    expect(jobReads).toHaveLength(1);
    expect(jobReads[0][2]).toBeGreaterThan(0);
  });

  it("does not treat a later event for an evicted job as its complete history", async () => {
    const { logger } = indexedLog();
    const jobs = new BrowserJobs(logger, { maxCachedJobs: 1 });
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "old", state: "succeeded" }, output: "done" });
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "new", state: "succeeded" } });
    await jobs.query({ action: "list" }, context.conversationId);
    await logger.append({ type: "browser.job.progress", ...context, content: { jobId: "old", value: "late" } });
    const result: any = await jobs.query({ action: "status", id: "old" }, context.conversationId);
    expect(result).toMatchObject({ state: "succeeded", result: "done", events: [{ state: "succeeded" }, { value: "late" }] });
  });

  it("indexes newly queued jobs after earlier jobs were evicted", async () => {
    const { logger } = indexedLog();
    const jobs = new BrowserJobs(logger, { maxCachedJobs: 1 });
    for (const id of ["one", "two"]) await logger.append({ type: "browser.job.state", ...context, content: { jobId: id, state: "succeeded" } });
    await jobs.query({ action: "list" }, context.conversationId);
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "fresh", state: "queued" } });
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "fresh", state: "succeeded" } });
    await jobs.query({ action: "status", id: "fresh" }, context.conversationId);
    const projection = (jobs as any).projections.get(context.conversationId);
    expect(projection.jobs.get("fresh").eventIds).toHaveLength(2);
  });

  it("retries rebuilding an evicted job if the log is cleared during the scan", async () => {
    const { logger } = indexedLog();
    const jobs = new BrowserJobs(logger, { maxCachedJobs: 0 });
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "old", state: "succeeded" }, output: "stale" });
    await jobs.query({ action: "list" }, context.conversationId);
    const original = logger.jobEventsSince.bind(logger);
    let reached!: () => void, release!: () => void;
    const ready = new Promise<void>((resolve) => { reached = resolve; });
    const gate = new Promise<void>((resolve) => { release = resolve; });
    vi.spyOn(logger, "jobEventsSince").mockImplementation(async (...args) => {
      const page = await original(...args);
      if (args[1] === -1) { reached(); await gate; }
      return page;
    });
    const querying = jobs.query({ action: "status", id: "old" }, context.conversationId);
    await ready;
    await logger.clear();
    release();
    await expect(querying).rejects.toThrow("unavailable");
  });

  it("does not return a stale list when the log is cleared during reconstruction", async () => {
    const { logger } = indexedLog();
    const jobs = new BrowserJobs(logger, { maxCachedJobs: 0 });
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "old", state: "succeeded" } });
    await jobs.query({ action: "list" }, context.conversationId);
    const original = logger.jobEventsSince.bind(logger);
    let reached!: () => void, release!: () => void;
    const ready = new Promise<void>((resolve) => { reached = resolve; });
    const gate = new Promise<void>((resolve) => { release = resolve; });
    vi.spyOn(logger, "jobEventsSince").mockImplementation(async (...args) => {
      const page = await original(...args);
      if (args[1] === -1) { reached(); await gate; }
      return page;
    });
    const querying = jobs.query({ action: "list" }, context.conversationId);
    await ready;
    await logger.clear();
    release();
    expect(await querying).toEqual({ jobs: [], hasMore: false });
  });

  it("recovers abandoned jobs even when no completed metadata is retained", async () => {
    const { logger, events } = indexedLog();
    const jobs = new BrowserJobs(logger, { maxCachedJobs: 0 });
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "lost", state: "queued" } });
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "lost", state: "running" } });
    expect(await jobs.query({ action: "status", id: "lost" }, context.conversationId)).toMatchObject({ state: "interrupted", terminal: true });
    expect(events.filter((event) => (fromLogValue(event.content) as any)?.state === "interrupted")).toHaveLength(1);
    expect(await jobs.query({ action: "list" }, context.conversationId)).toEqual({ jobs: [{ id: "lost", state: "interrupted" }], hasMore: false });
  });

  it("catches up incrementally, batches event reads, and coalesces concurrent readers", async () => {
    const { logger, byTypes, getMany } = indexedLog();
    const jobs = new BrowserJobs(logger);
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "long", state: "running" } });
    for (let index = 0; index < 280; index++) await logger.append({ type: "browser.job.progress", ...context, content: { jobId: "long", index }, output: "x".repeat(1024) });
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "long", state: "succeeded" }, output: "done" });
    const baseline: any = await jobs.query({ action: "status", id: "long", limit: 500 }, context.conversationId);
    expect(baseline.events).toHaveLength(282);
    byTypes.mockClear(); getMany.mockClear();
    await Promise.all(Array.from({ length: 20 }, () => jobs.query({ action: "status", id: "long", after: baseline.nextCursor }, context.conversationId)));
    const reads = byTypes.mock.calls.filter(([types]) => types.includes("browser.job.progress"));
    expect(reads.length).toBeLessThanOrEqual(2);
    expect(reads.every(([, conversationId, afterId]) => conversationId === context.conversationId && afterId === baseline.nextCursor)).toBe(true);
    expect(getMany.mock.calls.every(([ids]) => ids.length === 1)).toBe(true);
    await logger.append({ type: "browser.job.progress", ...context, content: { jobId: "long", index: 280 } });
    const delta: any = await jobs.query({ action: "status", id: "long", after: baseline.nextCursor }, context.conversationId);
    expect(delta.events).toMatchObject([{ index: 280 }]);
  });

  it("rechecks a shared catch-up when a second reader starts after an append", async () => {
    const { logger } = indexedLog();
    const jobs = new BrowserJobs(logger);
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "shared", state: "succeeded" } });
    await jobs.query({ action: "status", id: "shared" }, context.conversationId);
    const original = logger.jobEventsSince.bind(logger);
    let captured!: () => void, release!: () => void;
    const ready = new Promise<void>((resolve) => { captured = resolve; });
    const gate = new Promise<void>((resolve) => { release = resolve; });
    let first = true;
    vi.spyOn(logger, "jobEventsSince").mockImplementation(async (...args) => {
      const page = await original(...args);
      if (first) { first = false; captured(); await gate; }
      return page;
    });
    const one = jobs.query({ action: "status", id: "shared" }, context.conversationId);
    await ready;
    await logger.append({ type: "browser.job.progress", ...context, content: { jobId: "shared", value: "new" } });
    const two = jobs.query({ action: "status", id: "shared" }, context.conversationId);
    release();
    const [, second]: any[] = await Promise.all([one, two]);
    expect(second.events).toContainEqual(expect.objectContaining({ value: "new" }));
  });

  it("lets earlier readers finish while later readers trigger another catch-up", async () => {
    const { logger } = indexedLog();
    const jobs = new BrowserJobs(logger);
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "job", state: "succeeded" } });
    const original = logger.jobEventsSince.bind(logger);
    let releaseFirst!: () => void, releaseSecond!: () => void, firstReady!: () => void, secondReady!: () => void;
    const firstGate = new Promise<void>((resolve) => { releaseFirst = resolve; });
    const secondGate = new Promise<void>((resolve) => { releaseSecond = resolve; });
    const firstStarted = new Promise<void>((resolve) => { firstReady = resolve; });
    const secondStarted = new Promise<void>((resolve) => { secondReady = resolve; });
    let calls = 0;
    vi.spyOn(logger, "jobEventsSince").mockImplementation(async (...args) => {
      const page = await original(...args);
      if (++calls === 1) { firstReady(); await firstGate; }
      else if (calls === 2) { secondReady(); await secondGate; }
      return page;
    });
    const first = jobs.query({ action: "status", id: "job" }, context.conversationId);
    await firstStarted;
    const second = jobs.query({ action: "status", id: "job" }, context.conversationId);
    releaseFirst();
    await secondStarted;
    expect(await first).toMatchObject({ state: "succeeded" });
    releaseSecond();
    expect(await second).toMatchObject({ state: "succeeded" });
  });

  it("keeps pagination complete after ID-cache eviction and invalidates it on log clear", async () => {
    const { logger } = indexedLog();
    const jobs = new BrowserJobs(logger, { maxIndexedEvents: 1 });
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "old", state: "running" } });
    await logger.append({ type: "browser.job.progress", ...context, content: { jobId: "other", value: 9 } });
    await logger.append({ type: "browser.job.progress", ...context, content: { jobId: "old", value: 1 } });
    await logger.append({ type: "browser.job.progress", ...context, content: { jobId: "old", value: 2 } });
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "old", state: "succeeded" }, output: "old-result" });
    const first: any = await jobs.query({ action: "status", id: "old", limit: 2 }, context.conversationId);
    expect(first.events).toMatchObject([{ state: "running" }, { value: 1 }]);
    expect(first.hasMore).toBe(true);
    const second: any = await jobs.query({ action: "status", id: "old", after: first.nextCursor, limit: 2 }, context.conversationId);
    expect(second.events).toMatchObject([{ value: 2 }, { state: "succeeded" }]);
    expect(second.hasMore).toBe(false);
    await logger.clear();
    await expect(jobs.query({ action: "status", id: "old" }, context.conversationId)).rejects.toThrow("unavailable");
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "old", state: "succeeded" }, output: "new-result" });
    const fresh: any = await jobs.query({ action: "status", id: "old" }, context.conversationId);
    expect(fresh.events).toHaveLength(1);
    expect(fresh.result).toBe("new-result");
  });

  it("does not resurrect a recovered job when its clear epoch changes before the conditional append", async () => {
    const { logger, events } = indexedLog();
    const jobs = new BrowserJobs(logger);
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "lost", state: "running" } });
    const append = logger.appendIfEpoch.bind(logger);
    let reached!: () => void, release!: () => void;
    const ready = new Promise<void>((resolve) => { reached = resolve; });
    const gate = new Promise<void>((resolve) => { release = resolve; });
    vi.spyOn(logger, "appendIfEpoch").mockImplementation(async (record, epoch, expectedId) => { reached(); await gate; return append(record, epoch, expectedId); });
    const querying = jobs.query({ action: "status", id: "lost" }, context.conversationId);
    await ready;
    await logger.clear();
    release();
    await expect(querying).rejects.toThrow("unavailable");
    expect(events.filter((event) => (fromLogValue(event.content) as any)?.state === "interrupted")).toHaveLength(0);
  });

  it("does not overwrite a terminal event that commits before the recovery CAS", async () => {
    const { logger, store, events } = indexedLog();
    const jobs = new BrowserJobs(logger);
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "lost", state: "running" } });
    const append = logger.appendIfEpoch.bind(logger);
    let reached!: () => void, release!: () => void;
    const ready = new Promise<void>((resolve) => { reached = resolve; });
    const gate = new Promise<void>((resolve) => { release = resolve; });
    vi.spyOn(logger, "appendIfEpoch").mockImplementation(async (record, epoch, expectedId) => { reached(); await gate; return append(record, epoch, expectedId); });
    const querying = jobs.query({ action: "status", id: "lost" }, context.conversationId);
    await ready;
    await new EventLogger({ store }).append({ type: "browser.job.state", ...context, content: { jobId: "lost", state: "succeeded" }, output: "done" });
    release();
    expect(await querying).toMatchObject({ state: "succeeded", terminal: true, result: "done" });
    expect(events.filter((event) => (fromLogValue(event.content) as any)?.state === "interrupted")).toHaveLength(0);
  });

  it("does not report an abandoned job as live when recovery cannot be persisted", async () => {
    const { logger } = indexedLog();
    const jobs = new BrowserJobs(logger);
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "lost", state: "running" } });
    logger.stop();
    await expect(jobs.query({ action: "status", id: "lost" }, context.conversationId)).rejects.toThrow("Could not persist job recovery");
  });

  it("discards a page if the log is cleared while its event IDs are being read", async () => {
    const { logger, getMany } = indexedLog();
    const jobs = new BrowserJobs(logger);
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "old", state: "succeeded" }, output: "secret" });
    await jobs.query({ action: "status", id: "old" }, context.conversationId);
    const original = getMany.getMockImplementation()!;
    let captured!: () => void, release!: () => void;
    const ready = new Promise<void>((resolve) => { captured = resolve; });
    const gate = new Promise<void>((resolve) => { release = resolve; });
    getMany.mockImplementation(async (ids) => { const result = await original(ids); captured(); await gate; return result; });
    const querying = jobs.query({ action: "status", id: "old" }, context.conversationId);
    await ready;
    await logger.clear();
    release();
    await expect(querying).rejects.toThrow("unavailable");
  });
  it("never misidentifies a queued job as host-lost while its start is still publishing", async () => {
    const { logger, events } = log();
    const jobs = new BrowserJobs(logger);
    const append = logger.append.bind(logger);
    let release!: () => void;
    let published!: () => void;
    const queued = new Promise<void>((resolve) => { published = resolve; });
    const gate = new Promise<void>((resolve) => { release = resolve; });
    vi.spyOn(logger, "append").mockImplementation(async (record) => {
      const event = await append(record);
      if (record.type === "browser.job.state" && (record.content as any)?.state === "queued") {
        published();
        await gate;
      }
      return event;
    });
    const execute = vi.fn(async () => undefined);
    const starting = jobs.start(context, undefined, execute);
    await queued;
    const id = (fromLogValue(events[0]!.content) as any).jobId;
    expect(await jobs.query({ action: "list" }, context.conversationId)).toEqual({ jobs: [{ id, state: "queued" }], hasMore: false });
    expect(await jobs.query({ action: "cancel", id }, context.conversationId)).toMatchObject({ state: "queued", terminal: false });
    release();
    expect(await starting).toBe(id);
    expect(await jobs.completion(id, context.conversationId)).toMatchObject({ state: "cancelled", terminal: true });
    expect(execute).not.toHaveBeenCalled();
    expect(events.filter((event) => (fromLogValue(event.content) as any)?.state === "interrupted")).toHaveLength(0);
  });

  it("does not overwrite a real terminal result when a reader holds an older running snapshot", async () => {
    const { logger, events } = log();
    const jobs = new BrowserJobs(logger);
    let finish!: () => void;
    const id = await jobs.start(context, undefined, async (_signal, _id, started) => {
      await started();
      await new Promise<void>((resolve) => { finish = resolve; });
      return "done";
    });
    await vi.waitFor(() => expect(finish).toBeTypeOf("function"));
    const original = logger.jobEventsSince.bind(logger);
    let read!: () => void;
    let release!: () => void;
    const captured = new Promise<void>((resolve) => { read = resolve; });
    const gate = new Promise<void>((resolve) => { release = resolve; });
    let first = true;
    vi.spyOn(logger, "jobEventsSince").mockImplementation(async (conversationId, afterId, limit) => {
      const snapshot = await original(conversationId, afterId, limit);
      if (first) { first = false; read(); await gate; }
      return snapshot;
    });
    const querying = jobs.query({ action: "status", id }, context.conversationId);
    await captured;
    finish();
    await vi.waitFor(() => expect(events.some((event) => (fromLogValue(event.content) as any)?.state === "succeeded")).toBe(true));
    release();
    expect(await querying).toMatchObject({ state: "succeeded", terminal: true, result: "done" });
    expect(events.filter((event) => (fromLogValue(event.content) as any)?.state === "interrupted")).toHaveLength(0);
  });

  it("rechecks abandoned-job candidates and deduplicates concurrent recovery", async () => {
    const { logger, events } = log();
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "lost", state: "running" } });
    const jobs = new BrowserJobs(logger);
    await Promise.all([
      jobs.query({ action: "status", id: "lost" }, context.conversationId),
      jobs.query({ action: "list" }, context.conversationId),
    ]);
    expect(events.filter((event) => (fromLogValue(event.content) as any)?.state === "interrupted")).toHaveLength(1);
  });

  it("rechecks the durable state before recovering an apparently lost job", async () => {
    const { logger, events } = log();
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "old", state: "running" } });
    const jobs = new BrowserJobs(logger);
    const original = logger.jobEventsSince.bind(logger);
    let read!: () => void;
    let release!: () => void;
    const captured = new Promise<void>((resolve) => { read = resolve; });
    const gate = new Promise<void>((resolve) => { release = resolve; });
    let first = true;
    vi.spyOn(logger, "jobEventsSince").mockImplementation(async (conversationId, afterId, limit) => {
      const snapshot = await original(conversationId, afterId, limit);
      if (first) { first = false; read(); await gate; }
      return snapshot;
    });
    const querying = jobs.query({ action: "status", id: "old" }, context.conversationId);
    await captured;
    await logger.append({ type: "browser.job.state", ...context, content: { jobId: "old", state: "succeeded" }, output: "saved" });
    release();
    expect(await querying).toMatchObject({ state: "succeeded", terminal: true, result: "saved" });
    expect(events.filter((event) => (fromLogValue(event.content) as any)?.state === "interrupted")).toHaveLength(0);
  });

  it("returns unread progress immediately and waits for the next matching receipt", async () => {
    const { logger } = log();
    const jobs = new BrowserJobs(logger);
    let finish!: () => void;
    const id = await jobs.start(context, undefined, async (_signal, _id, started) => {
      await started();
      await new Promise<void>((resolve) => { finish = resolve; });
    });
    await vi.waitFor(() => expect(finish).toBeTypeOf("function"));
    const baseline: any = await jobs.query({ action: "status", id }, context.conversationId);
    await logger.append({ type: "browser.job.progress", ...context, content: { jobId: id, operation: "first" } });
    const unread: any = await jobs.query({ action: "wait", id, after: baseline.nextCursor, waitMs: 10_000 }, context.conversationId);
    expect(unread.events).toMatchObject([{ operation: "first" }]);
    let returned = false;
    const waiting = jobs.query({ action: "wait", id, after: unread.nextCursor, waitMs: 10_000 }, context.conversationId).then((result) => { returned = true; return result; });
    await logger.append({ type: "browser.job.progress", conversationId: "another", content: { jobId: id, operation: "unrelated" } });
    await logger.append({ type: "browser.job.progress", ...context, content: { jobId: "other-job", operation: "unrelated" } });
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(returned).toBe(false);
    await logger.append({ type: "browser.job.progress", ...context, content: { jobId: id, operation: "second" } });
    expect(await waiting).toMatchObject({ state: "running", terminal: false, events: [{ operation: "second" }] });
    finish();
    await jobs.completion(id, context.conversationId);
  });

  it("removes its subscription on cancellation", async () => {
    const { logger } = log();
    const jobs = new BrowserJobs(logger);
    let finish!: () => void;
    const id = await jobs.start(context, undefined, async (_signal, _id, started) => {
      await started();
      await new Promise<void>((resolve) => { finish = resolve; });
    });
    await vi.waitFor(() => expect(finish).toBeTypeOf("function"));
    const baseline: any = await jobs.query({ action: "status", id }, context.conversationId);
    const subscribe = logger.subscribe.bind(logger);
    const removed = vi.fn();
    vi.spyOn(logger, "subscribe").mockImplementation((listener) => {
      const unsubscribe = subscribe(listener);
      return () => { removed(); unsubscribe(); };
    });
    const controller = new AbortController();
    const waiting = jobs.query({ action: "wait", id, after: baseline.nextCursor, waitMs: 10_000 }, context.conversationId, controller.signal);
    controller.abort(new DOMException("cancelled", "AbortError"));
    await expect(waiting).rejects.toMatchObject({ name: "AbortError" });
    expect(removed).toHaveBeenCalledOnce();
    finish();
    await jobs.completion(id, context.conversationId);
  });

  it("does not miss a receipt committed between subscription and the initial read", async () => {
    const { logger } = log();
    const jobs = new BrowserJobs(logger);
    let finish!: () => void;
    const id = await jobs.start(context, undefined, async (_signal, _id, started) => {
      await started();
      await new Promise<void>((resolve) => { finish = resolve; });
    });
    await vi.waitFor(() => expect(finish).toBeTypeOf("function"));
    const baseline: any = await jobs.query({ action: "status", id }, context.conversationId);
    const original = logger.jobEventsSince.bind(logger);
    let read!: () => void;
    let release!: () => void;
    const captured = new Promise<void>((resolve) => { read = resolve; });
    const gate = new Promise<void>((resolve) => { release = resolve; });
    let first = true;
    vi.spyOn(logger, "jobEventsSince").mockImplementation(async (conversationId, afterId, limit) => {
      const snapshot = await original(conversationId, afterId, limit);
      if (first) { first = false; read(); await gate; }
      return snapshot;
    });
    const waiting = jobs.query({ action: "wait", id, after: baseline.nextCursor, waitMs: 10_000 }, context.conversationId);
    await captured;
    await logger.append({ type: "browser.job.progress", ...context, content: { jobId: id, operation: "during-read" } });
    release();
    expect(await waiting).toMatchObject({ terminal: false, events: [{ operation: "during-read" }] });
    finish();
    await jobs.completion(id, context.conversationId);
  });
  it("returns cursor slices and rejects jobs owned by another conversation", async () => {
    const { logger } = log();
    const jobs = new BrowserJobs(logger);
    const id = await jobs.start(
      context,
      undefined,
      async (_signal, _id, started) => {
        await started();
        return { value: 7 };
      },
    );
    await jobs.completion(id, context.conversationId);
    const first: any = await jobs.query(
      { action: "status", id, limit: 1 },
      context.conversationId,
    );
    expect(first).toMatchObject({
      state: "succeeded",
      ok: true,
      result: { value: 7 },
      hasMore: true,
    });
    const rest: any = await jobs.query(
      { action: "status", id, after: first.nextCursor },
      context.conversationId,
    );
    expect(
      rest.events.every((event: any) => event.cursor > first.nextCursor),
    ).toBe(true);
    expect(rest.hasMore).toBe(false);
    await expect(
      jobs.query({ action: "cancel", id }, "other-conversation"),
    ).rejects.toThrow("unavailable");
  });
  it("honors a wait longer than 30 seconds without cancelling the job", async () => {
    const { logger } = log();
    const jobs = new BrowserJobs(logger);
    let finish!: () => void;
    const id = await jobs.start(context, undefined, async (_signal, _id, started) => {
      await started();
      await new Promise<void>((resolve) => { finish = resolve; });
    });
    await vi.waitFor(() => expect(finish).toBeTypeOf("function"));
    const baseline: any = await jobs.query({ action: "status", id }, context.conversationId);
    vi.useFakeTimers();
    let returned = false;
    const waiting = jobs.query({ action: "wait", id, after: baseline.nextCursor, waitMs: 60_000 }, context.conversationId).then((value) => { returned = true; return value; });
    await vi.advanceTimersByTimeAsync(30_001);
    expect(returned).toBe(false);
    await vi.advanceTimersByTimeAsync(29_999);
    expect(await waiting).toMatchObject({ state: "running", terminal: false });
    finish();
    await jobs.settle(context.conversationId);
  });
  it("keeps cancellation pending until the execution host completes cleanup and never rolls back", async () => {
    const { logger } = log();
    const jobs = new BrowserJobs(logger);
    let cleaned!: () => void;
    let effects = 0;
    const id = await jobs.start(
      context,
      undefined,
      async (signal, _id, started) => {
        await started();
        effects++;
        await new Promise<void>((resolve) => {
          cleaned = resolve;
        });
        signal.throwIfAborted();
      },
    );
    await vi.waitFor(() => expect(effects).toBe(1));
    expect(
      await jobs.query({ action: "cancel", id }, context.conversationId),
    ).toMatchObject({ state: "running", terminal: false, rollback: false });
    cleaned();
    expect(
      await jobs.completion(id, context.conversationId),
    ).toMatchObject({ state: "cancelled", terminal: true, ok: false });
    expect(effects).toBe(1);
  });
  it("projects a lost host as interrupted and preserves partial receipts without replay", async () => {
    const { logger, events } = log();
    await logger.append({
      type: "browser.job.state",
      ...context,
      content: { jobId: "lost", state: "running" },
    });
    await logger.append({
      type: "browser.job.progress",
      ...context,
      content: {
        jobId: "lost",
        sequence: 1,
        operation: "click",
        state: "completed",
      },
    });
    const recovered = new BrowserJobs(logger);
    expect(
      await recovered.query(
        { action: "status", id: "lost" },
        context.conversationId,
      ),
    ).toMatchObject({
      state: "interrupted",
      result: {
        error: { code: "execution-state-unknown", retryable: false, effectUnknown: true,
          message: expect.stringContaining("terminal write may have failed") },
      },
    });
    await recovered.query(
      { action: "status", id: "lost" },
      context.conversationId,
    );
    expect(
      events.filter((event) => event.type === "browser.job.state"),
    ).toHaveLength(2);
  });
  it("returns the exact failed step error alongside partial progress", async () => {
    const { logger } = log();
    const jobs = new BrowserJobs(logger);
    const id = await jobs.start(
      context,
      undefined,
      async (signal, id, started) => {
        await started();
        const scope = new ProgramScope(signal, id, context, logger);
        await scope.call("first", () => ({ performed: true }), false);
        await scope.call("check", () => { throw new Error("outcome did not match"); }, false, true);
      },
    );
    const result: any = await jobs.completion(id, context.conversationId);
    expect(result.events).toContainEqual(
      expect.objectContaining({
        operation: "first",
        state: "completed",
        output: { performed: true },
      }),
    );
    expect(result.events).toContainEqual(
      expect.objectContaining({
        operation: "check",
        state: "not-dispatched",
        error: expect.objectContaining({ message: "outcome did not match" }),
      }),
    );
  });
  it("reports timeout as failure and cleans bounded wait timers", async () => {
    const { logger } = log();
    const jobs = new BrowserJobs(logger);
    const id = await jobs.start(context, undefined, async () => {
      throw new DOMException("deadline", "TimeoutError");
    });
    expect(
      await jobs.completion(id, context.conversationId),
    ).toMatchObject({
      state: "failed",
      result: { error: { code: "timeout", retryable: false } },
    });
  });
});

describe("revocable program capabilities", () => {
  it("records bounded capability receipts while returning the actual live handles", async () => {
    const { logger, events } = log();
    const scope = new ProgramScope(new AbortController().signal, "job", context, logger);
    const page = new PageFacade({} as AutomationRuntime, 42);
    const wrapped = scope.wrap(new Proxy(page, {}));
    const locator = new LocatorFacade({} as AutomationRuntime, 42, { queries: [] });
    for (const [operation, handle] of [["page.waitForEvent", page], ["browser.page", wrapped], ["tabs.open", new Proxy(wrapped, {})], ["page.locator", locator]] as const)
      expect(await scope.call(operation, async () => handle, false)).toBe(handle);
    const ordinary = { type: "browser-capability", kind: "page", tabId: 42, extra: "user data" };
    expect(await scope.call("page.evaluate", async () => ordinary, false)).toBe(ordinary);
    const outputs = events.filter((event) => (fromLogValue(event.content, event.valueEncoding) as any)?.state === "completed")
      .map((event) => fromLogValue(event.output, event.valueEncoding));
    expect(outputs).toEqual([{ type: "browser-capability", kind: "page", tabId: 42 }, { type: "browser-capability", kind: "page", tabId: 42 },
      { type: "browser-capability", kind: "page", tabId: 42 }, { type: "browser-capability", kind: "locator", tabId: 42 }, ordinary]);
  });
  it("serializes mutations, subscribes before them, and separates dispatch from verification", async () => {
    const { logger, events } = log();
    const scope = new ProgramScope(
      new AbortController().signal,
      "job",
      context,
      logger,
    );
    const order: string[] = [];
    let notify!: () => void;
    const waiting = scope.call(
      "waitForEvent",
      () => {
        order.push("subscribe");
        return new Promise<void>((resolve) => {
          notify = resolve;
        });
      },
      false,
      false,
      true,
    );
    const first = scope.call("fill", async () => {
      await Promise.all([scope.dispatched(), scope.dispatched()]);
      order.push("fill");
      await Promise.resolve();
      notify();
      return { performed: true };
    });
    const second = scope.call("click", async () => {
      await scope.dispatched();
      order.push("click");
    });
    await Promise.all([waiting, first, second]);
    await scope.call("readCondition", () => { expect(order.join()).toBe("subscribe,fill,click"); }, false, true);
    await scope.finish();
    expect(scope.effectUnknown).toBe(false);
    expect(
      events.filter((event) => {
        const content = fromLogValue(event.content) as any;
        return (
          content.operation === "fill" && content.state === "dispatched-unknown"
        );
      }),
    ).toHaveLength(1);
    expect(events.map((event) => fromLogValue(event.content))).toContainEqual(
      expect.objectContaining({ operation: "readCondition", state: "verified" }),
    );
    expect(events.map((event) => fromLogValue(event.content))).toContainEqual(
      expect.objectContaining({
        operation: "fill",
        state: "dispatched-unknown",
      }),
    );
    expect(() => scope.call("late", () => order.push("late"))).toThrow(
      "expired",
    );
  });

  it.each(["accept", "dismiss", "setFiles"] as const)("isolates concurrent %s dispatch from an ordered action", async (method) => {
    for (const first of ["action", "event"] as const) for (const finishFirst of ["action", "event"] as const) {
      const { logger, events } = log();
      const scope = new ProgramScope(new AbortController().signal, "job", context, logger);
      let startAction!: () => void, startEvent!: () => void, releaseAction!: () => void, releaseEvent!: () => void;
      const actionStarted = new Promise<void>((resolve) => { startAction = resolve; });
      const eventStarted = new Promise<void>((resolve) => { startEvent = resolve; });
      const actionGate = new Promise<void>((resolve) => { releaseAction = resolve; });
      const eventGate = new Promise<void>((resolve) => { releaseEvent = resolve; });
      const target = {
        [method]: async () => { throw new Error("Event must use isolated invocation"); },
        [PROGRAM_EVENT_INVOKE]: async (operation: string, _args: unknown[], dispatch: () => Promise<void>) => {
          expect(operation).toBe(method); startEvent(); await eventGate; await dispatch(); throw new Error("event failed after dispatch");
        },
      };
      const wrapped = scope.wrap(target, "event");
      const action = () => scope.call("click", async () => { startAction(); await actionGate; await scope.dispatched(); throw new Error("action failed after dispatch"); });
      let a: Promise<unknown>, b: Promise<unknown>;
      if (first === "action") { a = action().catch((error) => error); await actionStarted; b = wrapped[method]().catch((error) => error); await eventStarted; }
      else { b = wrapped[method]().catch((error) => error); await eventStarted; a = action().catch((error) => error); await actionStarted; }
      if (finishFirst === "action") {
        releaseAction();
        expect(await a).toMatchObject({ message: "action failed after dispatch", effectUnknown: true });
        releaseEvent();
        expect(await b).toMatchObject({ message: "event failed after dispatch", effectUnknown: true });
      } else {
        releaseEvent();
        expect(await b).toMatchObject({ message: "event failed after dispatch", effectUnknown: true });
        releaseAction();
        expect(await a).toMatchObject({ message: "action failed after dispatch", effectUnknown: true });
      }
      const receipts = events.map((event) => fromLogValue(event.content) as any);
      for (const operation of ["click", `event.${method}`]) {
        expect(receipts.filter((item) => item.operation === operation && item.state === "dispatched-unknown")).toHaveLength(2);
        expect(receipts.filter((item) => item.operation === operation && item.state === "not-dispatched")).toHaveLength(1);
      }
      expect(scope.effectUnknown).toBe(true);
      // An unrelated later operation must never inherit a finished marker.
      await scope.dispatched();
      expect(events.map((event) => fromLogValue(event.content) as any).filter((item) => item.state === "dispatched-unknown")).toHaveLength(4);
    }
  });
  it.each([false, true])("preserves a concurrent event's dispatch state across cancellation (dispatched=%s)", async (dispatched) => {
    const { logger, events } = log();
    const controller = new AbortController();
    const scope = new ProgramScope(controller.signal, "job", context, logger);
    let started!: () => void, release!: () => void;
    const running = new Promise<void>((resolve) => { started = resolve; });
    const gate = new Promise<void>((resolve) => { release = resolve; });
    const target = {
      accept: async () => undefined,
      [PROGRAM_EVENT_INVOKE]: async (_operation: string, _args: unknown[], mark: () => Promise<void>) => {
        if (dispatched) await mark();
        started(); await gate;
        if (!dispatched) await mark();
      },
    };
    const action = scope.wrap(target, "event").accept().catch((error) => error);
    await running;
    controller.abort(); release();
    const error = await action;
    expect(Boolean(error.effectUnknown)).toBe(dispatched);
    const receipts = events.map((event) => fromLogValue(event.content) as any).filter((entry) => entry.operation === "event.accept");
    expect(receipts.at(-1)?.state).toBe(dispatched ? "dispatched-unknown" : "not-dispatched");
    expect(scope.effectUnknown).toBe(dispatched);
  });
  it("distinguishes rejected preconditions from uncertain dispatched effects and prevents queued late effects", async () => {
    const { logger, events } = log();
    const controller = new AbortController();
    const scope = new ProgramScope(controller.signal, "job", context, logger);
    await expect(
      scope.call("precondition", () => {
        throw new Error("strict match");
      }),
    ).rejects.toThrow("strict match");
    expect(scope.effectUnknown).toBe(false);
    let release!: () => void;
    const late = vi.fn();
    const first = scope.call("click", async () => {
      await scope.dispatched();
      await new Promise<void>((resolve) => {
        release = resolve;
      });
      scope.guard();
    });
    const queued = scope.call("late", late);
    const failure = expect(first).rejects.toBeDefined();
    const queuedFailure = expect(queued).rejects.toBeDefined();
    await vi.waitFor(() => expect(release).toBeTypeOf("function"));
    controller.abort(new DOMException("cancel", "AbortError"));
    scope.revoke();
    release();
    await Promise.all([failure, queuedFailure]);
    expect(late).not.toHaveBeenCalled();
    expect(scope.effectUnknown).toBe(true);
    expect(events.map((event) => fromLogValue(event.content))).toContainEqual(
      expect.objectContaining({
        operation: "precondition",
        state: "not-dispatched",
      }),
    );
  });
});

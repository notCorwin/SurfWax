import { describe, expect, it, vi } from "vitest";
import { EventLogger, type LogEvent } from "../logging";
import { BrowserDiagnostics } from "./diagnostics";

function harness() {
  const events: LogEvent[] = [];
  const logger = new EventLogger({ store: { async append(event) { const saved = { ...event, id: events.length + 1 }; events.push(saved); return saved; }, async all() { return events; }, async clear() { events.splice(0); } } });
  const diagnostics = new BrowserDiagnostics(logger);
  diagnostics.bind({ conversationId: "conversation" });
  return { diagnostics, logger, events };
}
function request(index: number) { return { requestId: `${index}`, request: { method: "POST", url: `https://test/${index}`, headers: { secret: "raw" }, postData: `body ${index}` }, type: "Fetch" }; }
function message(text: string) { return { type: "log", args: [{ value: text }] }; }

describe("BrowserDiagnostics", () => {
  it("reports failed child-frame capture and its originating command", async () => {
    const { diagnostics, logger, events } = harness();
    logger.beginRun("conversation", "run");
    diagnostics.bind({ conversationId: "conversation", logIdentity: logger.toolIdentity("conversation", "inspect") });
    diagnostics.captureFailed({ tabId: 1, sessionId: "child" }, "Network.enable", new Error("CDP refused"));
    expect(await diagnostics.requests(1, {})).toMatchObject({ integrity: "incomplete", reason: "diagnostic-capture-failed", hasMore: null });
    expect(await diagnostics.console(1, {})).toMatchObject({ integrity: "complete" });
    await logger.flush();
    expect(events).toContainEqual(expect.objectContaining({ type: "browser.diagnostic.capture-failed", runId: "run",
      content: expect.objectContaining({ method: "Network.enable", source: { tabId: 1, sessionId: "child" } }), error: expect.objectContaining({ message: "CDP refused" }) }));
  });
  it("keeps diagnostic events in the operation's original phase", async () => {
    const { diagnostics, logger, events } = harness();
    logger.beginRun("conversation", "run"); logger.setRunPhase("run", 1);
    diagnostics.bind({ conversationId: "conversation", toolCallId: "request", logIdentity: logger.toolIdentity("conversation", "request") });
    logger.setRunPhase("run", 2);
    diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", request(1));
    await logger.flush();
    expect(events[0]).toMatchObject({ runId: "run", toolCallId: "1:request" });
  });

  it("persists raw events, limits cache memory and restores old pages of requests from the canonical log", async () => {
    const { diagnostics, logger, events } = harness();
    for (let index = 1; index <= 1005; index += 1) diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", request(index));
    expect((diagnostics as any).tabs.get(1).network).toHaveLength(1000);
    const raw = request(1);
    await logger.flush();
    expect(events).toHaveLength(1005);
    expect(events[0]?.output).toEqual(raw);
    const page = await diagnostics.requests(1, { offset: 0, limit: 2 }) as any;
    expect(page).toMatchObject({ integrity: "complete", hasMore: true, nextOffset: 2 });
    const listed = page.requests;
    expect(listed).toEqual([
      { requestRef: expect.any(String), method: "POST", url: "https://test/1", status: undefined, statusText: undefined },
      { requestRef: expect.any(String), method: "POST", url: "https://test/2", status: undefined, statusText: undefined },
    ]);
    expect(await diagnostics.request(1, listed[0].requestRef)).toMatchObject({ requestBody: "body 1", requestHeaders: { secret: "raw" } });
  });
  it("replays a large mixed capture with late responses, redirects and distinct frame sessions", async () => {
    const { diagnostics } = harness();
    for (let index = 1; index <= 8000; index++) diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", request(index));
    for (let index = 1; index <= 1500; index++) diagnostics.handle({ tabId: 1 }, "Runtime.consoleAPICalled", message(`log ${index}`));
    diagnostics.handle({ tabId: 1 }, "Network.responseReceived", { requestId: "1", response: { status: 202, headers: {} } });
    diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", { ...request(1), redirectResponse: { status: 302 } });
    diagnostics.handle({ tabId: 1, sessionId: "frame" }, "Network.requestWillBeSent", request(1));
    const first = await diagnostics.requests(1, { limit: 1 }) as any;
    expect(first).toMatchObject({ integrity: "complete", requests: [{ url: "https://test/1", status: 202, superseded: true }] });
    const end = await diagnostics.requests(1, { offset: 8000, limit: 2 }) as any;
    expect(end).toMatchObject({ integrity: "complete", hasMore: false, requests: [{ url: "https://test/1" }, { url: "https://test/1" }] });
    expect(end.requests[0].requestRef).not.toBe(end.requests[1].requestRef);
    expect(await diagnostics.console(1, { limit: 1 })).toMatchObject({ integrity: "complete", messages: [{ text: "log 1" }] });
    expect((diagnostics as any).tabs.get(1).networkLatest.size).toBeLessThanOrEqual(1000);
  });
  it("retains the newest request index while trimming redirects and resets it on navigation", async () => {
    const { diagnostics } = harness();
    for (let index = 0; index < 1001; index++) diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", request(1));
    diagnostics.handle({ tabId: 1 }, "Network.responseReceived", { requestId: "1", response: { status: 204, headers: {} } });
    const state = (diagnostics as any).tabs.get(1);
    expect(state.networkLatest.size).toBe(1);
    expect(state.networkLatest.values().next().value).toMatchObject({ index: 1001, status: 204 });
    diagnostics.handle({ tabId: 1 }, "Page.frameNavigated", { frame: { id: "root" } });
    expect((diagnostics as any).tabs.get(1).networkLatest.size).toBe(0);
  });
  it("keeps identical request IDs in distinct frame sessions separate and clears only the active epoch", async () => {
    const { diagnostics } = harness();
    diagnostics.handle({ tabId: 1, sessionId: "frame-a" }, "Network.requestWillBeSent", request(1));
    diagnostics.handle({ tabId: 1, sessionId: "frame-b" }, "Network.requestWillBeSent", request(1));
    diagnostics.handle({ tabId: 1, sessionId: "frame-b" }, "Network.responseReceived", { requestId: "1", response: { status: 201, headers: { response: "b" } } });
    const [a, b] = (await diagnostics.requests(1, {}) as any).requests;
    expect(a.requestRef).not.toBe(b.requestRef);
    expect(await diagnostics.request(1, a.requestRef)).toMatchObject({ debuggee: { tabId: 1, sessionId: "frame-a" } });
    expect(await diagnostics.request(1, b.requestRef)).toMatchObject({ debuggee: { tabId: 1, sessionId: "frame-b" }, status: 201 });
    await expect(diagnostics.request(2, a.requestRef)).rejects.toMatchObject({ code: "stale-request" });
    diagnostics.handle({ tabId: 1, sessionId: "frame-a" }, "Page.frameNavigated", { frame: { id: "iframe-root" } });
    expect((await diagnostics.requests(1, {}) as any).requests).toHaveLength(2);
    diagnostics.handle({ tabId: 1 }, "Page.frameNavigated", { frame: { id: "root" } });
    expect((await diagnostics.requests(1, {}) as any).requests).toEqual([]);
  });
  it("paginates console output, honors severity, and leaves the raw argument objects in the log", async () => {
    const { diagnostics, logger, events } = harness();
    const params = { type: "warning", timestamp: 1, args: [{ value: "raw" }, { type: "object", description: "Object", objectId: "remote" }] };
    diagnostics.handle({ tabId: 1 }, "Runtime.consoleAPICalled", params);
    diagnostics.handle({ tabId: 1 }, "Log.entryAdded", { entry: { level: "error", text: "failure", timestamp: 2 } });
    expect(await diagnostics.console(1, { minLevel: "error", limit: 1 })).toEqual({ messages: [{ index: 2, level: "error", text: "failure", timestamp: 2 }], integrity: "complete", hasMore: false });
    await logger.flush();
    expect(events[0]?.output).toEqual(params);
  });

  it("reports incomplete console history without a logger while retaining the live tail", async () => {
    const diagnostics = new BrowserDiagnostics();
    for (let index = 1; index <= 1001; index++) diagnostics.handle({ tabId: 1 }, "Runtime.consoleAPICalled", message(`message ${index}`));
    const first = await diagnostics.console(1, { limit: 1 });
    expect(first).toMatchObject({ integrity: "incomplete", reason: "diagnostic-log-incomplete", hasMore: true, nextOffset: 1, messages: [{ index: 2, text: "message 2" }] });
    expect(await diagnostics.console(1, { offset: 1000 })).toMatchObject({ integrity: "incomplete", hasMore: null, messages: [] });
    await expect(diagnostics.console(1, { limit: 101 })).rejects.toThrow("limit");
  });

  it("reports log gaps and merges console messages that are still live", async () => {
    const { diagnostics, logger } = harness();
    for (let index = 1; index <= 1001; index++) diagnostics.handle({ tabId: 1 }, "Runtime.consoleAPICalled", message(`message ${index}`));
    await logger.flush();
    const original = logger.diagnosticEventsSnapshot.bind(logger);
    vi.spyOn(logger, "diagnosticEventsSnapshot").mockImplementation(async (conversation, capture) => {
      const snapshot = await original(conversation, capture);
      return { ...snapshot, value: snapshot.value.filter((event) => (event.content as any)?.revision !== 1001) };
    });
    expect(await diagnostics.console(1, { offset: 1000, limit: 2 })).toMatchObject({ integrity: "incomplete", reason: "diagnostic-log-incomplete", hasMore: null, messages: [{ index: 1001, text: "message 1001" }] });
  });

  it.each([false, true])("does not mix cleared messages into console replay when clear telemetry is missing=%s", async (omitClear) => {
    const { diagnostics, logger } = harness();
    diagnostics.handle({ tabId: 1 }, "Runtime.consoleAPICalled", message("old message"));
    await diagnostics.console(1, { clear: true });
    for (let index = 1; index <= 1001; index++) diagnostics.handle({ tabId: 1 }, "Runtime.consoleAPICalled", message(`new ${index}`));
    await logger.flush();
    const original = logger.diagnosticEventsSnapshot.bind(logger);
    if (omitClear) vi.spyOn(logger, "diagnosticEventsSnapshot").mockImplementation(async (conversation, capture) => {
      const snapshot = await original(conversation, capture);
      return { ...snapshot, value: snapshot.value.filter((event) => (event.content as any)?.method !== "console.clear") };
    });
    expect(await diagnostics.console(1, { limit: 1 })).toMatchObject({ integrity: omitClear ? "incomplete" : "complete", hasMore: true, messages: [{ index: 1, text: "new 1" }] });
  });

  it("deduplicates console replays and honors cancellation without canceling the other reader", async () => {
    const { diagnostics, logger } = harness();
    for (let index = 1; index <= 1001; index++) diagnostics.handle({ tabId: 1 }, "Runtime.consoleAPICalled", message(`message ${index}`));
    await logger.flush();
    const original = logger.diagnosticEventsSnapshot.bind(logger);
    let entered!: () => void; let release!: () => void;
    const started = new Promise<void>((resolve) => { entered = resolve; });
    const held = new Promise<void>((resolve) => { release = resolve; });
    const reads = vi.spyOn(logger, "diagnosticEventsSnapshot").mockImplementation(async (conversation, capture) => { entered(); await held; return original(conversation, capture); });
    const controller = new AbortController();
    const canceled = diagnostics.console(1, { limit: 1 }, controller.signal);
    await started;
    const other = diagnostics.console(1, { limit: 1 });
    controller.abort();
    await expect(canceled).rejects.toMatchObject({ name: "AbortError" });
    release();
    expect(await other).toMatchObject({ integrity: "complete", messages: [{ index: 1, text: "message 1" }] });
    expect(reads).toHaveBeenCalledOnce();
  });

  it("restarts console replay if it is cleared while the log read is in flight", async () => {
    const { diagnostics, logger } = harness();
    for (let index = 1; index <= 1001; index++) diagnostics.handle({ tabId: 1 }, "Runtime.consoleAPICalled", message(`old ${index}`));
    await logger.flush();
    const original = logger.diagnosticEventsSnapshot.bind(logger);
    let entered!: () => void; let release!: () => void;
    const started = new Promise<void>((resolve) => { entered = resolve; });
    const held = new Promise<void>((resolve) => { release = resolve; });
    let calls = 0;
    vi.spyOn(logger, "diagnosticEventsSnapshot").mockImplementation(async (conversation, capture) => {
      const snapshot = await original(conversation, capture);
      if (++calls === 1) { entered(); await held; }
      return snapshot;
    });
    const pending = diagnostics.console(1, { limit: 1 });
    await started;
    await diagnostics.console(1, { clear: true });
    for (let index = 1; index <= 1001; index++) diagnostics.handle({ tabId: 1 }, "Runtime.consoleAPICalled", message(`new ${index}`));
    release();
    expect(await pending).toMatchObject({ integrity: "complete", messages: [{ index: 1, text: "new 1" }] });
    expect(calls).toBeGreaterThanOrEqual(2);
  });

  it("invalidates cached console history after another logger clears the canonical log", async () => {
    const { diagnostics, logger, events } = harness();
    const other = new EventLogger({ store: { async append(event) { const saved = { ...event, id: events.length + 1 }; events.push(saved); return saved; }, async all() { return events; } } });
    for (let index = 1; index <= 1001; index++) diagnostics.handle({ tabId: 1 }, "Runtime.consoleAPICalled", message(`message ${index}`));
    await logger.flush();
    expect(await diagnostics.console(1, { limit: 1 })).toMatchObject({ integrity: "complete", messages: [{ index: 1 }] });
    await other.clear();
    expect(await diagnostics.console(1, { limit: 1 })).toMatchObject({ integrity: "incomplete", reason: "diagnostic-log-incomplete", messages: [{ index: 2 }] });
  });

  it("reports an unavailable console log rather than losing the live tail", async () => {
    const { diagnostics, logger } = harness();
    for (let index = 1; index <= 1001; index++) diagnostics.handle({ tabId: 1 }, "Runtime.consoleAPICalled", message(`message ${index}`));
    vi.spyOn(logger, "diagnosticEventsSnapshot").mockRejectedValue(new Error("log unavailable"));
    expect(await diagnostics.console(1, { limit: 1 })).toMatchObject({ integrity: "incomplete", reason: "diagnostic-log-unavailable", messages: [{ index: 2 }] });
  });

  it("separates console history by tab and conversation", async () => {
    const { diagnostics } = harness();
    diagnostics.handle({ tabId: 1 }, "Runtime.consoleAPICalled", message("tab one"));
    diagnostics.handle({ tabId: 2 }, "Runtime.consoleAPICalled", message("tab two"));
    expect(await diagnostics.console(1, {})).toMatchObject({ messages: [{ text: "tab one" }], integrity: "complete" });
    expect(await diagnostics.console(2, {})).toMatchObject({ messages: [{ text: "tab two" }], integrity: "complete" });
    diagnostics.bind({ conversationId: "other" });
    expect(await diagnostics.console(1, {})).toMatchObject({ messages: [], integrity: "complete" });
  });
  it("retains extra headers delivered before the request event in the originating frame session", async () => {
    const { diagnostics } = harness();
    diagnostics.handle({ tabId: 1, sessionId: "frame" }, "Network.requestWillBeSentExtraInfo", { requestId: "1", headers: { Cookie: "complete" } });
    diagnostics.handle({ tabId: 1, sessionId: "frame" }, "Network.responseReceivedExtraInfo", { requestId: "1", headers: { "Set-Cookie": "raw" } });
    diagnostics.handle({ tabId: 1, sessionId: "frame" }, "Network.requestWillBeSent", request(1));
    diagnostics.handle({ tabId: 1, sessionId: "frame" }, "Network.responseReceived", { requestId: "1", response: { status: 200, headers: { "content-type": "text/plain" } } });
    const [record] = (await diagnostics.requests(1, {}) as any).requests;
    expect(await diagnostics.request(1, record.requestRef)).toMatchObject({ requestHeaders: { Cookie: "complete" }, responseHeaders: { "Set-Cookie": "raw" } });
  });

  it("rejects a previous document's reference even when Chrome reuses request IDs and indexes", async () => {
    const { diagnostics } = harness();
    diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", request(1));
    const [before] = (await diagnostics.requests(1, {}) as any).requests;
    diagnostics.handle({ tabId: 1 }, "Page.frameNavigated", { frame: { id: "root" } });
    diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", { ...request(1), request: { method: "GET", url: "https://test/new", headers: {} } });
    const [after] = (await diagnostics.requests(1, {}) as any).requests;
    expect(after.requestRef).not.toBe(before.requestRef);
    await expect(diagnostics.request(1, before.requestRef)).rejects.toMatchObject({ code: "stale-request" });
    await expect(diagnostics.request(1, after.requestRef)).resolves.toMatchObject({ url: "https://test/new" });
  });

  it("gives redirects separate references and never exposes a later hop as the earlier body", async () => {
    const { diagnostics } = harness();
    diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", request(1));
    const [first] = (await diagnostics.requests(1, {}) as any).requests;
    diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", { ...request(1), request: { method: "GET", url: "https://test/final", headers: {} }, redirectResponse: { status: 302 } });
    const [old, next] = (await diagnostics.requests(1, {}) as any).requests;
    expect(old).toMatchObject({ requestRef: first.requestRef, superseded: true });
    expect(next.requestRef).not.toBe(first.requestRef);
    await expect(diagnostics.request(1, first.requestRef)).rejects.toMatchObject({ code: "stale-request" });
    await expect(diagnostics.request(1, next.requestRef)).resolves.toMatchObject({ url: "https://test/final" });
  });

  it("invalidates a detached frame or child session without invalidating unrelated sources", async () => {
    const { diagnostics } = harness();
    diagnostics.handle({ tabId: 1, sessionId: "a" }, "Network.requestWillBeSent", { ...request(1), frameId: "frame-a" });
    diagnostics.handle({ tabId: 1, sessionId: "b" }, "Network.requestWillBeSent", { ...request(1), frameId: "frame-b" });
    const [a, b] = (await diagnostics.requests(1, {}) as any).requests;
    diagnostics.handle({ tabId: 1 }, "Page.frameDetached", { frameId: "frame-a" });
    await expect(diagnostics.request(1, a.requestRef)).rejects.toMatchObject({ code: "stale-request" });
    await expect(diagnostics.request(1, b.requestRef)).resolves.toMatchObject({ debuggee: { sessionId: "b" } });
    diagnostics.handle({ tabId: 1 }, "Target.detachedFromTarget", { sessionId: "b" });
    await expect(diagnostics.request(1, b.requestRef)).rejects.toMatchObject({ code: "stale-request" });
  });

  it.each(["redirect", "detach"] as const)("does not return an evicted old request when %s happens during log replay", async (change) => {
    const { diagnostics, logger } = harness();
    diagnostics.handle({ tabId: 1, sessionId: "child" }, "Network.requestWillBeSent", request(1));
    const [first] = (await diagnostics.requests(1, {}) as any).requests;
    for (let index = 2; index <= 1001; index++) diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", request(index));
    await logger.flush();
    const original = logger.diagnosticEventsSnapshot.bind(logger);
    let entered!: () => void; let release!: () => void;
    const started = new Promise<void>((resolve) => { entered = resolve; });
    const held = new Promise<void>((resolve) => { release = resolve; });
    let calls = 0;
    vi.spyOn(logger, "diagnosticEventsSnapshot").mockImplementation(async (conversation) => {
      const events = await original(conversation);
      if (++calls === 1) { entered(); await held; }
      return events;
    });
    const pending = diagnostics.request(1, first.requestRef);
    await started;
    if (change === "redirect") diagnostics.handle({ tabId: 1, sessionId: "child" }, "Network.requestWillBeSent", { ...request(1), redirectResponse: { status: 302 } });
    else diagnostics.handle({ tabId: 1 }, "Target.detachedFromTarget", { sessionId: "child" });
    release();
    await expect(pending).rejects.toMatchObject({ code: "stale-request" });
    expect(calls).toBe(1); // Live invalidations reject the stale ref without replaying a moving log.
  });

  it.each(["redirect", "detach"] as const)("fails closed if the log omits an already observed %s", async (change) => {
    const { diagnostics, logger } = harness();
    diagnostics.handle({ tabId: 1, sessionId: "child" }, "Network.requestWillBeSent", request(1));
    const [first] = (await diagnostics.requests(1, {}) as any).requests;
    for (let index = 2; index <= 1001; index++) diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", request(index));
    await logger.flush();
    const oldEvents = await logger.diagnosticEventsSnapshot("conversation");
    if (change === "redirect") diagnostics.handle({ tabId: 1, sessionId: "child" }, "Network.requestWillBeSent", { ...request(1), redirectResponse: { status: 302 } });
    else diagnostics.handle({ tabId: 1 }, "Target.detachedFromTarget", { sessionId: "child" });
    // Diagnostic telemetry is best effort; it may not contain the latest
    // event. The live identity guard must reject an outdated reconstruction.
    vi.spyOn(logger, "diagnosticEventsSnapshot").mockResolvedValue(oldEvents);
    await expect(diagnostics.request(1, first.requestRef)).rejects.toMatchObject({ code: "stale-request" });
  });

  it("shares a cold log replay across concurrent requests and reuses bounded entries during unrelated traffic", async () => {
    const { diagnostics, logger } = harness();
    diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", request(1));
    const [first] = (await diagnostics.requests(1, {}) as any).requests;
    for (let index = 2; index <= 1001; index++) diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", request(index));
    await logger.flush();
    const reads = vi.spyOn(logger, "diagnosticEventsSnapshot");
    const [a, b] = await Promise.all([diagnostics.request(1, first.requestRef), diagnostics.request(1, first.requestRef)]);
    expect(a.requestRef).toBe(b.requestRef);
    expect(reads).toHaveBeenCalledTimes(1);
    diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", request(1002));
    await diagnostics.request(1, first.requestRef);
    expect(reads).toHaveBeenCalledTimes(1);
    await diagnostics.requests(1, { offset: 0, limit: 2 });
    await diagnostics.requests(1, { offset: 0, limit: 2 });
    expect(reads).toHaveBeenCalledTimes(2);
  });

  it("replays only newly committed capture events after a complete cached projection", async () => {
    const events: LogEvent[] = [];
    const queries: number[] = [];
    const logger = new EventLogger({ store: {
      async append(event) { const saved = { ...event, id: events.length + 1 }; events.push(saved); return saved; },
      async all() { return [...events]; },
      async latestByType(type) { return [...events].reverse().find((event) => event.type === type); },
      async byTypes(types, conversationId, afterId = -1) { return events.filter((event) => event.id > afterId && types.includes(event.type) && (!conversationId || event.conversationId === conversationId)); },
      async diagnosticsByCapture(conversationId, tabId, epoch, afterId) {
        queries.push(afterId);
        return events.filter((event) => event.id > afterId && event.type === "browser.diagnostic" && event.conversationId === conversationId && (event.content as any)?.tabId === tabId && (event.content as any)?.epoch === epoch);
      },
    } });
    const diagnostics = new BrowserDiagnostics(logger);
    diagnostics.bind({ conversationId: "conversation" });
    for (let index = 1; index <= 1001; index++) diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", request(index));
    const first = await diagnostics.requests(1, { limit: 1 }) as any;
    expect(first).toMatchObject({ integrity: "complete", requests: [{ url: "https://test/1" }] });
    diagnostics.handle({ tabId: 1 }, "Network.responseReceived", { requestId: "1", response: { status: 207, headers: {} } });
    diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", request(1002));
    const updated = await diagnostics.requests(1, { limit: 1 }) as any;
    expect(updated).toMatchObject({ integrity: "complete", requests: [{ url: "https://test/1", status: 207 }] });
    expect(queries).toEqual([-1, 1001]);
  });

  it("marks an indexed capture incomplete if an indexed event is missing", async () => {
    const events: LogEvent[] = [];
    const logger = new EventLogger({ store: {
      async append(event) { const saved = { ...event, id: events.length + 1 }; events.push(saved); return saved; },
      async all() { return [...events]; },
      async latestByType(type) { return [...events].reverse().find((event) => event.type === type); },
      async diagnosticsByCapture(conversationId, tabId, epoch, afterId) {
        return events.filter((event) => event.id > afterId && event.id !== 500 && event.type === "browser.diagnostic" && event.conversationId === conversationId && (event.content as any)?.tabId === tabId && (event.content as any)?.epoch === epoch);
      },
    } });
    const diagnostics = new BrowserDiagnostics(logger);
    diagnostics.bind({ conversationId: "conversation" });
    for (let index = 1; index <= 1001; index++) diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", request(index));
    expect(await diagnostics.requests(1, { limit: 1 })).toMatchObject({ integrity: "incomplete", reason: "diagnostic-log-incomplete" });
  });

  it("does not retain a replay projection with oversized request bodies", async () => {
    const { diagnostics, logger } = harness();
    diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", { ...request(1), request: { ...request(1).request, postData: "x".repeat(3 * 1024 * 1024) } });
    for (let index = 2; index <= 1001; index++) diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", request(index));
    const reads = vi.spyOn(logger, "diagnosticEventsSnapshot");
    await diagnostics.requests(1, { limit: 1 });
    diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", request(1002));
    await diagnostics.requests(1, { limit: 1 });
    expect(reads).toHaveBeenCalledTimes(2);
    expect(reads.mock.calls[1]?.[1]?.afterId).toBeUndefined();
  });

  it("cancels a waiting historical replay without cancelling shared work", async () => {
    const { diagnostics, logger } = harness();
    diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", request(1));
    const [first] = (await diagnostics.requests(1, {}) as any).requests;
    for (let index = 2; index <= 1001; index++) diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", request(index));
    await logger.flush();
    const original = logger.diagnosticEventsSnapshot.bind(logger);
    let entered!: () => void; let release!: () => void;
    const started = new Promise<void>((resolve) => { entered = resolve; });
    const held = new Promise<void>((resolve) => { release = resolve; });
    const reads = vi.spyOn(logger, "diagnosticEventsSnapshot").mockImplementation(async (conversation) => { entered(); await held; return original(conversation); });
    const controller = new AbortController();
    const cancelled = diagnostics.request(1, first.requestRef, controller.signal);
    await started;
    const other = diagnostics.request(1, first.requestRef);
    controller.abort();
    await expect(cancelled).rejects.toMatchObject({ name: "AbortError" });
    release();
    await expect(other).resolves.toMatchObject({ requestRef: first.requestRef });
    expect(reads).toHaveBeenCalledOnce();
  });

  it.each(["missing", "reordered", "duplicate"] as const)("reports %s replay events without claiming full history", async (problem) => {
    const { diagnostics, logger } = harness();
    for (let index = 1; index <= 1001; index++) diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", request(index));
    await logger.flush();
    const original = logger.diagnosticEventsSnapshot.bind(logger);
    vi.spyOn(logger, "diagnosticEventsSnapshot").mockImplementation(async (conversation) => {
      const snapshot = await original(conversation), events = [...snapshot.value];
      if (problem === "missing") events.splice(20, 1);
      else if (problem === "reordered") [events[20], events[21]] = [events[21]!, events[20]!];
      else events.splice(21, 0, events[20]!);
      return { ...snapshot, value: events };
    });
    const first = await diagnostics.requests(1, { limit: 2 }) as any;
    expect(first).toMatchObject({ integrity: "incomplete", reason: "diagnostic-log-incomplete", hasMore: true, nextOffset: 2 });
    const end = await diagnostics.requests(1, { offset: 5000, limit: 2 }) as any;
    expect(end).toMatchObject({ requests: [], integrity: "incomplete", hasMore: null });
    expect(end).not.toHaveProperty("nextOffset");
  });

  it("keeps the known live tail if its diagnostic events were dropped", async () => {
    const { diagnostics, logger } = harness();
    for (let index = 1; index <= 1001; index++) diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", request(index));
    await logger.flush();
    const original = logger.diagnosticEventsSnapshot.bind(logger);
    vi.spyOn(logger, "diagnosticEventsSnapshot").mockImplementation(async (conversation) => {
      const snapshot = await original(conversation);
      return { ...snapshot, value: snapshot.value.filter((event) => (event.content as any)?.revision !== 1001) };
    });
    const page = await diagnostics.requests(1, { offset: 1000, limit: 2 }) as any;
    expect(page).toMatchObject({ integrity: "incomplete", hasMore: null, requests: [{ url: "https://test/1001" }] });
  });

  it("invalidates cached historical pages after another logger clears the canonical log", async () => {
    const { diagnostics, logger, events } = harness();
    const other = new EventLogger({ store: {
      async append(event) { const saved = { ...event, id: events.length + 1 }; events.push(saved); return saved; },
      async all() { return events; }, async clear() { events.splice(0); },
    } });
    for (let index = 1; index <= 1001; index++) diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", request(index));
    await logger.flush();
    const before = await diagnostics.requests(1, { limit: 1 }) as any;
    expect(before).toMatchObject({ integrity: "complete", requests: [{ url: "https://test/1" }] });
    await other.clear();
    const after = await diagnostics.requests(1, { limit: 1 }) as any;
    expect(after).toMatchObject({ integrity: "incomplete", reason: "diagnostic-log-incomplete", requests: [{ url: "https://test/2" }] });
  });

  it("includes console.clear in replay ordering and isolates conversation/run ownership", async () => {
    const { diagnostics, logger } = harness();
    diagnostics.bind({ conversationId: "conversation", logIdentity: { runId: "one", toolCallId: "call", toolCallIdCanonical: true } });
    for (let index = 1; index <= 500; index++) diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", request(index));
    await diagnostics.console(1, { clear: true });
    for (let index = 501; index <= 1001; index++) diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", request(index));
    await logger.flush();
    const page = await diagnostics.requests(1, { limit: 1 }) as any;
    expect(page).toMatchObject({ integrity: "complete", requests: [{ url: "https://test/1" }] });
    diagnostics.bind({ conversationId: "conversation", logIdentity: { runId: "two", toolCallId: "call", toolCallIdCanonical: true } });
    await expect(diagnostics.request(1, page.requests[0].requestRef)).rejects.toMatchObject({ code: "stale-request" });
    expect(await diagnostics.requests(1, {})).toMatchObject({ requests: [], integrity: "complete", hasMore: false });
    diagnostics.bind({ conversationId: "other", logIdentity: { runId: "two", toolCallId: "call", toolCallIdCanonical: true } });
    expect(await diagnostics.requests(1, {})).toMatchObject({ requests: [], integrity: "complete", hasMore: false });
  });

  it("does not mistake other tabs' interleaved events for a gap in this tab's capture", async () => {
    const { diagnostics, logger } = harness();
    for (let index = 1; index <= 1001; index++) {
      diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", request(index));
      if (index % 20 === 0) diagnostics.handle({ tabId: 2 }, "Network.requestWillBeSent", request(index));
    }
    await logger.flush();
    expect(await diagnostics.requests(1, { limit: 1 })).toMatchObject({ integrity: "complete", requests: [{ url: "https://test/1" }] });
  });

  it("reports unavailable historical telemetry and keeps live results", async () => {
    const { diagnostics, logger } = harness();
    for (let index = 1; index <= 1001; index++) diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", request(index));
    vi.spyOn(logger, "diagnosticEventsSnapshot").mockRejectedValue(new Error("storage unavailable"));
    expect(await diagnostics.requests(1, { offset: 1000 })).toMatchObject({ requests: [], integrity: "incomplete", reason: "diagnostic-log-unavailable", hasMore: null });
    expect((await diagnostics.requests(1, { limit: 1 }) as any).requests[0].url).toBe("https://test/2");
    await expect(diagnostics.requests(1, { limit: 101 })).rejects.toThrow("limit");
  });
});

 it("returns a fixed diagnostic prefix under uninterrupted traffic and reuses pages across WebSocket frames", async () => {
    const { diagnostics, logger } = harness();
    for (let index = 1; index <= 1001; index++) diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", request(index));
    await logger.flush();
    const original = logger.diagnosticEventsSnapshot.bind(logger);
    const reads = vi.spyOn(logger, "diagnosticEventsSnapshot").mockImplementation(async (...args) => {
      const snapshot = await original(...args);
      diagnostics.handle({ tabId: 1 }, "Network.webSocketFrameReceived", { requestId: "socket", response: { payloadData: "tick" } });
      diagnostics.handle({ tabId: 1 }, "Network.requestWillBeSent", request(1002));
      return snapshot;
    });
    expect(await diagnostics.requests(1, {limit:1}, AbortSignal.timeout(1000)))
      .toMatchObject({integrity:"complete",requests:[{url:"https://test/1"}]});
    expect(reads).toHaveBeenCalledOnce();
    reads.mockImplementation(original);
    await diagnostics.requests(1, {limit:1});
    const count=reads.mock.calls.length;
    for(let i=0;i<50;i++) diagnostics.handle({tabId:1}, "Network.webSocketFrameReceived", {requestId:"socket",response:{payloadData:String(i)}});
    await diagnostics.requests(1, {limit:1});
    expect(reads).toHaveBeenCalledTimes(count);
  });

it("shares a pending replay when only WebSocket traffic separates concurrent readers", async () => {
  const { diagnostics, logger } = harness();
  for (let i=1;i<=1001;i++) diagnostics.handle({tabId:1},"Network.requestWillBeSent",request(i));
  await logger.flush();
  const original=logger.diagnosticEventsSnapshot.bind(logger);
  let release!:()=>void, entered!:()=>void;
  const held=new Promise<void>(resolve=>release=resolve), started=new Promise<void>(resolve=>entered=resolve);
  const reads=vi.spyOn(logger,"diagnosticEventsSnapshot").mockImplementation(async(...args)=>{const value=await original(...args);entered();await held;return value});
  const first=diagnostics.requests(1,{limit:1});await started;
  diagnostics.handle({tabId:1},"Network.webSocketFrameReceived",{requestId:"socket",response:{payloadData:"tick"}});
  const second=diagnostics.requests(1,{limit:1});release();
  expect(await first).toEqual(await second);expect(reads).toHaveBeenCalledOnce();
});

it("refreshes only the requested history entry when its response arrives during replay", async () => {
  const { diagnostics, logger } = harness();
  diagnostics.handle({tabId:1},"Network.requestWillBeSent",request(1));
  const first=(await diagnostics.requests(1,{limit:1}) as any).requests[0];
  for(let i=2;i<=1001;i++)diagnostics.handle({tabId:1},"Network.requestWillBeSent",request(i));
  await logger.flush();
  const original=logger.diagnosticEventsSnapshot.bind(logger);let reads=0;
  vi.spyOn(logger,"diagnosticEventsSnapshot").mockImplementation(async(...args)=>{
    const value=await original(...args);
    if(++reads===1)diagnostics.handle({tabId:1},"Network.responseReceived",{requestId:"1",response:{status:201,headers:{"x-result":"created"}}});
    return value;
  });
  expect(await diagnostics.request(1,first.requestRef)).toMatchObject({status:201,responseHeaders:{"x-result":"created"}});
  expect(reads).toBe(2);
});

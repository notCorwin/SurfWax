import { describe, expect, it } from "vitest";
import { evaluateResultEvidence, lastAgentResponse, type ResultEvidenceInput } from "../../e2e/evaluation/result-evidence";

const complete = (): ResultEvidenceInput => ({
  outcome: "conversation.finished", networkSettled: true, ledgerDrained: true, logComplete: true,
  jobsSettled: true, business: true, interaction: { applicable: true, verified: true }, lifecycle: true,
});

describe("evaluation result evidence", () => {
  it("passes only with a finished conversation and all applicable evidence", () => {
    expect(evaluateResultEvidence(complete())).toEqual({ classification: "passed", passed: true, businessVerified: true,
      interactionApplicable: true, interactionVerified: true, lifecycleVerified: true, jobsSettled: true, reasons: [] });
    expect(evaluateResultEvidence({ ...complete(), interaction: { applicable: false } })).toMatchObject({
      classification: "passed", interactionApplicable: false, interactionVerified: null,
    });
  });

  it("distinguishes a real business, interaction or lifecycle mismatch", () => {
    expect(evaluateResultEvidence({ ...complete(), business: false })).toMatchObject({
      classification: "failed", passed: false, businessVerified: false, reasons: ["business_incorrect"],
    });
    expect(evaluateResultEvidence({ ...complete(), interaction: { applicable: true, verified: false } })).toMatchObject({
      classification: "failed", interactionVerified: false, reasons: ["interaction_incorrect"],
    });
    expect(evaluateResultEvidence({ ...complete(), lifecycle: false })).toMatchObject({
      classification: "failed", lifecycleVerified: false, reasons: ["lifecycle_invalid"],
    });
  });

  it("does not turn an unsettled network or undrained ledger into a business failure or success", () => {
    for (const networkSettled of [false, null] as const) {
      for (const business of [true, false] as const) {
        expect(evaluateResultEvidence({ ...complete(), networkSettled, business })).toMatchObject({
          classification: "unknown", passed: false, businessVerified: null, interactionVerified: null,
        });
      }
    }
    expect(evaluateResultEvidence({ ...complete(), ledgerDrained: false, business: false })).toMatchObject({
      classification: "unknown", businessVerified: null, reasons: expect.arrayContaining(["ledger_unavailable", "business_unknown"]),
    });
  });

  it("distinguishes inapplicable interaction from applicable but unavailable interaction", () => {
    expect(evaluateResultEvidence({ ...complete(), interaction: { applicable: true, verified: null } })).toMatchObject({
      classification: "unknown", interactionApplicable: true, interactionVerified: null, reasons: ["interaction_unknown"],
    });
    expect(evaluateResultEvidence({ ...complete(), interaction: { applicable: false } })).toMatchObject({
      classification: "passed", interactionApplicable: false, interactionVerified: null,
    });
  });

  it("keeps lifecycle unknown if the canonical log is incomplete", () => {
    expect(evaluateResultEvidence({ ...complete(), logComplete: false, lifecycle: false })).toMatchObject({
      classification: "unknown", lifecycleVerified: null, jobsSettled: null, reasons: ["lifecycle_unknown", "jobs_unknown"],
    });
    expect(evaluateResultEvidence({ ...complete(), lifecycle: null })).toMatchObject({
      classification: "unknown", lifecycleVerified: null, reasons: ["lifecycle_unknown"],
    });
  });

  it("keeps every unfinished run unknown, even if no business action or tool was observed", () => {
    for (const outcome of ["setup_failed", "running", "timed_out", "unexpected"]) {
      expect(evaluateResultEvidence({ ...complete(), outcome })).toMatchObject({
        classification: "unknown", passed: false, reasons: ["conversation_outcome_unknown"],
      });
    }
    for (const outcome of ["conversation.failed", "conversation.aborted"]) {
      expect(evaluateResultEvidence({ ...complete(), outcome, business: false, lifecycle: false })).toMatchObject({
        classification: "unknown", passed: false, businessVerified: false, lifecycleVerified: false,
        reasons: ["conversation_not_finished", "business_incorrect", "lifecycle_invalid"],
      });
    }
    expect(evaluateResultEvidence({ ...complete(), outcome: "setup_failed", networkSettled: null, ledgerDrained: false,
      logComplete: false, business: false, interaction: { applicable: true, verified: false }, lifecycle: false })).toMatchObject({
      classification: "unknown", passed: false, businessVerified: null, interactionVerified: null, lifecycleVerified: null,
      reasons: ["conversation_outcome_unknown", "network_unknown", "ledger_unavailable", "business_unknown", "interaction_unknown", "lifecycle_unknown", "jobs_unknown"],
    });
  });

  it("keeps unfinished or unknown jobs unknown while retaining observed errors", () => {
    expect(evaluateResultEvidence({ ...complete(), jobsSettled: false, business: false })).toMatchObject({
      classification: "unknown", businessVerified: false, jobsSettled: false, reasons: ["business_incorrect", "jobs_unsettled"],
    });
    expect(evaluateResultEvidence({ ...complete(), jobsSettled: null })).toMatchObject({
      classification: "unknown", jobsSettled: null, reasons: ["jobs_unknown"],
    });
    expect(evaluateResultEvidence({ ...complete(), business: false, logComplete: false })).toMatchObject({
      classification: "unknown", businessVerified: false, lifecycleVerified: null, jobsSettled: null,
      reasons: ["business_incorrect", "lifecycle_unknown", "jobs_unknown"],
    });
  });

  it("describes the last observed agent response without inferring a cause", () => {
    expect(lastAgentResponse([])).toBeNull();
    expect(lastAgentResponse([{ kind: "agent", responseStatus: 429, responseComplete: true },
      { kind: "agent", responseStatus: 200, responseComplete: true },
      { kind: "auxiliary", responseStatus: 500, responseComplete: true }])).toEqual({ status: 200, complete: true });
    expect(lastAgentResponse([{ kind: "agent", responseStatus: null, responseComplete: false }])).toEqual({ status: null, complete: false });
    expect(() => lastAgentResponse([{ kind: "agent", responseStatus: "429", responseComplete: true }])).toThrow();
  });
});

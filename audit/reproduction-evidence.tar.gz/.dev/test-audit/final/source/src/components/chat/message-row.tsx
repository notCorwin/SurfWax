import { CopyIcon, PencilIcon } from "lucide-react";
import { memo, useEffect, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Bubble, BubbleContent } from "@/components/ui/bubble";
import { Message, MessageContent, MessageFooter } from "@/components/ui/message";
import { Textarea } from "@/components/ui/textarea";
import { ErrorNotice } from "@/components/ui/error-notice";
import { MarkdownText } from "./markdown-text";
import { ActivityPhaseContext, activityPhaseAt, turnActivityBoundary, turnActivityPhase } from "./process-group";
import { ToolGroupView, toolGroupAt, type ToolTimeline } from "./tool-timeline";

import { useRuntimeView, type MessageView } from "@/sidepanel/runtime-view";
export type { MessageView } from "@/sidepanel/runtime-view";
type RowProps = { message: MessageView; messages: readonly MessageView[]; running: boolean; locked: boolean;
  command: (action: () => void | Promise<unknown>) => void; latest: boolean; timeline: ToolTimeline };
export const MessageRow = memo(function MessageRow({ message, messages, running, locked, command, latest, timeline }: RowProps) {
  const runtime = useRuntimeView();
  const client = () => runtime.thread.getMessageById(message.id);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState("");
  const bubble = useRef<HTMLDivElement>(null);
  const [editSize, setEditSize] = useState({ width: 0, height: 0 });
  const [copied, setCopied] = useState(false);
  const [copyError, setCopyError] = useState<unknown>();
  const copyTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  useEffect(() => () => clearTimeout(copyTimer.current), []);
  const copy = async () => {
    try { await navigator.clipboard.writeText(client().getCopyText()); setCopied(true); setCopyError(undefined);
      clearTimeout(copyTimer.current); copyTimer.current = setTimeout(() => setCopied(false), 1500);
    } catch (error) { setCopyError(error); }
  };
  const user = message.role === "user";
  const parts = message.parts;
  const boundary = turnActivityBoundary(messages, message.id);
  const phase = turnActivityPhase(messages, message.id, running);
  const renderParts = () => {
    const output = [];
    for (const [index, part] of parts.entries()) {
      if (part.type === "text") {
        output.push(user ? <p key={index} className="whitespace-pre-wrap wrap-break-word">{part.text}</p> : <MarkdownText key={index} text={part.text} />);
      } else {
        const group = toolGroupAt(timeline, message.id, index);
        if (group) output.push(<ActivityPhaseContext.Provider key={index} value={!group.live && phase !== "pending" ? phase : activityPhaseAt(boundary, index, phase, part.status.type)}><ToolGroupView group={group} /></ActivityPhaseContext.Provider>);
      }
    }
    return output;
  };
  const actions = useMemo(() => user && !running && !locked && <MessageFooter className="gap-1 px-0 justify-end">
    <Button type="button" variant="ghost" size="icon-xs" aria-label={copied ? "已复制" : "复制消息"} title="复制消息" onClick={() => void copy()}><CopyIcon aria-hidden="true" /></Button>
    {user && !editing && <Button type="button" variant="ghost" size="icon-xs" disabled={locked} data-testid="edit-message-button" aria-label="编辑消息" title="编辑消息"
      onClick={() => command(() => { const rect = bubble.current!.getBoundingClientRect(); setEditSize({ width: rect.width, height: rect.height }); setDraft(client().getCopyText()); setEditing(true); })}><PencilIcon aria-hidden="true" /></Button>}
  </MessageFooter>, [runtime, user, message.id, copied, editing, running, locked, command]);
  const hasVisiblePart = parts.some((part, index) => part.type !== "text" ? Boolean(toolGroupAt(timeline, message.id, index)) : Boolean(part.text.trim()));
  if (!user && !hasVisiblePart && message.metadata.custom?.interrupted !== true
    && !(message.status?.type === "incomplete" && message.status.reason === "error")) return null;
  return <Message data-role={message.role} align={user ? "end" : "start"} aria-live={latest && !user ? "polite" : undefined} className={user ? "user-message" : "assistant-message px-2"}>
    <MessageContent className={user ? "items-end" : "assistant-message-content"}>
      {user ? <form className="flex w-full min-w-0 flex-col items-end gap-1" onSubmit={(event) => event.preventDefault()}>
        <Bubble variant="muted" align="end" className="max-w-[94%]" style={editing ? { width: editSize.width } : undefined}><BubbleContent ref={bubble} data-testid="user-message-bubble" className={`border-border/70 ${editing ? "w-full" : ""}`}>
          {editing ? <Textarea autoFocus data-testid="edit-message-input" aria-label="编辑消息" value={draft} disabled={locked}
            style={{ height: Math.min(128, Math.max(22, editSize.height - 16)) }}
            onChange={(event) => { setDraft(event.target.value); event.currentTarget.style.height = "auto"; event.currentTarget.style.height = `${Math.min(128, event.currentTarget.scrollHeight)}px`; }}
            className="max-h-32 min-h-0 resize-none rounded-none border-0 bg-transparent p-0 text-sm leading-relaxed shadow-none dark:bg-transparent" /> : renderParts()}
        </BubbleContent></Bubble>
        {editing && <div className="flex justify-end gap-1">
          <Button type="button" size="sm" variant="ghost" onClick={() => setEditing(false)}>取消</Button>
          <Button type="button" size="sm" disabled={locked || !draft.trim()} onClick={() => command(() => {
            const result = runtime.thread.edit(message.id, draft); setEditing(false); return result;
          })}>保存并重新生成</Button>
        </div>}
      </form> : renderParts()}
      {!user && message.metadata.custom?.interrupted === true && <div className="interrupted-message" data-testid="interrupted-message">
        <span>回复已中断</span>
      </div>}
      {message.status?.type === "incomplete" && message.status.reason === "error" && <ErrorNotice summary="模型请求失败。" error={message.status.error} />}
      {copyError !== undefined && <ErrorNotice summary="复制失败。" error={copyError} />}
      {actions}
    </MessageContent>
  </Message>;
}, (before, after) => before.message === after.message
  // A new response snapshot changes the turn array, but settled tool/user rows
  // need another render only when their derived activity state changes.
  && (before.messages === after.messages
    || turnActivityBoundary(before.messages, before.message.id) === turnActivityBoundary(after.messages, after.message.id)
      && turnActivityPhase(before.messages, before.message.id, before.running) === turnActivityPhase(after.messages, after.message.id, after.running))
  && before.running === after.running && before.locked === after.locked && before.command === after.command
  && before.latest === after.latest && before.timeline === after.timeline);

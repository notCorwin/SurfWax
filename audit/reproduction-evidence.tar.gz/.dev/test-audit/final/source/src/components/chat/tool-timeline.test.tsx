import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import type { MessagePart, MessageView } from "@/sidepanel/conversation-store";
import { RuntimeViewContext, type RuntimeView } from "@/sidepanel/runtime-view";
import { MessageRow } from "./message-row";
import { projectToolTimeline, withWaitingActivity, toolGroupAt, toolGroupDuration, ToolGroupView } from "./tool-timeline";

type Tool = Extract<MessagePart, { type: "tool-call" }>;
const tool = (id: string, start = 0, end = 100): Tool => ({
  type: "tool-call", toolName: "inspect_pages", toolCallId: id, args: {}, status: { type: "complete" }, startedAtMs: start, finishedAtMs: end,
});
const text = (value: string): MessagePart => ({ type: "text", text: value, status: { type: "complete" } });
const reasoning = (value: string): Extract<MessagePart, { text: string }> => ({ type: "reasoning", text: value, status: { type: "complete" } });
const message = (id: string, parts: MessagePart[]) => ({ id, role: "assistant", parts, metadata: {}, status: { type: "complete" }, branchCount: 1, branchNumber: 1 }) as unknown as MessageView;

describe("tool timeline", () => {
  it("groups reasoning and tools across messages until visible assistant text", () => {
    const messages = [message("a", [reasoning("first thought"), tool("1")]),
      message("b", [reasoning("second thought"), tool("2"), reasoning("third thought")]),
      message("c", [text("VISIBLE ANSWER"), reasoning("later thought"), tool("3")])];
    const timeline = projectToolTimeline(messages, false);
    const first = toolGroupAt(timeline, "a", 0)!;
    const second = toolGroupAt(timeline, "c", 1)!;
    expect(first.reasoning.map((part) => part.text)).toEqual(["first thought", "second thought", "third thought"]);
    expect(first.tools.map((part) => part.toolCallId)).toEqual(["1", "2"]);
    expect(toolGroupAt(timeline, "b", 0)).toBeUndefined();
    expect(second.reasoning.map((part) => part.text)).toEqual(["later thought"]);
    expect(second.tools.map((part) => part.toolCallId)).toEqual(["3"]);
    const runtime = { thread: { getMessageById: () => ({ getCopyText: () => "" }) } } as unknown as RuntimeView["runtime"];
    const html = renderToStaticMarkup(createElement(RuntimeViewContext.Provider, { value: { runtime, thread: runtime.thread, getState: runtime.thread.getState } },
      messages.map((item) => createElement(MessageRow, { key: item.id, message: item, messages, running: false, locked: false,
        latest: item.id === "c", timeline, command: () => {} }))));
    expect(html).not.toContain('data-testid="reasoning-item"');
    const host = document.createElement("div");
    host.innerHTML = html;
    expect(host.textContent?.match(/思考完成/g)).toHaveLength(2);
    expect(html).not.toContain("回复未生成");
    expect(html.match(/data-testid="tool-group-summary"/g)).toHaveLength(2);
    expect(html).not.toContain("first thought");
    expect(html).not.toContain("second thought");
    expect(html).not.toContain("third thought");
    expect(html.indexOf('data-testid="tool-group-summary"')).toBeLessThan(html.indexOf("VISIBLE ANSWER"));
    expect(html.lastIndexOf('data-testid="tool-group-summary"')).toBeGreaterThan(html.indexOf("VISIBLE ANSWER"));
  });

  it("merges settled reasoning and tools into one row with elapsed time, including overlapping responses only once", () => {
    const messages = [message("merged", [
      { ...reasoning("plan"), responseTimeMs: 2000, responseTimingId: 1, startedAtMs: 1000, finishedAtMs: 3000 },
      tool("first", 3000, 5000),
      { ...reasoning("next"), responseTimeMs: 2000, responseTimingId: 2, startedAtMs: 5000, finishedAtMs: 7000 },
      { ...reasoning("same response"), responseTimeMs: 2000, responseTimingId: 2, startedAtMs: 5000, finishedAtMs: 7000 },
      tool("second", 7000, 8000),
    ])];
    const group = toolGroupAt(projectToolTimeline(messages, false), "merged", 0)!;
    const host = document.createElement("div");
    host.innerHTML = renderToStaticMarkup(createElement(ToolGroupView, { group }));
    expect(host.querySelectorAll(".transcript-activity")).toHaveLength(1);
    expect(host.textContent).toBe("思考完成、查看页面 · 7.00 秒");
    expect(host.querySelector('[data-testid="reasoning-item"]')).toBeNull();
    const unknown = { ...group, reasoning: [reasoning("unknown")] };
    expect(renderToStaticMarkup(createElement(ToolGroupView, { group: unknown }))).not.toContain(" 秒");
    const failed = { ...group, reasoning: [{ ...group.reasoning[0]!, status: { type: "incomplete" as const } }] };
    const failedHtml = renderToStaticMarkup(createElement(ToolGroupView, { group: failed }));
    expect(failedHtml).toContain("思考未完成、查看页面");
    expect(failedHtml).toContain('data-status="error"');
  });

  it("shows response time per live reasoning and deduplicates the settled total", () => {
    const parts = [
      { ...reasoning("first"), responseTimeMs: 1234, responseTimingId: 1 },
      { ...reasoning("same response"), responseTimeMs: 1234, responseTimingId: 1 },
      { ...reasoning("next response"), responseTimeMs: 3250, responseTimingId: 2 },
    ];
    const messages = [message("timed", parts)];
    const live = toolGroupAt(projectToolTimeline(messages, true), "timed", 0)!;
    const liveHtml = renderToStaticMarkup(createElement(ToolGroupView, { group: live }));
    expect(liveHtml.match(/1.23 秒/g)).toHaveLength(2);
    expect(liveHtml).toContain("3.25 秒");
    const settled = toolGroupAt(projectToolTimeline(messages, false), "timed", 0)!;
    expect(renderToStaticMarkup(createElement(ToolGroupView, { group: settled }))).toContain("4.48 秒");
    expect(liveHtml).toContain("模型响应总耗时");
  });

  it("keeps incomplete historical reasoning distinct from an unfinished final activity", () => {
    const incomplete: MessagePart = { type: "reasoning", text: "partial", status: { type: "incomplete" } };
    const messages = [message("a", [incomplete, text("answer"), incomplete])];
    const timeline = projectToolTimeline(messages, false);
    const runtime = { thread: { getMessageById: () => ({ getCopyText: () => "" }) } } as unknown as RuntimeView["runtime"];
    const html = renderToStaticMarkup(createElement(RuntimeViewContext.Provider, { value: { runtime, thread: runtime.thread, getState: runtime.thread.getState } },
      createElement(MessageRow, { message: messages[0]!, messages, running: false, locked: false, latest: true, timeline, command: () => {} })));
    expect(html.indexOf("思考未完成")).toBeLessThan(html.indexOf("answer"));
    expect(html.indexOf("回复未生成")).toBeGreaterThan(html.indexOf("answer"));
  });

  it("keeps all reasoning, waiting and tools in order", () => {
    const messages = [message("a", [reasoning("first"), tool("1"), reasoning("second"), tool("2")])];
    const waiting = { afterId: "2", id: "waiting:request", label: "正在等待推理提供商响应" };
    const projected = withWaitingActivity(projectToolTimeline(messages, true), [waiting]);
    const group = projected.trailing!;
    const html = renderToStaticMarkup(createElement(ToolGroupView, { group }));
    expect(html.match(/data-tool-id=/g)).toHaveLength(5);
    expect(html).toContain('data-tool-id="1"');
    expect(html).not.toContain("first");
    expect(html).toContain("思考完成");
    expect(html).toContain('data-tool-id="2"');
    expect(html).toContain('data-tool-id="waiting:request"');
    expect(html).toContain('data-testid="waiting-status"');
    expect(withWaitingActivity(projectToolTimeline([message("b", [text("answer")])], true), [waiting]).trailing?.waiting).toEqual([waiting]);
    expect(projected.timeline.starts.size).toBe(0);
    const separated = withWaitingActivity(projectToolTimeline([message("split", [tool("1"), text("answer"), tool("2")])], true), [{ ...waiting, afterId: "1", endedAt: 1000 }]);
    expect(separated.trailing?.waiting).toEqual([]);
    expect(toolGroupAt(separated.timeline, "split", 0)?.waiting).toHaveLength(1);

    const completed = { ...waiting, afterId: "1", endedAt: 1000 };
    const next = withWaitingActivity(projectToolTimeline(messages, true), [completed]);
    const historyHtml = renderToStaticMarkup(createElement(ToolGroupView, { group: next.trailing! }));
    expect(historyHtml.match(/data-tool-id=/g)).toHaveLength(5);
    expect(historyHtml.indexOf('data-tool-id="waiting:request"')).toBeLessThan(historyHtml.lastIndexOf("思考完成"));
    expect(historyHtml.lastIndexOf("思考完成")).toBeLessThan(historyHtml.indexOf('data-tool-id="2"'));

    const waits = [
      { ...waiting, id: "unanchored-first", afterId: undefined },
      { ...waiting, id: "unanchored-second", afterId: "missing" },
      { ...waiting, id: "anchored-first", afterId: "1" },
      { ...waiting, id: "anchored-second", afterId: "1" },
    ];
    const ordered = renderToStaticMarkup(createElement(ToolGroupView, { group: { ...group, waiting: waits } }));
    const host = document.createElement("div");
    host.innerHTML = ordered;
    const ids = Array.from(host.querySelectorAll<HTMLElement>("[data-tool-id]"), (row) => row.dataset.toolId);
    expect(ids).toEqual(["unanchored-first", "unanchored-second", group.activities[0]!.id, "1", "anchored-first", "anchored-second", group.activities[2]!.id, "2"]);

  });

  it("keeps tool groups in place, spanning assistant messages until visible text breaks the sequence", () => {
    const messages = [message("a", [text("first"), tool("1"), tool("2")]), message("b", [text(" "), tool("3"), text("next"), tool("4")])];
    const projected = projectToolTimeline(messages, true);
    const first = toolGroupAt(projected, "a", 1)!;
    const second = toolGroupAt(projected, "b", 3)!;
    expect(first.tools.map((item) => item.toolCallId)).toEqual(["1", "2", "3"]);
    expect(first.live).toBe(false);
    expect(toolGroupAt(projected, "b", 1)).toBeUndefined();
    expect(second.tools.map((item) => item.toolCallId)).toEqual(["4"]);
    expect(second.live).toBe(true);
    expect(projectToolTimeline(messages, false).starts.size).toBe(2);
    expect(toolGroupAt(projectToolTimeline(messages, false), "b", 3)?.live).toBe(false);
    expect(projectToolTimeline(messages, true)).toBe(projected);
  });

  it("shows every activity during a running sequence and a single non-expandable summary after it ends", () => {
    const messages = [message("a", [tool("1"), tool("2"), tool("3"), tool("4")])];
    const live = toolGroupAt(projectToolTimeline(messages, true), "a", 0)!;
    const liveHtml = renderToStaticMarkup(createElement(ToolGroupView, { group: live }));
    expect(liveHtml.match(/class="activity transcript-activity"/g)).toHaveLength(4);
    const settled = toolGroupAt(projectToolTimeline(messages, false), "a", 0)!;
    const settledHtml = renderToStaticMarkup(createElement(ToolGroupView, { group: settled }));
    expect(settledHtml).toContain("tool-group-summary");
    expect(settledHtml).not.toContain("<details");
  });

  it("keeps a call visible if later text arrived before that call finished", () => {
    const pending: Tool = { ...tool("pending"), status: { type: "running" }, finishedAtMs: undefined };
    const messages = [message("a", [pending, text("later text")])];
    expect(toolGroupAt(projectToolTimeline(messages, true), "a", 0)?.live).toBe(true);
    expect(toolGroupAt(projectToolTimeline([message("a", [tool("done"), text("later text")])], true), "a", 0)?.live).toBe(false);
  });

  it("shows individual live failures and summarizes them after the sequence ends", () => {
    const failed: Tool = { ...tool("failed"), isError: true, result: { error: "failure" }, status: { type: "incomplete" } };
    const interrupted: Tool = { ...tool("interrupted"), interrupted: true, status: { type: "incomplete" } };
    const messages = [message("a", [failed, interrupted, tool("1"), tool("2"), tool("3")])];
    for (const running of [true, false]) {
      const group = toolGroupAt(projectToolTimeline(messages, running), "a", 0)!;
      const html = renderToStaticMarkup(createElement(ToolGroupView, { group }));
      expect(html.match(/data-status="error"/g)).toHaveLength(running ? 2 : 1);
      if (!running) expect(html).toContain("1 项失败，1 项已中断");
      if (running) {
        expect(html.match(/data-tool-id=/g)).toHaveLength(5);
        expect(html).toContain('data-tool-id="failed"');
        expect(html).toContain('data-tool-id="interrupted"');
      }
    }
  });

  it("reports a pending call as interrupted when its turn was cancelled after an earlier call", () => {
    const pending: Tool = { ...tool("pending"), status: { type: "running" }, finishedAtMs: undefined };
    const item = { ...message("a", [tool("done"), pending]), metadata: { custom: { interrupted: true } } };
    const messages = [item];
    const runtime = { thread: { getMessageById: () => ({ getCopyText: () => "" }) } } as unknown as RuntimeView["runtime"];
    const html = renderToStaticMarkup(createElement(RuntimeViewContext.Provider, { value: { runtime, thread: runtime.thread, getState: runtime.thread.getState } },
      createElement(MessageRow, { message: item, messages, running: false, locked: false, latest: true, timeline: projectToolTimeline(messages, false), command: () => {} })));
    expect(html).toContain("已中断");
    expect(html).toContain('data-status="error"');
  });

  it("renders text and tool groups in chronological order across assistant messages", () => {
    const messages = [message("a", [text("BEFORE"), tool("1")]), message("b", [tool("2"), text("AFTER")])];
    const timeline = projectToolTimeline(messages, false);
    const runtime = { thread: { getMessageById: () => ({ getCopyText: () => "" }) } } as unknown as RuntimeView["runtime"];
    const html = renderToStaticMarkup(createElement(RuntimeViewContext.Provider, { value: { runtime, thread: runtime.thread, getState: runtime.thread.getState } },
      messages.map((item) => createElement(MessageRow, { key: item.id, message: item, messages, running: false, locked: false, latest: item.id === "b", timeline, command: () => {} }))));
    expect(html.indexOf("BEFORE")).toBeLessThan(html.indexOf("tool-group-summary"));
    expect(html.indexOf("tool-group-summary")).toBeLessThan(html.indexOf("AFTER"));
    expect(html.match(/data-testid="tool-group-summary"/g)).toHaveLength(1);
    expect(html).not.toContain('aria-label="复制消息"');
    expect(html).not.toContain('data-testid="replay-message-button"');
  });

  it("measures elapsed wall time rather than summing concurrent calls and omits unknown or incomplete timing", () => {
    expect(toolGroupDuration([tool("1", 1000, 4000), tool("2", 2000, 3000)])).toBe(3000);
    expect(toolGroupDuration([{ ...tool("1"), finishedAtMs: undefined }])).toBeUndefined();
    expect(toolGroupDuration([{ ...tool("1"), timingIncomplete: true }])).toBeUndefined();
    expect(toolGroupDuration([tool("1", 1000, 500)])).toBeUndefined();
  });
});

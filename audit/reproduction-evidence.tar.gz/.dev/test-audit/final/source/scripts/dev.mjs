import { access, mkdir } from "node:fs/promises";
import { createServer as createNetServer } from "node:net";
import { resolve } from "node:path";
import { chromium } from "@playwright/test";
import { createServer } from "vite";
import { reloadDevelopmentExtension } from "./reload-dev-extension.ts";
import { fitWindowToScreen } from "./development-extension.mjs";
import { cleanDevStorage, lockProfile } from "./dev-storage.mjs";

const root = process.cwd();
const extensionPath = resolve(root, process.env.SURFWAX_DEV_OUT_DIR ?? "dist");
const profilePath = resolve(root, ".dev/chromium-profile");
const targetUrl = process.argv[2] ?? "https://polymarket.com/zh/esports";
const port = Number(process.env.SURFWAX_DEV_PORT ?? 5173);
let context;
let vite;
let unlockProfile;

function waitForPort() {
  return new Promise((resolveFree, reject) => {
    const probe = createNetServer();
    probe.once("error", (error) =>
      reject(
        error.code === "EADDRINUSE"
          ? new Error(
              `localhost:${port} 已被占用；请关闭已有的 Surf Wax 开发进程。`,
            )
          : error,
      ),
    );
    probe.listen(port, "localhost", () => probe.close(resolveFree));
  });
}

async function waitForFile(path, timeoutMs = 30_000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      await access(path);
      return;
    } catch {
      await new Promise((resolveWait) => setTimeout(resolveWait, 100));
    }
  }
  throw new Error(`等待开发构建超时：${path}`);
}

async function waitForWorker(extensionId, timeoutMs = 30_000) {
  const belongsToExtension = (worker) => new URL(worker.url()).hostname === extensionId;
  const existing = context.serviceWorkers().find(belongsToExtension);
  if (existing) return existing;
  try {
    return await context.waitForEvent("serviceworker", {
      predicate: belongsToExtension,
      timeout: timeoutMs,
    });
  } catch {
    throw new Error("等待 Surf Wax Service Worker 超时；请检查终端中的 Vite 编译错误后重新运行 npm run dev。");
  }
}

async function main() {
  if (!URL.canParse(targetUrl)) throw new Error(`无效的目标 URL：${targetUrl}`);
  await waitForPort();
  vite = await createServer();
  await vite.listen();
  vite.printUrls();
  await waitForFile(resolve(extensionPath, "manifest.json"));

  unlockProfile = await lockProfile(profilePath, root);
  if (!unlockProfile) throw new Error(`开发 Profile 正被使用或清理：${profilePath}。若上次进程异常退出，请确认 Chrome 已关闭后移除 ${profilePath}.cleanup-lock。`);
  await mkdir(profilePath, { recursive: true });
  try {
    context = await chromium.launchPersistentContext(profilePath, {
      channel: "chrome",
      chromiumSandbox: true,
      headless: false,
      colorScheme: null,
      viewport: null,
      ignoreDefaultArgs: ["--disable-extensions"],
      args: [
        "--start-maximized",
        "--enable-unsafe-extension-debugging",
        "--hide-crash-restore-bubble",
      ],
    });
  } catch (error) {
    throw new Error(`无法启动系统 Chrome；请确认已安装并更新 Google Chrome，且没有其他开发窗口占用 ${profilePath}。\n${error.message}`, { cause: error });
  }

  const page = context.pages().find((candidate) => candidate.url() === "about:blank") ?? await context.newPage();
  const browserSession = await context.browser().newBrowserCDPSession();
  let extensionId;
  try {
    ({ id: extensionId } = await browserSession.send("Extensions.loadUnpacked", {
      path: extensionPath,
    }));
    const { extensions } = await browserSession.send("Extensions.getExtensions");
    const others = extensions.filter((extension) => extension.enabled && extension.id !== extensionId);
    if (others.length) {
      // Keep prior output directories installed (and their data intact), but
      // restore the single-extension isolation of the old launch flags.
      const management = await context.newPage();
      try {
        await management.goto("chrome://extensions/");
        await management.evaluate(async (ids) => {
          for (const id of ids) await chrome.management.setEnabled(id, false);
        }, others.map((extension) => extension.id));
      } finally {
        await management.close();
      }
    }
  } catch (error) {
    throw new Error(`无法加载 Surf Wax 开发扩展；请更新系统 Chrome，并检查 ${extensionPath}/manifest.json 和 Vite 编译错误。\n${error.message}`, { cause: error });
  }
  console.log(`开发浏览器：${context.browser().version()}（系统 Chrome，沙箱已启用）。`);
  await fitWindowToScreen(context, page, browserSession);

  await reloadDevelopmentExtension(context, await waitForWorker(extensionId));
  console.log("Surf Wax 开发扩展已重新加载，当前源码已生效。");

  const settings = await context.newPage();
  try {
    await settings.goto(`chrome://extensions/?id=${extensionId}`);
    const toggle = settings.locator(
      "extensions-toggle-row#allow-user-scripts cr-toggle#crToggle",
    );
    await toggle.waitFor({ state: "visible" });
    if (await toggle.getAttribute("aria-checked") !== "true") await toggle.click();
    await settings.locator(
      "extensions-toggle-row#allow-user-scripts cr-toggle#crToggle[aria-checked='true']",
    ).waitFor({ state: "visible" });
  } finally {
    await settings.close();
  }

  await page.goto(targetUrl);
  const { targetInfos } = await browserSession.send("Target.getTargets", {
    filter: [{ type: "tab", exclude: false }, { exclude: true }],
  });
  const tab = targetInfos.find(
    (target) => target.type === "tab" && target.url === page.url(),
  );
  if (!tab) throw new Error(`无法找到目标标签页：${page.url()}`);
  const panelUrl = `chrome-extension://${extensionId}/sidepanel.html`;
  let reopening;

  const ensurePanel = async () => {
    if (reopening) return reopening;
    reopening = (async () => {
      const { targetInfos } = await browserSession.send("Target.getTargets");
      if (!targetInfos.some((target) => target.url.startsWith(panelUrl))) {
        await browserSession.send("Extensions.triggerAction", {
          id: extensionId,
          targetId: tab.targetId,
        });
      }
    })().finally(() => {
      reopening = undefined;
    });
    return reopening;
  };

  await ensurePanel();
  context.on("serviceworker", (nextWorker) => {
    if (new URL(nextWorker.url()).hostname === extensionId) {
      setTimeout(() => void ensurePanel().catch(console.error), 300);
    }
  });
  console.log(`\nSurf Wax 开发环境已就绪：${targetUrl}\n按 Ctrl+C 退出。`);

  await new Promise((resolveStop) => {
    process.once("SIGINT", resolveStop);
    process.once("SIGTERM", resolveStop);
    process.once("SIGHUP", resolveStop);
    context.once("close", resolveStop);
  });
}

try {
  await main();
} catch (error) {
  console.error(error instanceof Error ? error.message : error);
  process.exitCode = 1;
} finally {
  await context?.close().catch(() => undefined);
  await vite?.close().catch(() => undefined);
  await unlockProfile?.();
  await cleanDevStorage({ apply: true, cacheBudgetBytes: 256 * 1024 ** 2 }).catch(error => console.error(`开发产物清理失败：${error.message}`));
}

# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: live-market-regression.spec.ts >> captures a page with hidden layoutless and zero-sized iframe documents
- Location: e2e/live-market-regression.spec.ts:20:1

# Error details

```
Error: expect(received).toContain(expected) // indexOf

Expected substring: "Frame action"
Received string:    "[{\"id\":\"readonly:0\",\"line\":\"        - text \\\"Market dashboard\\\"\"},{\"id\":\"readonly:1\",\"line\":\"        - text \\\"Visible market action\\\"\"},{\"id\":\"readonly:2\",\"line\":\"        - text \\\"Show market frames\\\"\"}]"
```

# Test source

```ts
  68  |       const frameId = raw.strings[doc.frameId]!;
  69  |       let owner;
  70  |       try {
  71  |         const { backendNodeId } = await cdp.send("DOM.getFrameOwner", {
  72  |           frameId,
  73  |         });
  74  |         owner = (await cdp.send("DOM.describeNode", { backendNodeId })).node
  75  |           .attributes;
  76  |       } catch {
  77  |         /* Root has no owner. */
  78  |       }
  79  |       geometry.push({
  80  |         frameId,
  81  |         owner,
  82  |         viewport: doc.layout.bounds[row],
  83  |         scrollX: doc.scrollOffsetX,
  84  |         scrollY: doc.scrollOffsetY,
  85  |       });
  86  |     }
  87  |     await test
  88  |       .info()
  89  |       .attach("chrome-document-geometry", {
  90  |         body: JSON.stringify(geometry, null, 2),
  91  |         contentType: "application/json",
  92  |       });
  93  |     expect(
  94  |       geometry.some(
  95  |         (doc) =>
  96  |           doc.owner?.includes("display: none;") &&
  97  |           doc.viewport?.[2] === 0 &&
  98  |           doc.viewport?.[3] === 0,
  99  |       ),
  100 |     ).toBe(true);
  101 |     await cdp.detach();
  102 |     await target.evaluate(() => {
  103 |       const show = document.createElement("button");
  104 |       show.textContent = "Show market frames";
  105 |       show.onclick = () =>
  106 |         document
  107 |           .querySelectorAll("iframe")
  108 |           .forEach(
  109 |             (frame) => (frame.style.cssText = "width:300px;height:120px"),
  110 |           );
  111 |       document.querySelector("main")!.append(show);
  112 |     });
  113 |     responses.push(
  114 |       commandResponse(
  115 |         "inspect_page",
  116 |         { full: true, budget: 12000 },
  117 |         "hidden-market",
  118 |       ),
  119 |       commandResponse(
  120 |         "click",
  121 |         { target: { by: "role", value: "button", name: "Show market frames" } },
  122 |         "reveal-market",
  123 |       ),
  124 |       commandResponse(
  125 |         "inspect_page",
  126 |         { full: true, budget: 12000 },
  127 |         "visible-market",
  128 |       ),
  129 |       textResponse("MARKET_CAPTURE_DONE"),
  130 |       textResponse("Market"),
  131 |     );
  132 |     await (
  133 |       await configure(opened.context, opened.page, provider.baseURL)
  134 |     ).close();
  135 |     await target.bringToFront();
  136 |     await opened.page
  137 |       .getByTestId("composer-input")
  138 |       .fill("Read visible market content");
  139 |     await opened.page.getByTestId("composer-input").press("Enter");
  140 |     await expect(opened.page.locator(".markdown-body").last()).toContainText(
  141 |       "MARKET_CAPTURE_DONE",
  142 |       { timeout: 45000 },
  143 |     );
  144 |     const events = await readEvents(opened.page);
  145 |     await test
  146 |       .info()
  147 |       .attach("canonical-events", {
  148 |         body: JSON.stringify(events, null, 2),
  149 |         contentType: "application/json",
  150 |       });
  151 |     const result = events.find(
  152 |       (e) =>
  153 |         ["tool.finished", "tool.failed"].includes(e.type) &&
  154 |         e.toolCallId === "hidden-market",
  155 |     );
  156 |     expect(result, JSON.stringify(result)).toMatchObject({
  157 |       type: "tool.finished",
  158 |       output: { items: expect.any(Array) },
  159 |     });
  160 |     const visible = JSON.stringify(result.output.items);
  161 |     expect(visible).toContain("Visible market action");
  162 |     expect(visible).not.toContain("Frame action");
  163 |     expect(visible).not.toContain("same origin");
  164 |     const revealed = events.find(
  165 |       (e) =>
  166 |         e.type === "tool.finished" && e.toolCallId?.endsWith("visible-market"),
  167 |     );
> 168 |     expect(JSON.stringify(revealed?.output.items)).toContain("Frame action");
      |                                                    ^ Error: expect(received).toContain(expected) // indexOf
  169 |     expect(JSON.stringify(revealed?.output.items)).toContain("same origin");
  170 |   } finally {
  171 |     await dispose(opened.context, opened.userDataDirectory, provider.server);
  172 |   }
  173 | });
  174 | 
  175 | test("keeps current frame routes across top-level navigation with process-swapping children", async () => {
  176 |   test.setTimeout(90000);
  177 |   const responses: MockResponse[] = [],
  178 |     provider = await startProvider(responses),
  179 |     opened = await openExtension();
  180 |   try {
  181 |     const target = await opened.context.newPage();
  182 |     await target.goto(`${provider.origin}/complex`);
  183 |     const url = `${provider.origin}/complex`;
  184 |     responses.push(
  185 |       commandResponse("list_frames", {}, "before-navigation"),
  186 |       commandResponse("navigate", { url }, "market-navigation"),
  187 |       commandResponse(
  188 |         "inspect_page",
  189 |         { full: true, budget: 12000 },
  190 |         "after-navigation",
  191 |       ),
  192 |       commandResponse("reload", {}, "market-reload"),
  193 |       commandResponse(
  194 |         "inspect_page",
  195 |         { full: true, budget: 12000 },
  196 |         "after-reload",
  197 |       ),
  198 |       textResponse("NAVIGATION_CAPTURE_DONE"),
  199 |       textResponse("Navigation"),
  200 |     );
  201 |     await (
  202 |       await configure(opened.context, opened.page, provider.baseURL)
  203 |     ).close();
  204 |     await target.bringToFront();
  205 |     await opened.page
  206 |       .getByTestId("composer-input")
  207 |       .fill("Read page across navigation");
  208 |     await opened.page.getByTestId("composer-input").press("Enter");
  209 |     await expect(opened.page.locator(".markdown-body").last()).toContainText(
  210 |       "NAVIGATION_CAPTURE_DONE",
  211 |       { timeout: 75000 },
  212 |     );
  213 |     const events = await readEvents(opened.page);
  214 |     await test
  215 |       .info()
  216 |       .attach("canonical-events", {
  217 |         body: JSON.stringify(events, null, 2),
  218 |         contentType: "application/json",
  219 |       });
  220 |     for (const id of ["after-navigation", "after-reload"]) {
  221 |       const result = events.find(
  222 |         (e) =>
  223 |           ["tool.finished", "tool.failed"].includes(e.type) &&
  224 |           (e.toolCallId === id || e.toolCallId?.endsWith(":" + id)),
  225 |       );
  226 |       expect(result, JSON.stringify(result)).toMatchObject({
  227 |         type: "tool.finished",
  228 |         output: { items: expect.any(Array) },
  229 |       });
  230 |       expect(JSON.stringify(result.output.items)).toContain("Frame action");
  231 |     }
  232 |   } finally {
  233 |     await dispose(opened.context, opened.userDataDirectory, provider.server);
  234 |   }
  235 | });
  236 | 
```
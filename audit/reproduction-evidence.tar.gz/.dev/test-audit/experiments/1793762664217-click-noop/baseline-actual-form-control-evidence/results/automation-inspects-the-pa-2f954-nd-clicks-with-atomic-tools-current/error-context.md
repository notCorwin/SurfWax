# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: automation.spec.ts >> inspects the page and fills and clicks with atomic tools
- Location: e2e/automation.spec.ts:69:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

Expected: ArrayContaining [ObjectContaining {"line": StringContaining "Welcome me@example.com"}]
Received: []
```

# Test source

```ts
  1   | import { chromium, expect, type BrowserContext, type CDPSession, type Locator, type Page } from "@playwright/test";
  2   | import { once } from "node:events";
  3   | import { mkdtemp, readFile, rm } from "node:fs/promises";
  4   | import { existsSync } from "node:fs";
  5   | import { createServer, type Server } from "node:http";
  6   | import { tmpdir } from "node:os";
  7   | import { resolve } from "node:path";
  8   | import { PROGRAM_CATALOG_VERSION } from "../src/chrome/tool";
  9   | 
  10  | 
  11  | import { test, p95, textResponse, assistantResponse, commandResponse, delayedResponse, startProvider, closeServer, openExtension, dispose, selectProvider, configure, themeColors, expectThemeButton, startNewConversation, nameCurrentConversation, enableUserScripts, readEvents, attachTarget, warnsOnLeave, nativePanel, submitNative, readNativeEvents, type MockResponse } from './fixtures';
  12  | 
  13  | test("selects large tool output without creating another reference", async () => {
  14  |   const responses: MockResponse[] = [];
  15  |   const provider = await startProvider(responses);
  16  |   const opened = await openExtension();
  17  |   let artifactRef = 0;
  18  |   try {
  19  |     const target = await opened.context.newPage();
  20  |     await target.goto(`${provider.origin}/target`);
  21  |     await target.evaluate(() => { const main = document.querySelector("main")!; main.textContent = "LARGE_START" + "zx".repeat(6000); main.style.display = "none"; });
  22  |     responses.push(
  23  |       commandResponse("read_text", { target: { by: "css", value: "main" } }, "call-large"),
  24  |       (request) => {
  25  |         const message = request.messages.findLast((entry: any) => entry.role === "tool");
  26  |         const output = JSON.parse(message.content);
  27  |         expect(output.access.artifactId).toBe(output.$ref);
  28  |         artifactRef = output.$ref;
  29  |         return commandResponse("read_artifact", { ...output.access, limit: 11 }, "call-select-large");
  30  |       },
  31  |       textResponse("DONE_COMPACT"),
  32  |       textResponse("引用测试"),
  33  |     );
  34  |     const options = await configure(opened.context, opened.page, provider.baseURL);
  35  |     await options.close();
  36  |     const composer = opened.page.getByTestId("composer-input");
  37  |     await composer.fill("inspect page contexts and a large result");
  38  |     await composer.press("Enter");
  39  |     await expect(opened.page.locator(".markdown-body").last()).toContainText("DONE_COMPACT");
  40  |     await expect.poll(() => provider.requests.filter((request) => request.tools).length).toBeGreaterThanOrEqual(3);
  41  |     const requests = provider.requests.filter((request) => request.tools);
  42  |     const secondPrompt = JSON.stringify(requests[1].messages);
  43  |     expect(secondPrompt).toContain("$ref");
  44  |     expect(secondPrompt).not.toContain("zx".repeat(2_100));
  45  |     expect(JSON.stringify(requests[2].messages)).toContain("LARGE_START");
  46  |     const events = await readEvents(opened.page);
  47  |     const data = events.find((event) => event.type === "tool.result.data");
  48  |     expect(data.output).toMatchObject({ result: "LARGE_START" + "zx".repeat(6000) });
  49  |     expect(artifactRef).toBe(data.id);
  50  |     expect(events.find((event) => event.type === "tool.finished" && event.toolCallId === "call-select-large")?.output.result).toBe("LARGE_START");
  51  |     expect(events.filter((event) => event.type === "tool.result.data")).toHaveLength(1);
  52  |     await opened.page.reload();
  53  |     await opened.page.getByTestId("conversation-menu").click();
  54  |     await opened.page.locator(".conversation-item", {hasText:"引用测试"}).locator(".conversation-select").click();
  55  |     await expect(opened.page.locator(".markdown-body").last()).toContainText("DONE_COMPACT");
  56  |     await target.bringToFront();
  57  |     responses.push(commandResponse("read_artifact", { artifactId: data.id, path: ["result"], offset: 0, limit: 11 }, "read-after-reload"), textResponse("RESTORED_READ"));
  58  |     await opened.page.getByTestId("composer-input").fill("read the stored result in this restored conversation");
  59  |     await opened.page.getByTestId("composer-input").press("Enter");
  60  |     await expect(opened.page.locator(".markdown-body").last()).toContainText("RESTORED_READ");
  61  |     expect((await readEvents(opened.page)).find(event => event.type === "tool.finished" && event.toolCallId === "read-after-reload")?.output.result).toBe("LARGE_START");
  62  |     expect(await opened.page.evaluate(() => typeof (globalThis as any).__surfWaxResult)).toBe("undefined");
  63  |   } finally {
  64  |     await dispose(opened.context, opened.userDataDirectory, provider.server);
  65  |   }
  66  | });
  67  | 
  68  | 
  69  | test("inspects the page and fills and clicks with atomic tools", async () => {
  70  |   const responses: MockResponse[] = [];
  71  |   const provider = await startProvider(responses);
  72  |   const opened = await openExtension();
  73  |   try {
  74  |     await (await configure(opened.context, opened.page, provider.baseURL)).close();
  75  |     const target = await opened.context.newPage();
  76  |     await target.goto(`${provider.origin}/automation`);
  77  |     const [tab] = await opened.page.evaluate((url) => chrome.tabs.query({ url }), `${provider.origin}/automation`);
  78  |     expect(tab?.id).toBeDefined();
  79  |     responses.push(
  80  |       commandResponse("inspect_page", {}, "call-snapshot"),
  81  |       commandResponse("fill", { target: { by: "label", value: "Email" }, value: "me@example.com" }, "call-fill"),
  82  |       commandResponse("click", { target: { by: "role", value: "button", name: "Sign in" } }, "call-click"),
  83  |       commandResponse("inspect_page", {}, "call-verify"),
  84  |       textResponse("PAGE_AUTOMATION_OK"),
  85  |       textResponse("页面自动化"),
  86  |     );
  87  |     const windowCount = await opened.page.evaluate(async () => (await chrome.windows.getAll()).length);
  88  |     await opened.page.getByTestId("composer-input").fill("use semantic page automation");
  89  |     await opened.page.getByTestId("composer-input").press("Enter");
  90  |     await expect(opened.page.locator(".markdown-body").last()).toContainText("PAGE_AUTOMATION_OK");
  91  |     const events = await readEvents(opened.page);
  92  |     const observation = events.find((event) => event.type === "tool.finished" && event.toolCallId === "call-snapshot")?.output;
  93  |     const clicked = events.find((event) => event.type === "tool.finished" && event.toolCallId === "call-click")?.output;
  94  |     const verified = events.find((event) => event.type === "tool.finished" && event.toolCallId === "call-verify")?.output;
  95  |     expect(observation.items).toEqual(expect.arrayContaining([expect.objectContaining({ ref: expect.stringMatching(/^t\d+s[a-f0-9]+d\d+e\d+$/) })]));
  96  |     expect(clicked.pageSnapshot.items).toEqual(expect.arrayContaining([expect.objectContaining({ line: expect.stringContaining("Welcome me@example.com") })]));
> 97  |     expect(verified.items).toEqual(expect.arrayContaining([expect.objectContaining({ line: expect.stringContaining("Welcome me@example.com") })]));
      |                            ^ Error: expect(received).toEqual(expected) // deep equality
  98  |     await expect.poll(() => target.locator("output").textContent()).toBe("Welcome me@example.com");
  99  |     expect(events.some((event) => event.type === "automation.action.finished" && event.toolCallId === "call-click")).toBe(true);
  100 |     const toolNames = provider.requests[0].tools.map((tool: any) => tool.function.name);
  101 |     expect(toolNames).toEqual(expect.arrayContaining(["inspect_page", "fill", "click", "send_page_request"]));
  102 |     expect(toolNames).not.toContain("execute_program");
  103 |     expect(new Set(toolNames).size).toBe(toolNames.length);
  104 |     expect(toolNames).not.toContain("run");
  105 |     expect(toolNames).not.toContain("inspect");
  106 |     expect(toolNames).not.toContain("jobs");
  107 |     expect(toolNames).not.toContain("browser");
  108 |     expect(toolNames.filter((name: string) => ["open", "attach", "close", "detach", "show", "list", "close-all", "kill-all"].includes(name))).toEqual([]);
  109 |     expect(await opened.page.evaluate(async () => (await chrome.windows.getAll()).length)).toBe(windowCount);
  110 |     expect(provider.requests.filter((request) => request.tools)).toHaveLength(5);
  111 |   } finally {
  112 |     await dispose(opened.context, opened.userDataDirectory, provider.server);
  113 |   }
  114 | });
  115 | 
  116 | test("uploads a stored artifact through an independent tool", async () => {
  117 |   const responses: MockResponse[] = [];
  118 |   const provider = await startProvider(responses);
  119 |   const opened = await openExtension();
  120 |   try {
  121 |     const target = await opened.context.newPage();
  122 |     await target.goto(`${provider.origin}/automation`);
  123 |     await target.evaluate(() => {
  124 |       const input = document.createElement("input");
  125 |       input.type = "file";
  126 |       input.id = "upload-target";
  127 |       input.onchange = async () => {
  128 |         const file = input.files?.[0];
  129 |         document.body.dataset.uploadedName = file?.name ?? "";
  130 |         document.body.dataset.uploadedContent = await file?.text() ?? "";
  131 |       };
  132 |       document.body.append(input);
  133 |     });
  134 |     responses.push(
  135 |       commandResponse("create_text_artifact", { filename: "report.txt", text: "hello from artifact", mimeType: "text/plain" }, "create-upload"),
  136 |       (request) => {
  137 |         const result = JSON.parse(request.messages.findLast((entry: any) => entry.role === "tool").content);
  138 |         return commandResponse("upload_file", { target: { by: "css", value: "#upload-target" }, artifactId: result.result.id }, "upload-artifact");
  139 |       },
  140 |       textResponse("ARTIFACT_UPLOAD_OK"), textResponse("上传产物"),
  141 |     );
  142 |     const options = await configure(opened.context, opened.page, provider.baseURL);
  143 |     await options.close();
  144 |     await opened.page.getByTestId("composer-input").fill("upload the created report");
  145 |     await opened.page.getByTestId("composer-input").press("Enter");
  146 |     await expect(opened.page.locator(".markdown-body").last()).toContainText("ARTIFACT_UPLOAD_OK");
  147 |     await expect.poll(() => target.locator("body").getAttribute("data-uploaded-content")).toBe("hello from artifact");
  148 |     expect(await target.locator("body").getAttribute("data-uploaded-name")).toBe("report.txt");
  149 |     expect((await readEvents(opened.page)).find((event) => event.toolCallId === "upload-artifact" && event.type === "tool.finished")?.output).toMatchObject({ ok: true });
  150 |   } finally {
  151 |     await dispose(opened.context, opened.userDataDirectory, provider.server);
  152 |   }
  153 | });
  154 | 
  155 | test("uploads multiple artifacts to a chooser across independent tool calls", async () => {
  156 |   const responses: MockResponse[] = [];
  157 |   const provider = await startProvider(responses);
  158 |   const opened = await openExtension();
  159 |   try {
  160 |     const target = await opened.context.newPage();
  161 |     await target.goto(`${provider.origin}/automation`);
  162 |     await target.evaluate(() => {
  163 |       const input = document.createElement("input");
  164 |       input.type = "file"; input.multiple = true; input.hidden = true;
  165 |       input.onchange = async () => {
  166 |         const files = [...(input.files ?? [])];
  167 |         document.body.dataset.chooserNames = files.map((file) => file.name).join(",");
  168 |         document.body.dataset.chooserContents = (await Promise.all(files.map((file) => file.text()))).join(",");
  169 |       };
  170 |       const button = document.createElement("button");
  171 |       button.id = "open-chooser"; button.textContent = "Choose files";
  172 |       button.onclick = () => input.click();
  173 |       document.body.append(input, button);
  174 |     });
  175 |     let firstId = 0, secondId = 0, subscriptionId = "", jobId = "", pollCount = 0;
  176 |     const lastTool = (request: any) => JSON.parse(request.messages.findLast((entry: any) => entry.role === "tool").content);
  177 |     const poll: MockResponse = (request) => {
  178 |       const job = lastTool(request);
  179 |       if (job.terminal) { expect(job).toMatchObject({ ok: true, state: "succeeded" }); return textResponse("CHOOSER_TOOLS_OK"); }
  180 |       responses.unshift(poll);
  181 |       return commandResponse("get_job", { jobId, after: job.nextCursor, waitMs: 10_000 }, `chooser-job-${++pollCount}`);
  182 |     };
  183 |     responses.push(
  184 |       commandResponse("create_text_artifact", { filename: "first.txt", text: "first" }, "chooser-artifact-one"),
  185 |       (request) => { firstId = lastTool(request).result.id; return commandResponse("create_text_artifact", { filename: "second.txt", text: "second" }, "chooser-artifact-two"); },
  186 |       (request) => { secondId = lastTool(request).result.id; return commandResponse("subscribe_event", { kind: "filechooser" }, "subscribe-chooser"); },
  187 |       (request) => { subscriptionId = lastTool(request).subscriptionId; return commandResponse("click", { target: { by: "css", value: "#open-chooser" }, background: true, timeoutMs: 30_000 }, "open-chooser"); },
  188 |       (request) => { jobId = lastTool(request).jobId; return commandResponse("wait_event", { subscriptionId, waitMs: 10_000 }, "wait-chooser"); },
  189 |       (request) => {
  190 |         const event = lastTool(request).events.find((item: any) => item.kind === "filechooser");
  191 |         expect(event.payload).toMatchObject({ mode: "selectMultiple", chooserId: expect.any(String) });
  192 |         return commandResponse("upload_file_chooser", { chooserId: event.payload.chooserId, artifactId: [firstId, secondId] }, "answer-chooser");
  193 |       },
  194 |       (request) => { expect(lastTool(request)).toMatchObject({ state: "completed", artifactIds: [firstId, secondId] }); return commandResponse("get_job", { jobId }, "read-chooser-job"); },
  195 |       poll, textResponse("选择文件"),
  196 |     );
  197 |     await (await configure(opened.context, opened.page, provider.baseURL)).close();
```
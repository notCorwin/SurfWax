# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page-independent-tools.spec.ts >> runs page-independent tools after closing the bound tab, including opening a restricted page
- Location: e2e/page-independent-tools.spec.ts:9:1

# Error details

```
Error: page.evaluate: Execution context was destroyed, most likely because of a navigation
```

# Test source

```ts
  356 |   const [options] = await Promise.all([context.waitForEvent("page"), page.getByTestId("open-settings").click()]);
  357 |   await options.waitForLoadState("domcontentloaded");
  358 |   await selectProvider(options, "custom", /自定义 Endpoint.*custom/);
  359 |   await options.getByText("高级设置", { exact: true }).click();
  360 |   await options.getByLabel("Base URL", { exact: true }).fill(baseURL);
  361 |   await options.getByLabel("Model ID", { exact: true }).fill("test-model");
  362 |   await options.getByLabel("API Key", { exact: true }).fill("test-key");
  363 |   await options.getByLabel("上下文窗口（tokens）").fill(String(contextWindow));
  364 |   await options.getByRole("button", { name: "保存配置" }).click();
  365 |   await expect(options.getByRole("status")).toContainText("配置已保存");
  366 |   await expect(page.getByTestId("composer-input")).toBeVisible();
  367 |   return options;
  368 | }
  369 | 
  370 | /** Explicitly advertise vision only for tests that request image artifacts. */
  371 | export async function configureWithImages(context: BrowserContext, page: Page, baseURL: string): Promise<Page> {
  372 |   const options = await configure(context, page, baseURL);
  373 |   await options.getByLabel("图片输入能力").click();
  374 |   await options.getByRole("option", { name: "支持", exact: true }).click();
  375 |   await options.getByRole("button", { name: "保存配置" }).click();
  376 |   await expect(options.getByRole("status")).toContainText("配置已保存");
  377 |   return options;
  378 | }
  379 | 
  380 | /** The settings tab can still own native focus; activate the tested surface first. */
  381 | export async function focusPageControl(page: Page, control: Locator): Promise<void> {
  382 |   await page.bringToFront();
  383 |   await expect.poll(() => page.evaluate(() => document.hasFocus())).toBe(true);
  384 |   await control.evaluate((element) => (element as HTMLElement).blur());
  385 |   await control.focus();
  386 |   await expect(control).toBeFocused();
  387 | }
  388 | 
  389 | export async function themeColors(page: Page, selectors: string[]): Promise<{ colorScheme: string; colors: { background: string; foreground: string }[] }> {
  390 |   return page.evaluate((targets) => ({
  391 |     colorScheme: getComputedStyle(document.documentElement).colorScheme,
  392 |     colors: targets.map((selector) => {
  393 |       const element = document.querySelector<HTMLElement>(selector);
  394 |       if (!element) throw new Error(`Missing theme target: ${selector}`);
  395 |       const style = getComputedStyle(element);
  396 |       return { background: style.backgroundColor, foreground: style.color };
  397 |     }),
  398 |   }), selectors);
  399 | }
  400 | 
  401 | export async function expectThemeButton(locator: Locator, colorScheme: "light" | "dark", variant: "default" | "destructive") {
  402 |   const expectedColor = variant === "destructive"
  403 |     ? colorScheme === "light" ? "rgb(185, 28, 28)" : "rgb(239, 68, 68)"
  404 |     : colorScheme === "light" ? "rgb(36, 109, 97)" : "rgb(157, 217, 201)";
  405 |   await expect.poll(() => locator.evaluate((element) => {
  406 |     const style = getComputedStyle(element);
  407 |     const canvas = document.createElement("canvas"); canvas.width = canvas.height = 1;
  408 |     const context = canvas.getContext("2d")!; context.fillStyle = style.backgroundColor; context.fillRect(0, 0, 1, 1);
  409 |     return { alpha: context.getImageData(0, 0, 1, 1).data[3], foreground: style.color, fontSize: style.fontSize, fontWeight: style.fontWeight };
  410 |   })).toMatchObject({ foreground: expectedColor, fontSize: "14px", fontWeight: "500" });
  411 |   const alpha = await locator.evaluate((element) => {
  412 |     const canvas = document.createElement("canvas"); canvas.width = canvas.height = 1;
  413 |     const context = canvas.getContext("2d")!; context.fillStyle = getComputedStyle(element).backgroundColor; context.fillRect(0, 0, 1, 1);
  414 |     return context.getImageData(0, 0, 1, 1).data[3]!;
  415 |   });
  416 |   expect(alpha).toBeGreaterThan(0);
  417 |   expect(alpha).toBeLessThan(64);
  418 | }
  419 | 
  420 | export async function startNewConversation(page: Page): Promise<void> {
  421 |   if (await page.locator(".conversation-dropdown").isVisible()) await page.keyboard.press("Escape");
  422 |   await page.getByTestId("new-conversation").click();
  423 |   await expect(page.getByTestId("conversation-menu")).toContainText("新对话");
  424 |   await expect(page.getByTestId("composer-input")).toBeEnabled();
  425 | }
  426 | 
  427 | /** Seed a named, idle conversation before a run. UI mutation itself is tested separately. */
  428 | export async function nameCurrentConversation(page: Page, title: string): Promise<void> {
  429 |   const id = await page.evaluate(async (title) => {
  430 |     const id = crypto.randomUUID();
  431 |     const db = await new Promise<IDBDatabase>((resolve, reject) => {
  432 |       const request = indexedDB.open("side-agent-runtime");
  433 |       request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error);
  434 |     });
  435 |     const transaction = db.transaction("events", "readwrite");
  436 |     const store = transaction.objectStore("events");
  437 |     const timestamp = new Date().toISOString();
  438 |     store.add({ type: "conversation.created", conversationId: id, timestamp, content: null });
  439 |     store.add({ type: "conversation.title.updated", conversationId: id, timestamp, content: { title, source: "manual" } });
  440 |     await new Promise<void>((resolve, reject) => { transaction.oncomplete = () => resolve(); transaction.onerror = () => reject(transaction.error); });
  441 |     db.close(); return id;
  442 |   }, title);
  443 |   await page.reload();
  444 |   await page.getByTestId("conversation-menu").click();
  445 |   await page.locator(".conversation-item", { hasText: title }).locator(".conversation-select").click();
  446 |   await expect(page.getByTestId("conversation-menu")).toContainText(title);
  447 | }
  448 | 
  449 | export async function enableUserScripts(context: BrowserContext, extensionId: string, extensionPage: Page): Promise<void> {
  450 |   if (await extensionPage.evaluate(() => typeof chrome.userScripts === "object")) return;
  451 |   const settings = await context.newPage();
  452 |   await settings.goto(`chrome://extensions/?id=${extensionId}`);
  453 |   const toggle = settings.locator("extensions-toggle-row#allow-user-scripts cr-toggle#crToggle");
  454 |   await expect(toggle).toBeVisible();
  455 |   if (await toggle.evaluate((element) => element.getAttribute("aria-checked") ?? element.getAttribute("aria-pressed")) !== "true") await toggle.click();
> 456 |   await expect.poll(() => extensionPage.evaluate(() => typeof chrome.userScripts)).toBe("object");
      |                                         ^ Error: page.evaluate: Execution context was destroyed, most likely because of a navigation
  457 |   await settings.close();
  458 | }
  459 | 
  460 | export async function readEvents(page: Page): Promise<any[]> {
  461 |   const events = await page.evaluate<any[]>(() => new Promise((resolveEvents, reject) => {
  462 |     const request = indexedDB.open("side-agent-runtime");
  463 |     request.onerror = () => reject(request.error);
  464 |     request.onsuccess = () => {
  465 |       const transaction = request.result.transaction("events", "readonly");
  466 |       const all = transaction.objectStore("events").getAll();
  467 |       all.onerror = () => reject(all.error);
  468 |       all.onsuccess = () => resolveEvents(all.result);
  469 |     };
  470 |   }));
  471 |   expect(events.filter((event) => event.type === "conversation.stream.chunk")).toEqual([]);
  472 |   return events;
  473 | }
  474 | 
  475 | export async function attachTarget(browserSession: CDPSession, targetId: string) {
  476 |   const { sessionId } = await browserSession.send("Target.attachToTarget", { targetId, flatten: false });
  477 |   let requestId = 0;
  478 |   const pending = new Map<number, { resolve: (value: any) => void; reject: (error: Error) => void }>();
  479 |   const receive = ({ sessionId: incoming, message }: { sessionId: string; message: string }) => {
  480 |     if (incoming !== sessionId) return;
  481 |     const response = JSON.parse(message);
  482 |     const request = pending.get(response.id);
  483 |     if (!request) return;
  484 |     pending.delete(response.id);
  485 |     if (response.error) request.reject(new Error(response.error.message));
  486 |     else request.resolve(response.result);
  487 |   };
  488 |   browserSession.on("Target.receivedMessageFromTarget", receive);
  489 |   const send = <T = any>(method: string, params: object = {}) => new Promise<T>((resolveSend, rejectSend) => {
  490 |     const id = ++requestId;
  491 |     pending.set(id, { resolve: resolveSend, reject: rejectSend });
  492 |     void browserSession.send("Target.sendMessageToTarget", { sessionId, message: JSON.stringify({ id, method, params }) }).catch(rejectSend);
  493 |   });
  494 |   return {
  495 |     send,
  496 |     async evaluate<T>(expression: string): Promise<T> {
  497 |       const response = await send<any>("Runtime.evaluate", { expression, awaitPromise: true, returnByValue: true });
  498 |       if (response.exceptionDetails) throw new Error(response.exceptionDetails.exception?.description ?? response.exceptionDetails.text);
  499 |       return response.result.value as T;
  500 |     },
  501 |     async close() {
  502 |       browserSession.off("Target.receivedMessageFromTarget", receive);
  503 |       await browserSession.send("Target.detachFromTarget", { sessionId }).catch(() => undefined);
  504 |     },
  505 |   };
  506 | }
  507 | 
  508 | export async function warnsOnLeave(page: Page): Promise<boolean> {
  509 |   return page.evaluate(() => {
  510 |     const event = new Event("beforeunload", { cancelable: true });
  511 |     window.dispatchEvent(event);
  512 |     return event.defaultPrevented;
  513 |   });
  514 | }
  515 | 
  516 | 
  517 | export { expect, chromium };
  518 | 
  519 | export async function openNativeSidePanel(opened: Awaited<ReturnType<typeof openExtension>>, targetURL: string,
  520 |   settings: { browser?: CDPSession; windowId?: number } = {}) {
  521 |   const browser = settings.browser ?? await opened.context.browser()!.newBrowserCDPSession();
  522 |   const panelURL = `chrome-extension://${opened.extensionId}/sidepanel.html`;
  523 |   const isPanel = (info: { type: string; url: string }) => info.type !== 'tab' && info.url.split(/[?#]/, 1)[0] === panelURL;
  524 |   const harness = opened.page.isClosed() ? await opened.context.newPage() : opened.page;
  525 |   if (harness !== opened.page) await harness.goto(`chrome-extension://${opened.extensionId}/options.html`);
  526 |   const chromeTabs = await harness.evaluate(({ url, windowId }) => chrome.tabs.query({ url, ...(windowId !== undefined ? { windowId } : {}) }),
  527 |     { url: targetURL, windowId: settings.windowId });
  528 |   const chromeTab = chromeTabs[0];
  529 |   if (!chromeTab?.id || chromeTab.windowId === undefined) throw new Error('Native panel Chrome tab not found');
  530 |   const windowId = chromeTab.windowId;
  531 |   const panelsBefore = new Set((await browser.send('Target.getTargets')).targetInfos
  532 |     .filter(isPanel).map(info => info.targetId));
  533 |   try {
  534 |     const tabs = await browser.send('Target.getTargets', { filter: [{ type: 'tab', exclude: false }, { exclude: true }] });
  535 |     const tab = tabs.targetInfos.find(item => item.url === targetURL);
  536 |     if (!tab) throw new Error('Native panel target tab not found');
  537 |     await browser.send('Extensions.triggerAction', { id: opened.extensionId, targetId: tab.targetId });
  538 |   } catch (error) {
  539 |     if (!/Extensions\.triggerAction.*(?:wasn't found|not found)|method not found/i.test(String(error))) throw error;
  540 |     // Chrome 138 does not expose the CDP Extensions domain. A real click on an
  541 |     // extension button supplies the user gesture required by SidePanel.open.
  542 |     await harness.evaluate((owningWindowId) => {
  543 |       const button = document.createElement('button');
  544 |       button.id = 'e2e-open-native-panel'; button.textContent = 'Open native panel';
  545 |       button.style.cssText = 'position:fixed;inset:8px auto auto 8px;z-index:2147483647;padding:12px';
  546 |       button.onclick = () => { void chrome.sidePanel.open({ windowId: owningWindowId }).then(
  547 |         () => { button.dataset.result = 'opened'; }, (failure) => { button.dataset.error = String(failure); }); };
  548 |       document.body.append(button);
  549 |     }, windowId);
  550 |     await harness.bringToFront();
  551 |     await harness.locator('#e2e-open-native-panel').click();
  552 |     await expect(harness.locator('#e2e-open-native-panel')).toHaveAttribute('data-result', 'opened');
  553 |   }
  554 |   await harness.evaluate(async ({ tabId, windowId }) => {
  555 |     await chrome.tabs.update(tabId, { active: true });
  556 |     await chrome.windows.update(windowId, { focused: true });
```
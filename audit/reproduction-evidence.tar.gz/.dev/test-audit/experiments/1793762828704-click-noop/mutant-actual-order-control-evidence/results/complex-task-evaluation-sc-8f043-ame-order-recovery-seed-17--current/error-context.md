# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: complex-task-evaluation.spec.ts >> scripted complex task: cross-frame order recovery (seed 17)
- Location: e2e/complex-task-evaluation.spec.ts:17:30

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 7
+ Received  + 1

  Object {
    "changes": Array [
      "express",
    ],
-   "orders": Array [
-     Object {
-       "confirmed": true,
-       "order": "ORDER-17",
-       "service": "express",
-     },
-   ],
+   "orders": Array [],
    "selected": "express",
  }
```

# Test source

```ts
  1   | import { createHash } from "node:crypto";
  2   | import { execFileSync } from "node:child_process";
  3   | import { expect } from "@playwright/test";
  4   | import { test, commandResponse, textResponse, startProvider, openExtension, dispose, configure, readEvents, type MockResponse } from "./fixtures";
  5   | 
  6   | // This is a deterministic execution-contract probe, not a model benchmark:
  7   | // every tool choice below is scripted. Actual provider usage is unavailable.
  8   | const digest = (value: unknown) => createHash("sha256").update(JSON.stringify(value)).digest("hex");
  9   | const byteSize = (value: unknown) => Buffer.byteLength(JSON.stringify(value));
  10  | const lastTool = (request: any) => {
  11  |   const content = request.messages.findLast((message: any) => message.role === "tool")?.content;
  12  |   return JSON.parse(Array.isArray(content) ? content.find((part: any) => part.type === "text").text : content);
  13  | };
  14  | const head = () => { try { return execFileSync("git", ["rev-parse", "HEAD"], { encoding: "utf8" }).trim(); } catch { return null; } };
  15  | const dirty = () => { try { return execFileSync("git", ["status", "--porcelain"], { encoding: "utf8" }).trim().length > 0; } catch { return null; } };
  16  | 
  17  | for (const seed of [17, 73]) test(`scripted complex task: cross-frame order recovery (seed ${seed})`, async () => {
  18  |   test.setTimeout(90_000);
  19  |   const responses: MockResponse[] = [];
  20  |   const provider = await startProvider(responses);
  21  |   const opened = await openExtension();
  22  |   const started = Date.now();
  23  |   let businessVerified = false, frameRef = "", buttonRef = "", actual: unknown, events: any[] = [];
  24  |   const checkpoints: Record<string, unknown> = {};
  25  |   const order = `ORDER-${seed}`;
  26  |   const service = seed === 17 ? "express" : "economy";
  27  |   const callIds = ["frames", "find-submit", "invalid-service", "read-after-failure", "choose-service", "enter-order", "confirm-checkbox", "submit-order", "verify-status"];
  28  |   try {
  29  |     const target = await opened.context.newPage();
  30  |     await target.goto(`${provider.origin}/complex`);
  31  |     await target.evaluate(() => {
  32  |       const frame = document.querySelector<HTMLIFrameElement>('iframe[src*=localhost]')!;
  33  |       document.querySelector<HTMLIFrameElement>('iframe[src="/same-frame"]')!.style.display = "none";
  34  |       frame.style.cssText = "width:540px;height:360px;transform:none";
  35  |       const decoy = document.createElement("button"); decoy.textContent = "Submit order";
  36  |       decoy.onclick = () => { document.body.dataset.decoyClicks = String(Number(document.body.dataset.decoyClicks || 0) + 1); };
  37  |       document.body.append(decoy);
  38  |     });
  39  |     const frame = target.frames().find((item) => item.url().includes("localhost"))!;
  40  |     await frame.evaluate(() => {
  41  |       document.body.innerHTML = `<label>Order reference <input id="order"></label>
  42  |         <label>Service <select id="service"><option value="standard">Standard</option><option value="express">Express</option><option value="economy">Economy</option></select></label>
  43  |         <label><input type="checkbox" id="confirmed"> Confirm details</label>
  44  |         <button id="submit">Submit order</button><output id="status">Not submitted</output>`;
  45  |       const changes: string[] = [];
  46  |       document.querySelector<HTMLSelectElement>("#service")!.addEventListener("change", (event) => changes.push((event.target as HTMLSelectElement).value));
  47  |       (window as any).businessChanges = changes;
  48  |       (window as any).businessOrders = [];
  49  |       document.querySelector<HTMLButtonElement>("#submit")!.onclick = () => {
  50  |         const submitted = { order: document.querySelector<HTMLInputElement>("#order")!.value,
  51  |           service: document.querySelector<HTMLSelectElement>("#service")!.value,
  52  |           confirmed: document.querySelector<HTMLInputElement>("#confirmed")!.checked };
  53  |         (window as any).businessOrders.push(submitted);
  54  |         document.querySelector("#status")!.textContent = "Submitted " + submitted.order;
  55  |       };
  56  |     });
  57  |     const targetInFrame = (by: string, value: string) => ({ by, value, frame: { ref: frameRef } });
  58  |     responses.push(
  59  |       commandResponse("list_frames", {}, callIds[0]!),
  60  |       (request) => {
  61  |         const result = lastTool(request); frameRef = result.frames?.find((entry: any) => entry.url.includes("localhost"))?.frameRef ?? "missing-frame";
  62  |         checkpoints.frames = result;
  63  |         return commandResponse("find_elements", { target: { ...targetInFrame("role", "button"), name: "Submit order" } }, callIds[1]!);
  64  |       },
  65  |       (request) => {
  66  |         const result = lastTool(request); buttonRef = result.elements?.[0]?.ref ?? "missing-ref";
  67  |         checkpoints.find = { total: result.total, ref: buttonRef };
  68  |         return commandResponse("select_option", { target: targetInFrame("css", "#service"), value: "not-an-option" }, callIds[2]!);
  69  |       },
  70  |       (request) => { checkpoints.failedSelection = lastTool(request); return commandResponse("read_value", { target: targetInFrame("css", "#service") }, callIds[3]!); },
  71  |       (request) => { checkpoints.afterFailure = lastTool(request); return commandResponse("select_option", { target: targetInFrame("css", "#service"), value: service }, callIds[4]!); },
  72  |       (request) => { checkpoints.selection = lastTool(request); return commandResponse("fill", { target: targetInFrame("css", "#order"), value: order }, callIds[5]!); },
  73  |       (request) => { checkpoints.fill = lastTool(request); return commandResponse("check_element", { target: targetInFrame("css", "#confirmed") }, callIds[6]!); },
  74  |       (request) => { checkpoints.check = lastTool(request); return commandResponse("click", { target: { ref: buttonRef } }, callIds[7]!); },
  75  |       (request) => { checkpoints.submit = lastTool(request); return commandResponse("verify_state", { target: targetInFrame("css", "#status"), textIncludes: `Submitted ${order}` }, callIds[8]!); },
  76  |       (request) => { checkpoints.verify = lastTool(request); return textResponse("SCRIPTED_TASK_DONE"); },
  77  |       textResponse("跨框架订单"),
  78  |     );
  79  |     await (await configure(opened.context, opened.page, provider.baseURL)).close();
  80  |     await target.bringToFront();
  81  |     await opened.page.getByTestId("composer-input").fill(`Submit order ${order} using ${service} service and confirm details.`);
  82  |     await opened.page.getByTestId("composer-input").press("Enter");
  83  |     await expect(opened.page.locator(".markdown-body").last()).toContainText("SCRIPTED_TASK_DONE", { timeout: 60_000 });
  84  | 
  85  |     // The business judge reads the application state independently of the LLM
  86  |     // and of tool receipts; the model's final text is never the pass criterion.
  87  |     actual = await frame.evaluate(() => ({ orders: (window as any).businessOrders, changes: (window as any).businessChanges,
  88  |       selected: document.querySelector<HTMLSelectElement>("#service")!.value }));
> 89  |     expect(actual).toEqual({ orders: [{ order, service, confirmed: true }], changes: [service], selected: service });
      |                    ^ Error: expect(received).toEqual(expected) // deep equality
  90  |     expect(await target.locator("body").getAttribute("data-decoy-clicks")).toBeNull();
  91  |     expect(checkpoints.failedSelection).toMatchObject({ ok: false });
  92  |     expect(checkpoints.afterFailure).toMatchObject({ ok: true, result: "standard" });
  93  |     expect(checkpoints.find).toMatchObject({ total: 1, ref: expect.any(String) });
  94  |     expect(checkpoints.verify).toMatchObject({ ok: true, result: { verified: true } });
  95  |     events = await readEvents(opened.page);
  96  |     const terminals = events.filter((event) => ["tool.finished", "tool.failed"].includes(event.type) && callIds.includes(event.toolCallId));
  97  |     for (const id of callIds) expect(terminals.filter((event) => event.toolCallId === id), `terminal result for ${id}`).toHaveLength(1);
  98  |     const requests = provider.requests.filter((request) => Array.isArray(request.tools));
  99  |     expect(requests).toHaveLength(callIds.length + 1);
  100 |     expect(requests.every((request) => digest(request.tools) === digest(requests[0].tools))).toBe(true);
  101 |     expect(requests[0].tools.map((tool: any) => tool.function.name)).toEqual(expect.arrayContaining(["list_frames", "find_elements", "select_option", "read_value", "fill", "check_element", "click", "verify_state"]));
  102 |     businessVerified = true;
  103 |   } finally {
  104 |     // Preserve failed attempts and their request costs, rather than reporting
  105 |     // successful runs only. These are JSON-byte measures, not billed tokens.
  106 |     if (!events.length) events = await readEvents(opened.page).catch(() => []);
  107 |     const requests = provider.requests.filter((request) => Array.isArray(request.tools));
  108 |     const schemas = requests.map((request) => digest(request.tools));
  109 |     const systemMessages = requests[0]?.messages?.filter((message: any) => message.role === "system") ?? [];
  110 |     const browser = await opened.context.newCDPSession(opened.page).then((session) => session.send("Browser.getVersion")).catch(() => null);
  111 |     const report = {
  112 |       scenario: "cross-frame-order-recovery", seed, execution: "scripted-mock-provider", businessVerified,
  113 |       scenarioWallClockMsIncludingSetup: Date.now() - started, gitHead: head(), gitDirty: dirty(), browser: browser?.product ?? null,
  114 |       provider: "mock-openai-compatible", model: "test-model", providerUsage: null,
  115 |       providerUsageReason: "The scripted provider did not report actual model usage; request bytes are not token counts.",
  116 |       toolCatalogHash: schemas[0] ?? null, toolCatalogStableAcrossRequests: schemas.every((hash) => hash === schemas[0]),
  117 |       toolCatalogBytes: requests[0] ? byteSize(requests[0].tools) : null,
  118 |       systemMessagesHash: digest(systemMessages), modelRequests: requests.length,
  119 |       reserializedRequestBytes: requests.reduce((sum, request) => sum + byteSize(request), 0),
  120 |       toolTerminalCounts: { succeeded: events.filter((event) => event.type === "tool.finished" && callIds.includes(event.toolCallId)).length,
  121 |         failed: events.filter((event) => event.type === "tool.failed" && callIds.includes(event.toolCallId)).length },
  122 |       expectedToolCalls: callIds.length, observedTerminalResults: events.filter((event) => ["tool.finished", "tool.failed"].includes(event.type) && callIds.includes(event.toolCallId)).length,
  123 |       actual, checkpoints,
  124 |     };
  125 |     await test.info().attach("scripted-complex-task-report", { body: JSON.stringify(report, null, 2), contentType: "application/json" });
  126 |     await dispose(opened.context, opened.userDataDirectory, provider.server);
  127 |   }
  128 | });
  129 | 
```